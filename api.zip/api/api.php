<?php  require_once("Rest.inc.php");
    require_once("../config.php");
require_once("system/library/image.php");
require_once("system/library/mail.php");

require_once("system/library/language.php");
require_once("system/modification/system/engine/loader.php");
require_once("system/engine/registry.php");
require_once("system/startupapi.php");

    class API extends REST {

        const DB_SERVER = DB_HOSTNAME;
        const DB_USER = DB_USERNAME;
        const DB_PASSWORD = DB_PASSWORD;
        const DB = DB_DATABASE;
        const DBPREFIX = DB_PREFIX;
        const VERSION = "2";
       
        const IMAGE_PATH = "http://sitename.com/image/";
        const WEBURL = "http://sitename.com/";

       
        private $db = NULL;

        public function __construct(){
            parent::__construct();                // Init parent contructor
            $this->dbConnect();                    // Initiate Database connection
        }

        /*
         *  Database connection
        */
        private function dbConnect(){
            $this->db = mysql_connect(self::DB_SERVER,self::DB_USER,self::DB_PASSWORD);
            if($this->db)
            mysql_select_db(self::DB,$this->db);
            mysql_set_charset('utf8',$this->db);
        }

        public function processApi(){
            $func = strtolower(trim(str_replace("/","",$_REQUEST['rquest'])));
            if((int)method_exists($this,$func) > 0)
                $this->$func();
            else
                $this->response('',404);                // If the method not exist with in this class, response would be "Page not found".
        }
        private function get_cart_products(){
            if($this->get_request_method() != 'POST'){
                $return_arry = array('status' => '401','message' => 'Invalid Request Type');
                $this->response($this->json($return_arry), 400);
            }

            /*$par = json_encode($_POST);
            $par = str_replace('\"','"',$par);
            $par = str_replace('"[','[',$par);
            $par = str_replace(']"',']',$par);
                       
            $params = (array)json_decode($par,true);*/
           
            $params = (array)json_decode($this->_request,true);
           
            if(empty($params)){
                $return_arry = array('status' => '401','message' => 'Invalid Json format');
                $this->response($this->json($return_arry), 400);
            }
           
            if(!isset($params['language_id']) || $params['language_id'] == ''){
                $return_arry = array('status' => '401','message' => 'Invalid Language Id');
                $this->response($this->json($return_arry), 400);
            } elseif(!isset($params['products']) || empty($params['products'])){
                $return_arry = array('status' => '401','message' => 'Invalid Products');
                $this->response($this->json($return_arry), 400);
            }else{
                $products = $params['products'];
                $language_id = $params['language_id'];
                $cart_products = $this->get_cart_products_info($products,$language_id);
                                $return_array = array();
                                $total = 0;
                                foreach($cart_products as $cart_product){
                                   $total = $total + $cart_product['total'];
                                   $cart_product['image'] = self::IMAGE_PATH.$cart_product['image'];
                                   $cart_product['price'] = $this->currencyformat($cart_product['price']);
                                   $cart_product['total'] = $this->currencyformat($cart_product['total']);
                                   $return_array[] =  $cart_product;                                
                                }
               
                $return_arry = array('status' => '200','total' => $this->currencyformat($total),'cart' => $return_array);
                $this->response($this->json($return_arry), 200);
            }
       
        }
       
        /*
        * get Shipping Method
        */
        private function getshipping_method(){
            $return_array = array();
           
             if($this->get_request_method() != 'POST'){
                $return_arry = array('status' => '401','message' => 'Invalid Request Type');
                $this->response($this->json($return_arry), 400);
            }

            /*$par = $_POST['value']; //json_encode($_POST['value']);
            $params = (array)json_decode($par);
            */
            $params = (array)json_decode($this->_request,true);
           
            //echo '<pre>';
            //print_r($this->_request); exit;
           
            if(empty($params)){
                $return_arry = array('status' => '401','message' => 'Invalid Json format');
                $this->response($this->json($return_arry), 400);
            }
           
            if(!isset($params['language_id']) || $params['language_id'] == ''){
                $return_arry = array('status' => '401','message' => 'Invalid Language Id');
                $this->response($this->json($return_arry), 400);
            } elseif(!isset($params['products']) || empty($params['products'])){
                $return_arry = array('status' => '401','message' => 'Invalid Products');
                $this->response($this->json($return_arry), 400);
            } elseif(!isset($params['shipping_address']) || empty($params['shipping_address'])){
                $return_arry = array('status' => '401','message' => 'Invalid Shipping Address');
                $this->response($this->json($return_arry), 400);
            } elseif(!isset($params['payment_address']) || empty($params['payment_address'])){
                $return_arry = array('status' => '401','message' => 'Invalid Payment Address');
                $this->response($this->json($return_arry), 400);
            }else{
                $shipping_address = $params['shipping_address'];
                $payment_address = $params['payment_address'];
                $products = $params['products'];
                $language_id = $params['language_id'];
            }
           
            $cart_products = $this->get_cart_products_info($products,$language_id);
            $total = 0;
            $items = 0;
            foreach($cart_products as $cart_product){
                $total += $cart_product['total'];
            }
           
            foreach($cart_products as $cart_product){
                if ($cart_product['shipping']) {
                    $items += $cart_product['quantity'];
                }
            }
           
            $shipping_method_code = array('free','item','pickup','flat');
           
            $shipping_methods = $this->getallrows("SELECT * FROM ".self::DBPREFIX."extension WHERE type = 'shipping'");
           
            foreach($shipping_methods as $shipping_method){
                if (in_array($shipping_method['code'], $shipping_method_code) && $this->setting($shipping_method['code'],$shipping_method['code'].'_status')){
                    $query = $this->getonerow("SELECT * FROM " . self::DBPREFIX . "zone_to_geo_zone WHERE geo_zone_id = '" . (int)$this->setting($shipping_method['code'],$shipping_method['code'].'_geo_zone_id') . "' AND country_id = '" . (int)$shipping_address['shipping_country_id'] . "' AND (zone_id = '" . (int)$shipping_address['shipping_zone_id'] . "' OR zone_id = '0')");
           
                    if (!$this->setting($shipping_method['code'],$shipping_method['code'].'_geo_zone_id')){
                        $status = true;
                    } elseif ($query) {
                        $status = true;
                    } else {
                        $status = false;
                    }
                   
                    if($shipping_method['code'] ==  'free'){
                        if ($total < $this->setting('free','free_total')) {
                            $status = false;
                        }
                    }
                   
                    $method_data = array();

                    if ($status) {
                        $quote_data = array();
                       
                        if($shipping_method['code'] ==  'free' || $shipping_method['code'] ==  'pickup'){
                            $cost = "0.00";
                            $text = $cost;
                        } elseif($shipping_method['code'] ==  'item'){
                            $cost = $this->setting('item','item_cost') * $items;
                            $text = $this->taxcalculation($cost,$this->setting('item','item_tax_class_id'),$payment_address,$shipping_address,$this->setting('config','config_tax'));
                            $text = $text['value'];
                        } else{
                            $cost = $this->setting('flat','flat_cost');
                            $text = $this->taxcalculation($cost,$this->setting('flat','flat_tax_class_id'),$payment_address,$shipping_address,$this->setting('config','config_tax'));
                            $text = $text['value'];
                        }
                        if($this->setting($shipping_method['code'],$shipping_method['code'].'_tax_class_id'))
                                                {
                                                          $tax_class_ids = $this->setting($shipping_method['code'],$shipping_method['code'].'_tax_class_id');
                                                }
                                                else{
                           $tax_class_ids = "0";
                        }
                        $quote_data[] = array(
                            'code'         => $shipping_method['code'].".".$shipping_method['code'],
                            'title'        => $shipping_method['code']." Shipping(".$this->currencyformat($text).")",
                            'cost'         => $cost,
                            'tax_class_id' => $tax_class_ids,
                            'text'         => $this->currencyformat($text)
                        );

                        $method_data = array(
                            'code'       => $shipping_method['code'],
                            'title'      => $shipping_method['code']." Shipping(".$this->currencyformat($text).")",
                            'quote'      => $quote_data,
                            'sort_order' => $this->setting($shipping_method['code'],$shipping_method['code'].'_sort_order'),
                            'error'      => false
                        );
                       
                        $return_array[] = $method_data;
                    }
                }
           
            }
           
            $return_arry = array('status' => '200','shipping_method' => $return_array);
            $this->response($this->json($return_arry), 200);
        }
       
       
        /*
        * get payment Method
        */
       
        private function getpayment_method(){
           
            $return_array = array();
           
            if($this->get_request_method() != 'POST'){
                $return_arry = array('status' => '401','message' => 'Invalid Request Type');
                $this->response($this->json($return_arry), 400);
            }

            //$par = json_encode($_POST);
            //$params = (array)json_decode($par);
           
            $params = (array)json_decode($this->_request,true);
           
            if(empty($params)){
                $return_arry = array('status' => '401','message' => 'Invalid Json format');
                $this->response($this->json($return_arry), 400);
            }
           
            if(!isset($params['language_id']) || $params['language_id'] == ''){
                $return_arry = array('status' => '401','message' => 'Invalid Language Id');
                $this->response($this->json($return_arry), 400);
            } elseif(!isset($params['products']) || empty($params['products'])){
                $return_arry = array('status' => '401','message' => 'Invalid Products');
                $this->response($this->json($return_arry), 400);
            } elseif(!isset($params['payment_address']) || empty($params['payment_address'])){
                $return_arry = array('status' => '401','message' => 'Invalid Address');
                $this->response($this->json($return_arry), 400);
            }else{
                $address = $params['payment_address'];
                $products = $params['products'];
                $language_id = $params['language_id'];
            }
           
            $cart_products = $this->get_cart_products_info($products,$language_id);
            $total = 0;
            foreach($cart_products as $cart_product){
                $total += $cart_product['total'];
            }
           
            $payment_methods = $this->getallrows("SELECT * FROM ".self::DBPREFIX."extension WHERE type = 'payment'");
           
            foreach($payment_methods as $payment_method){
                $query = $this->getonerow("SELECT * FROM " . self::DBPREFIX . "zone_to_geo_zone WHERE geo_zone_id = '" . (int)$this->setting($payment_method['code'],$payment_method['code'].'_geo_zone_id') . "' AND country_id = '" . (int)$address['payment_country_id'] . "' AND (zone_id = '" . (int)$address['payment_zone_id'] . "' OR zone_id = '0')");
           
                if ($this->setting($payment_method['code'],$payment_method['code'].'_total') > 0 && $this->setting($payment_method['code'],$payment_method['code'].'_total') > $total) {
                    $status = false;
                } elseif (!$this->setting($payment_method['code'],$payment_method['code'].'_geo_zone_id')) {
                    $status = true;
                } elseif ($query) {
                    $status = true;
                } else {
                    $status = false;
                }

                $method_data = array();

                if ($status && $this->setting($payment_method['code'],$payment_method['code'].'_status')) {
                    $method_data = array(
                        'code'       => $payment_method['code'],
                        'title'      => ucwords(str_replace('_',' ',$payment_method['code'])),
                        'terms'      => '',
                        'sort_order' => $this->setting($payment_method['code'],$payment_method['code'].'_sort_order')
                    );
                    $return_array[] = $method_data;
                }
               
            }
           
            $return_arry = array('status' => '200','payment_method' => $return_array);
            $this->response($this->json($return_arry), 200);
           
        }
       
       
        /*
        * Create order and send order id
        */
       
        private function confirmorder(){
            $return_array = array();
           
            if($this->get_request_method() != 'POST'){
                $return_arry = array('status' => '401','message' => 'Invalid Request Type');
                $this->response($this->json($return_arry), 400);
            }

            //$par = json_encode($_POST);
            //$params = (array)json_decode($par);
           
            $params = (array)json_decode($this->_request,true);
           
            if(empty($params)){
                $return_arry = array('status' => '401','message' => 'Invalid Json format');
                $this->response($this->json($return_arry), 400);
            }
           
            if(!isset($params['language_id']) || $params['language_id'] == ''){
                $return_arry = array('status' => '401','message' => 'Invalid Language Id');
                $this->response($this->json($return_arry), 400);
            } elseif(!isset($params['products']) || empty($params['products'])){
                $return_arry = array('status' => '401','message' => 'Invalid Products');
                $this->response($this->json($return_arry), 400);
            } elseif(!isset($params['payment_address']) || empty($params['payment_address'])){
                $return_arry = array('status' => '401','message' => 'Invalid Payment Address');
                $this->response($this->json($return_arry), 400);
            } elseif(!isset($params['shipping_address']) || empty($params['shipping_address'])){
                $return_arry = array('status' => '401','message' => 'Invalid Shipping Address');
                $this->response($this->json($return_arry), 400);
            } elseif(!isset($params['payment_method']) || empty($params['payment_method'])){
                $return_arry = array('status' => '401','message' => 'Invalid Payment Method');
                $this->response($this->json($return_arry), 400);
            } elseif(!isset($params['shipping_method']) || empty($params['shipping_method'])){
                $return_arry = array('status' => '401','message' => 'Invalid Shipping Method');
                $this->response($this->json($return_arry), 400);
            }else{
                $payment_address = $params['payment_address'];
                $shipping_address = $params['shipping_address'];
                $payment_method = $params['payment_method'];
                $shipping_method = $params['shipping_method'];
                $cart_products = $params['products'];
                $language_id = $params['language_id'];
               
                if(isset($params['voucher'])){
                    $voucher = $params['voucher'];
                }
               
                if(isset($params['coupon'])){
                    $coupon = $params['coupon'];
                }
            }
           
           
            $cart_products = $this->get_cart_products_info($cart_products,$language_id);
           
            $order_data = array();
           
            $order_data['invoice_prefix'] = addslashes($this->setting('config','config_invoice_prefix'));
            $order_data['store_id'] = (int)$this->setting('config','config_store_id');
            $order_data['store_name'] = addslashes($this->setting('config','config_name'));

            if ($order_data['store_id']) {
                $order_data['store_url'] = addslashes($this->setting('config','config_url'));
            } else {
                $order_data['store_url'] = self::WEBURL;
            }
           
            if(isset($params['customer_id']) && $params['customer_id'] != ''){
                $customer_detail = $this->getonerow("SELECT customer_id,customer_group_id,firstname,lastname,email,telephone,fax FROM ".self::DBPREFIX."customer WHERE customer_id = '".$params['customer_id']."' AND status = '1'");
               
                if(!empty($customer_detail)){
                    $order_data['customer_id'] = (int)$customer_detail['customer_id'];
                    $order_data['customer_group_id'] = (int)$customer_detail['customer_group_id'];
                    $order_data['firstname'] = addslashes($customer_detail['firstname']);
                    $order_data['lastname'] = addslashes($customer_detail['lastname']);
                    $order_data['email'] = addslashes($customer_detail['email']);
                    $order_data['telephone'] = addslashes($customer_detail['telephone']);
                    $order_data['fax'] = addslashes($customer_detail['fax']);
                }
            }
           
            if(!isset($order_data['customer_id'])){
                $order_data['customer_id'] = 0;
                $order_data['customer_group_id'] = 0;
                $order_data['firstname'] = addslashes($payment_address['payment_firstname']);
                $order_data['lastname'] = addslashes($payment_address['payment_lastname']);
                $order_data['email'] = addslashes($payment_address['payment_email']);
                $order_data['telephone'] = addslashes($payment_address['payment_telephone']);
                $order_data['fax'] = '';
            }
           
            $order_data['payment_firstname']    = addslashes($payment_address['payment_firstname']);
            $order_data['payment_lastname']     = addslashes($payment_address['payment_lastname']);
            $order_data['payment_company']      = addslashes($payment_address['payment_company']);
            $order_data['payment_address_1']    = addslashes($payment_address['payment_address_1']);
            $order_data['payment_address_2']    = addslashes($payment_address['payment_address_2']);   
            $order_data['payment_city']         = addslashes($payment_address['payment_city']);
            $order_data['payment_postcode']     = addslashes($payment_address['payment_postcode']);
            $order_data['payment_country']      = addslashes($payment_address['payment_country']);
            $order_data['payment_country_id']   = addslashes($payment_address['payment_country_id']);
            $order_data['payment_zone']         = addslashes($payment_address['payment_zone']);
            $order_data['payment_zone_id']      = addslashes($payment_address['payment_zone_id']);
           
            $order_data['payment_method']       = addslashes($payment_method['title']);
            $order_data['payment_code']         = addslashes($payment_method['code']);
           
           
            $order_data['shipping_firstname']    = addslashes($shipping_address['shipping_firstname']);
            $order_data['shipping_lastname']     = addslashes($shipping_address['shipping_lastname']);
            $order_data['shipping_company']      = addslashes($shipping_address['shipping_company']);
            $order_data['shipping_address_1']    = addslashes($shipping_address['shipping_address_1']);
            $order_data['shipping_address_2']    = addslashes($shipping_address['shipping_address_2']);   
            $order_data['shipping_city']         = addslashes($shipping_address['shipping_city']);
            $order_data['shipping_postcode']     = addslashes($shipping_address['shipping_postcode']);
            $order_data['shipping_country']      = addslashes($shipping_address['shipping_country']);
            $order_data['shipping_country_id']   = addslashes($shipping_address['shipping_country_id']);
            $order_data['shipping_zone']         = addslashes($shipping_address['shipping_zone']);
            $order_data['shipping_zone_id']      = addslashes($shipping_address['shipping_zone_id']);
           
            $order_data['shipping_method']       = addslashes($shipping_method['title']);
            $order_data['shipping_code']         = addslashes($shipping_method['code']);
           
            $order_data['language_id']         = (int)$language_id;
           
            $currency_id = $this->getonerow("SELECT * FROM ".self::DBPREFIX."currency WHERE code = '".$this->setting('config','config_currency')."'");
           
            if(!empty($currency_id)){
                $order_data['currency_id'] = (int)$currency_id['currency_id'];
                $order_data['currency_code'] = addslashes($currency_id['code']);
                $order_data['currency_value'] = addslashes($currency_id['value']);
            }
           
            $query = "INSERT INTO ".self::DBPREFIX."order SET ";
            foreach($order_data as $key => $value){
                $query .= $key." = '".$value."', ";
            }
            $query .= "date_added = NOW(),";
            $query .= "date_modified = NOW()";
           
            $order_id = $this->insert($query);
           
            $order_data['products'] = array();

            foreach ($cart_products as $product) {
                $option_data = array();

                foreach ($product['option'] as $option) {
                    $option_data[] = array(
                        'product_option_id'       => $option['product_option_id'],
                        'product_option_value_id' => $option['product_option_value_id'],
                        'option_id'               => $option['option_id'],
                        'option_value_id'         => $option['option_value_id'],
                        'name'                    => $option['name'],
                        'value'                   => $option['value'],
                        'type'                    => $option['type']
                    );
                }
               
                $tax = $this->taxcalculation($product['price'], $product['tax_class_id'],$payment_address,$shipping_address);
               
                $order_data['products'][] = array(
                    'product_id' => $product['product_id'],
                    'name'       => $product['name'],
                    'model'      => $product['model'],
                    'option'     => $option_data,
                    'download'   => $product['download'],
                    'quantity'   => $product['quantity'],
                    'subtract'   => $product['subtract'],
                    'price'      => $product['price'],
                    'total'      => $product['total'],
                    'tax'        => $tax['tax'],
                    'reward'     => $product['reward']
                );
            }
           
            foreach ($order_data['products'] as $product) {
               
                /*$vendor_sql = $this->getonerow("SELECT v.vendor_id,v.commission_id,c.commission_type,c.commission FROM `oc_vendors` v INNER JOIN oc_vendor vp ON (v.vendor_id = vp.vendor) INNER JOIN oc_commission c ON (c.commission_id = v.commission_id) WHERE `vproduct_id` = '" . (int)$product['product_id'] . "'");
               
                if($vendor_sql['commission_type'] == 0){
                    $commission = $product['total'] * $vendor_sql['commission'] / 100;
                    $vendor_total = $product['total'] - $commission;
                } elseif($vendor_sql['commission_type'] > 0){
                    $commission = $vendor_sql['commission'];
                    $vendor_total = $product['total'] - $commission;
                } else{
                    $commission = 0;
                    $vendor_total = 0;
                }*/
               
                $order_product_id = $this->insert("INSERT INTO " . self::DBPREFIX . "order_product SET order_id = '" . (int)$order_id . "', product_id = '" . (int)$product['product_id'] . "', name = '" . addslashes($product['name']) . "', model = '" . addslashes($product['model']) . "', quantity = '" . (int)$product['quantity'] . "', price = '" . (float)$product['price'] . "', total = '" . (float)$product['total'] . "', tax = '" . (float)$product['tax'] . "', reward = '" . (int)$product['reward'] . "'");
               
                //,vendor_id = '".$vendor_sql['vendor_id']."',commission = '".$commission."',vendor_total = '".$vendor_total."'

                foreach ($product['option'] as $option) {
                    $this->insert("INSERT INTO " . self::DBPREFIX . "order_option SET order_id = '" . (int)$order_id . "', order_product_id = '" . (int)$order_product_id . "', product_option_id = '" . (int)$option['product_option_id'] . "', product_option_value_id = '" . (int)$option['product_option_value_id'] . "', name = '" . addslashes($option['name']) . "', `value` = '" . addslashes($option['value']) . "', `type` = '" . addslashes($option['type']) . "'");
                }
            }
           
            $sub_total = 0;
            foreach($cart_products as $cart_product){
                $sub_total += $cart_product['total'];
            }
           
            $order_totals = $this->getallrows("SELECT * FROM ".self::DBPREFIX."extension WHERE type = 'total'");
            $sort_order = array();
            foreach($order_totals as $key => $order_total){
                $sort_order[$key] = $this->setting($order_total['code'],$order_total['code'] . '_sort_order');
            }
           
            array_multisort($sort_order, SORT_ASC, $order_totals);
           
            $ordertotal = 0;
            $order_taxes = array();
            $order_total_data = array();
           
            foreach($order_totals as $order_total){
                $setting_code = $order_total['code'];
                $setting_key = $order_total['code'] . '_status';
                if($this->setting($setting_code,$setting_key)){
                    if($order_total['code'] == 'handling' && ($sub_total < $this->setting('handling','handling_total')) && $sub_total > 0){
                        $order_total_data[] = array(
                            'code'       => 'handling',
                            'title'      => 'Handling Fee',
                            'value'      => $this->setting('handling','handling_fee'),
                            'sort_order' => $this->setting('handling','handling_sort_order')
                        );

                        if ($this->setting('handling','handling_tax_class_id')) {
                            $tax_rates = $this->taxcalculation($this->setting('handling','handling_fee'), $this->setting('handling','handling_tax_class_id'),$payment_address,$shipping_address,true);
                           
                            foreach ($tax_rates['tax_rate_data'] as $tax_rate) {
                                if (!isset($order_taxes[$tax_rate['tax_rate_id']])) {
                                    $order_taxes[$tax_rate['tax_rate_id']] = $tax_rate['amount'];
                                } else {
                                    $order_taxes[$tax_rate['tax_rate_id']] += $tax_rate['amount'];
                                }
                            }
                        }

                        $ordertotal += $this->setting('handling','handling_fee');
                    } else if($order_total['code'] == 'sub_total'){
                        $order_total_data[] = array(
                            'code'       => 'sub_total',
                            'title'      => 'Sub Total',
                            'value'      => $sub_total,
                            'sort_order' => $this->setting('sub_total','sub_total_sort_order')
                        );

                        $ordertotal += $sub_total;
                    } elseif($order_total['code'] == 'shipping'){
                        $order_total_data[] = array(
                            'code'       => 'shipping',
                            'title'      => $shipping_method['title'],
                            'value'      => $shipping_method['cost'],
                            'sort_order' => $shipping_method['sort_order']
                        );
                       
                        if ($shipping_method['tax_class_id']) {
                            $tax_rates = $this->taxcalculation($shipping_method['cost'], $shipping_method['tax_class_id'],$payment_address,$shipping_address);
                           
                            foreach ($tax_rates['tax_rate_data'] as $tax_rate) {
                                if (!isset($order_taxes[$tax_rate['tax_rate_id']])) {
                                    $order_taxes[$tax_rate['tax_rate_id']] = $tax_rate['amount'];
                                } else {
                                    $order_taxes[$tax_rate['tax_rate_id']] += $tax_rate['amount'];
                                }
                            }
                        }

                        $ordertotal += $shipping_method['cost'];
                    } elseif($order_total['code'] == 'coupon' && isset($coupon) && $coupon != ''){
                        $coupon_query = $this->getonerow("SELECT * FROM `" . self::DBPREFIX . "coupon` WHERE code = '" . addcslashes($coupon) . "' AND ((date_start = '0000-00-00' OR date_start < NOW()) AND (date_end = '0000-00-00' OR date_end > NOW())) AND status = '1'");
                        if($coupon_query){
                            if ($coupon_query['total'] > $sub_total) {
                                $status = false;
                            }
                           
                            $coupon_history_query = $this->getonerow("SELECT COUNT(*) AS total FROM `" . self::DBPREFIX . "coupon_history` ch WHERE ch.coupon_id = '" . (int)$coupon_query['coupon_id'] . "'");

                            if ($coupon_query['uses_total'] > 0 && ($coupon_history_query['total'] >= $coupon_query['uses_total'])) {
                                $status = false;

                            }

                            if ($coupon_query['logged'] && (!isset($params['customer_id']) || $params['customer_id'] == '')) {
                                $status = false;
                            }

                            if (isset($params['customer_id']) && $params['customer_id'] != '') {
                                $coupon_history_query = $this->getonerow("SELECT COUNT(*) AS total FROM `" . self::DBPREFIX . "coupon_history` ch WHERE ch.coupon_id = '" . (int)$coupon_query['coupon_id'] . "' AND ch.customer_id = '" . (int)$params['customer_id'] . "'");

                                if ($coupon_query['uses_customer'] > 0 && ($coupon_history_query['total'] >= $coupon_query['uses_customer'])) {
                                    $status = false;
                                }
                            }
                           
                            if ($coupon_query->row['couponvalid'] == '2') {
                                $status = false;
                            }
                           
                            $coupon_product_data = array();

                            $coupon_product_query = $this->getallrows("SELECT * FROM `" . self::DBPREFIX . "coupon_product` WHERE coupon_id = '" . (int)$coupon_query['coupon_id'] . "'");

                            foreach ($coupon_product_query as $product) {
                                $coupon_product_data[] = $product['product_id'];
                            }

                            // Categories
                            $coupon_category_data = array();

                            $coupon_category_query = $this->getallrows("SELECT * FROM `" . self::DBPREFIX . "coupon_category` cc LEFT JOIN `" . self::DBPREFIX . "category_path` cp ON (cc.category_id = cp.path_id) WHERE cc.coupon_id = '" . (int)$coupon_query['coupon_id'] . "'");

                            foreach ($coupon_category_query as $category) {
                                $coupon_category_data[] = $category['category_id'];
                            }

                            $product_data = array();

                            if ($coupon_product_data || $coupon_category_data) {
                                foreach ($this->cart->getProducts() as $product) {
                                    if (in_array($product['product_id'], $coupon_product_data)) {
                                        $product_data[] = $product['product_id'];

                                        continue;
                                    }

                                    foreach ($coupon_category_data as $category_id) {
                                        $coupon_category_query = $this->getonerow("SELECT COUNT(*) AS total FROM `" . self::DBPREFIX . "product_to_category` WHERE `product_id` = '" . (int)$product['product_id'] . "' AND category_id = '" . (int)$category_id . "'");

                                        if ($coupon_category_query->row['total']) {
                                            $product_data[] = $product['product_id'];

                                            continue;
                                        }
                                    }
                                }

                                if (!$product_data) {
                                    $status = false;
                                }
                            }
                        } else {
                            $status = false;
                        }
                        if ($status) {
                            $coupon_info = array(
                                'coupon_id'     => $coupon_query['coupon_id'],
                                'code'          => $coupon_query['code'],
                                'name'          => $coupon_query['name'],
                                'type'          => $coupon_query['type'],
                                'discount'      => $coupon_query['discount'],
                                'shipping'      => $coupon_query['shipping'],
                                'total'         => $coupon_query['total'],
                                'product'       => $product_data,
                                'date_start'    => $coupon_query['date_start'],
                                'date_end'      => $coupon_query['date_end'],
                                'uses_total'    => $coupon_query['uses_total'],
                                'uses_customer' => $coupon_query['uses_customer'],
                                'status'        => $coupon_query['status'],
                                'date_added'    => $coupon_query['date_added']
                            );
                           
                            $discount_total = 0;

                            if (!$coupon_info['product']) {
                                $subtotal = $sub_total;
                            } else {
                                $subtotal = 0;

                                foreach ($cart_products as $product) {
                                    if (in_array($product['product_id'], $coupon_info['product'])) {
                                        $subtotal += $product['total'];
                                    }
                                }
                            }

                            if ($coupon_info['type'] == 'F') {
                                $coupon_info['discount'] = min($coupon_info['discount'], $subtotal);
                            }

                            foreach ($cart_products as $product) {
                                $discount = 0;

                                if (!$coupon_info['product']) {
                                    $status = true;
                                } else {
                                    if (in_array($product['product_id'], $coupon_info['product'])) {
                                        $status = true;
                                    } else {
                                        $status = false;
                                    }
                                }

                                if ($status) {
                                    if ($coupon_info['type'] == 'F') {
                                        $discount = $coupon_info['discount'] * ($product['total'] / $subtotal);
                                    } elseif ($coupon_info['type'] == 'P') {
                                        $discount = $product['total'] / 100 * $coupon_info['discount'];
                                    }

                                    if ($product['tax_class_id']) {
                                        $tax_rates = $this->taxcalculation($product['total'] - ($product['total'] - $discount), $product['tax_class_id'],$payment_address,$shipping_address);

                                        foreach ($tax_rates['tax_rate_data'] as $tax_rate) {
                                            if ($tax_rate['type'] == 'P') {
                                                $order_taxes[$tax_rate['tax_rate_id']] -= $tax_rate['amount'];
                                            }
                                        }
                                    }
                                }

                                $discount_total += $discount;
                            }

                            if ($coupon_info['shipping'] && isset($shipping_method)) {
                                if (!empty($shipping_method['tax_class_id'])) {
                                    $tax_rates = $this->taxcalculation($shipping_method['cost'], $shipping_method['tax_class_id'],$payment_address,$shipping_address);

                                    foreach ($tax_rates['tax_rate_data'] as $tax_rate) {
                                        if ($tax_rate['type'] == 'P') {
                                            $order_taxes[$tax_rate['tax_rate_id']] -= $tax_rate['amount'];
                                        }
                                    }
                                }

                                $discount_total += $shipping_method['cost'];
                            }

                            // If discount greater than total
                            if ($discount_total > $ordertotal) {
                                $discount_total = $ordertotal;
                            }

                            $order_total_data[] = array(
                                'code'       => 'coupon',
                                'title'      => 'Coupon',
                                'value'      => -$discount_total,
                                'sort_order' => $this->setting('coupon','coupon_sort_order')
                            );

                            $ordertotal -= $discount_total;
                        }
                    } elseif($order_total['code'] == 'tax'){
                        foreach ($order_taxes as $key => $value) {
                            $tax_query = $this->getonerow("SELECT name FROM " . self::DBPREFIX . "tax_rate WHERE tax_rate_id = '" . (int)$key . "'");
                            if ($tax_query) {
                                $name = $tax_query['name'];
                            } else {
                                $name = '';
                            }
                            if ($value > 0) {
                                $order_total_data[] = array(
                                    'code'       => 'tax',
                                    'title'      => $name,
                                    'value'      => $value,

                                    'sort_order' => $this->setting('tax','tax_sort_order')
                                );
                                $ordertotal += $value;
                            }
                        }
                    } elseif($order_total['code'] == 'voucher' && isset($voucher) && $voucher != ''){
                        $status = true;
                        $amount = 0;
                        $voucher_query = $this->getonerow("SELECT *, vtd.name AS theme FROM " . self::DBPREFIX . "voucher v LEFT JOIN " . self::DBPREFIX . "voucher_theme vt ON (v.voucher_theme_id = vt.voucher_theme_id) LEFT JOIN " . self::DBPREFIX . "voucher_theme_description vtd ON (vt.voucher_theme_id = vtd.voucher_theme_id) WHERE v.code = '" . addcslashes($voucher) . "' AND vtd.language_id = '" . (int)$language_id . "' AND v.status = '1'");

                        if ($voucher_query) {
                            if ($voucher_query['order_id']) {
                                $implode = array();

                                foreach ($this->setting('config','config_complete_status') as $order_status_id) {
                                    $implode[] = "'" . (int)$order_status_id . "'";
                                }

                                $order_query = $this->getallrows("SELECT * FROM `" . self::DBPREFIX . "order` WHERE order_id = '" . (int)$voucher_query['order_id'] . "' AND order_status_id IN(" . implode(",", $implode) . ")");

                                if (!$order_query) {
                                    $status = false;
                                }

                                $order_voucher_query = $this->getonerow("SELECT * FROM `" . self::DBPREFIX . "order_voucher` WHERE order_id = '" . (int)$voucher_query['order_id'] . "' AND voucher_id = '" . (int)$voucher_query['voucher_id'] . "'");

                                if (!$order_voucher_query) {
                                    $status = false;
                                }
                            }

                            $voucher_history_query = $this->getonerow("SELECT SUM(amount) AS total FROM `" . self::DBPREFIX . "voucher_history` vh WHERE vh.voucher_id = '" . (int)$voucher_query['voucher_id'] . "' GROUP BY vh.voucher_id");

                            if ($voucher_history_query) {
                                $amount = $voucher_query['amount'] + $voucher_history_query['total'];
                            } else {
                                $amount = $voucher_query['amount'];
                            }

                            if ($amount <= 0) {
                                $status = false;
                            }
                        } else {
                            $status = false;
                        }

                        if ($status) {
                            $voucher_info =  array(
                                'voucher_id'       => $voucher_query['voucher_id'],
                                'code'             => $voucher_query['code'],
                                'from_name'        => $voucher_query['from_name'],
                                'from_email'       => $voucher_query['from_email'],
                                'to_name'          => $voucher_query['to_name'],
                                'to_email'         => $voucher_query['to_email'],
                                'voucher_theme_id' => $voucher_query['voucher_theme_id'],
                                'theme'            => $voucher_query['theme'],
                                'message'          => $voucher_query['message'],
                                'image'            => $voucher_query['image'],
                                'amount'           => $amount,
                                'status'           => $voucher_query['status'],
                                'date_added'       => $voucher_query['date_added']
                            );
                           
                            $amount = 0;
                           
                            if ($voucher_info['amount'] > $ordertotal) {
                                $amount = $ordertotal;
                            } else {
                                $amount = $voucher_info['amount'];
                            }

                            $order_total_data[] = array(
                                'code'       => 'voucher',
                                'title'      => sprintf('Voucher', $voucher),
                                'value'      => -$amount,
                                'sort_order' => $this->config->get('voucher_sort_order')
                            );

                            $ordertotal -= $amount;
                           
                            $insert_query = "INSERT INTO `" . self::DBPREFIX . "voucher_history` SET voucher_id = '" . (int)$voucher_info['voucher_id'] . "', order_id = '" . (int)$order_id . "', amount = '" . (float)-$amount . "', date_added = NOW()";
                            mysql_query($insert_query);
                        }
                    } elseif($order_total['code'] == 'total'){
                        $order_total_data[] = array(
                            'code'       => 'total',
                            'title'      => 'Total',
                            'value'      => max(0, $ordertotal),
                            'sort_order' => $this->setting('total','total_sort_order')
                        );
                    }
                }
            }
           
            $return_array = array();
            $return_array['order_id'] = $order_id;
            $return_array['total'] = $ordertotal;
            $j = 0;
            foreach($cart_products as $product){
                $return_array['products'][$j]['name'] = html_entity_decode($product['name']);
                $return_array['products'][$j]['quantity'] = $product['quantity'];
                $return_array['products'][$j]['unit_price'] = $this->currencyformat($product['price']);
                $return_array['products'][$j]['total'] = $this->currencyformat($product['total']);
                $j++;
            }
           
            if (isset($order_total_data) && !empty($order_total_data)) {
                $i = 0;
                foreach ($order_total_data as $total_data) {
                    $return_array['totals'][$i]['title'] = $total_data['title'];
                    $return_array['totals'][$i]['value'] = $this->currencyformat($total_data['value']);
                    $this->insert("INSERT INTO " . self::DBPREFIX . "order_total SET order_id = '" . (int)$order_id . "', code = '" . addslashes($total_data['code']) . "', title = '" . addslashes($total_data['title']) . "', `value` = '" . (float)$total_data['value'] . "', sort_order = '" . (int)$total_data['sort_order'] . "'");
                    $i++;
                }
            }
           
            $oder_total_update = "UPDATE " . self::DBPREFIX . "order SET total = '".$ordertotal."' WHERE order_id = '".$order_id."'";
            mysql_query($oder_total_update);
           
            $return_arry = array('status' => '200','order_info' => $return_array);

            $this->response($this->json($return_arry), 200);
        }
       
        /*
        * Place order
        */
       
        private function place_order(){
            if($this->get_request_method() != 'POST'){
                $return_arry = array('status' => '401','message' => 'Invalid Request Type');
                $this->response($this->json($return_arry), 400);
            }

            //$par = json_encode($_POST);
            //$params = (array)json_decode($par);
           
            $params = (array)json_decode($this->_request,true);
           
            if(empty($params)){
                $return_arry = array('status' => '401','message' => 'Invalid Json format');
                $this->response($this->json($return_arry), 400);
            } elseif(!isset($params['order_id']) || $params['order_id'] == ''){
                $return_arry = array('status' => '401','message' => 'Invalid Order Id');
                $this->response($this->json($return_arry), 400);
            } elseif(!isset($params['order_status_id']) || $params['order_status_id'] == ''){
                $return_arry = array('status' => '401','message' => 'Invalid Order Status Id');
                $this->response($this->json($return_arry), 400);
            }
           
            $ordersql = $this->getonerow("SELECT COUNT(*) as total FROM ".self::DBPREFIX."order WHERE order_id = '".$params['order_id']."'");
            if($ordersql['total'] <= 0){
                $return_arry = array('status' => '401','message' => 'Invalid Order Id');
                $this->response($this->json($return_arry), 400);
            }
           
            if($params['order_status_id'] == 1){
                $update_query = "UPDATE ".self::DBPREFIX."order SET order_status_id = '2' WHERE order_id = '".$params['order_id']."'";
                mysql_query($update_query);
           
                $order_info = $this->getorder_from_order_id($params['order_id']);
               
                if(!empty($order_info)){
                $this->order_mail($order_info['order_id']);
                    $message = "Hi ".$order_info['payment_firstname']."<br />";
                    $message .= "Your Order ".$order_info['order_id']." has been confirmed.";
                   
                    //$this->mail($message,$order_info['email'],'CONTACT@YOURMAILID.com');
                }
                $return_arry = array('status' => '200','order_id' => $params['order_id'],'message' => 'Order is Confirmed');
                $this->response($this->json($return_arry), 200);
            } else{
                $return_arry = array('status' => '401','order_id' => $params['order_id'],'message' => 'Order is Failed');
                $this->response($this->json($return_arry), 200);
            }
           
           
        }
		
		?>