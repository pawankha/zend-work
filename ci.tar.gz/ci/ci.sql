-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 18, 2016 at 11:12 AM
-- Server version: 5.5.49-0ubuntu0.14.04.1
-- PHP Version: 5.6.20-1+deb.sury.org~precise+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ci`
--

-- --------------------------------------------------------

--
-- Table structure for table `de_gallery`
--

CREATE TABLE IF NOT EXISTS `de_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `de_gallery`
--

INSERT INTO `de_gallery` (`id`, `image`, `user_id`, `status`) VALUES
(1, '1450447187_imgo_borndata.jpg', 1, '1'),
(2, '1450447247_output_pdmkBB.gif', 1, '1'),
(3, '1450447338_output_pdmkBB.gif', 1, '1'),
(5, '1450449032', 1, '1'),
(6, '1450449084', 1, '1'),
(7, '1450512882', 1, '1'),
(8, '1450512966', 1, '1');

-- --------------------------------------------------------

--
-- Table structure for table `de_login`
--

CREATE TABLE IF NOT EXISTS `de_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `email` text NOT NULL,
  `address` text NOT NULL,
  `image` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `de_login`
--

INSERT INTO `de_login` (`id`, `username`, `password`, `firstname`, `lastname`, `email`, `address`, `image`) VALUES
(1, 'pawan', '368e3d2acb26483c7db8388fe7ceeac9', 'Pawan', 'Jain', 'pawan@test.com', 'test pawan', '1450512841'),
(17, 'prashant', '21232f297a57a5a743894a0e4a801fc3', 'prashant', 'Asne', 'prashant@test.com', 'on which part you have been working so far?', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
