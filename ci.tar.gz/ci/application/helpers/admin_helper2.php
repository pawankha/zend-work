<?php
function admin_url(){
        $ci=& get_instance();
	//$ci->load->helper('url');
       $admin_url=site_url()."/admin";
       return $admin_url;
   }

function get_subcat($a){

        $ci=& get_instance();
	$ci->load->database(); 
       
         $ci->db->select('*');
       
        $ci->db->where('cat_parentid', $a);
        $ci->db->from('tbl_category');
	$query=$ci->db->get();
        $row =  $query->result_array();
	
  		return $row;


   }
   
   function buildTree(Array $data, $parent = 0) {
    $tree = array();
    foreach ($data as $d) {
        if ($d['cat_parentid'] == $parent) {
            $children = buildTree($data, $d['cat_id']);
            // set a trivial key
            if (!empty($children)) {
                $d['_children'] = $children;
            }
            $tree[] = $d;
        }
    }
    return $tree;
}


function printTree($tree, $r = 0, $p = null) {
    foreach ($tree as $i => $t) {
        $dash = ($t['cat_parentid'] == 0) ? '' : str_repeat('-', $r) .' ';
        printf("\t<option value='%d'>%s%s</option>\n", $t['cat_id'], $dash, $t['cat_name']);
        if ($t['cat_parentid'] == $p) {
            // reset $r
            $r = 0;
        }
        if (isset($t['_children'])) {
            printTree($t['_children'], ++$r, $t['cat_parentid']);
        }
    }
}



function category_tree($catId,$cId,$project_id){

	$ci=& get_instance();
	$ci->load->database();
	if(empty($cId) && $cId!=""){
  $query =  $ci->db->query("SELECT * FROM tbl_category WHERE cat_parentid='".$catId."' and project_id='".$project_id."' and cat_id!='".$cId."' ");
	} else {
  $query =  $ci->db->query("SELECT * FROM tbl_category WHERE cat_parentid='".$catId."' and project_id='".$project_id."' ");
	}
  $category_info= $query->result_array();
	$query1 =  $ci->db->query("SELECT * FROM tbl_category WHERE cat_id='".$cId."' and project_id='".$project_id."' ");
	  $ParentId= $query1->row();
	  print_r($category_info);
?>

<?php
foreach($category_info as $valCat){
			
	  //$query1 =  $ci->db->query("SELECT * FROM tbl_category WHERE cat_id='".$valCat['cat_parentid']."' ");
    //$numRows= $query1->num_rows();			
						if($valCat['cat_parentid']!="0"){
				$catName=str_repeat("-", $valCat['cat_parentid']).$valCat['cat_name'];
				} else {	$catName=$valCat['cat_name']; }
				?><option value="<?php echo $valCat['cat_id'];?>"<?php if(isset($ParentId->cat_parentid) && $ParentId->cat_parentid==$valCat['cat_id']){ echo "selected";}?> ><?php  echo $catName;
				category_tree($valCat['cat_id'],$cId,$project_id);
				echo "</option>";
  }

    }
    
    function decript($str){
      $str1 = base64_decode(urldecode($str));
     //$id=explode("encript", $str1);
     //return $id[1];
     return $str1;
     }
     function encript($id){
      // $en="4321encript";
//$str = urlencode(base64_encode($en.$id));
$str = urlencode(base64_encode($id));
     return $str;
     }
    function get_company_name($a){
		$c_id=decript($a);
        $ci=& get_instance();
	$ci->load->database(); 
       
         $ci->db->select('company_name');
       
        $ci->db->where('id', $c_id);
        $ci->db->from('tbl_company');
	$query=$ci->db->get();
        $row =  $query->row_array();
	return $row;


   }
   
   function get_project_name($a){
		$p_id=decript($a);
        $ci=& get_instance();
	$ci->load->database(); 
       
         $ci->db->select('project_name');
       
        $ci->db->where('project_pid', $p_id);
        $ci->db->from('tbl_project');
	$query=$ci->db->get();
        $row =  $query->row_array();
	return $row;


   }
   function category_tree1($catId,$cId="",$project_id,$category_id=""){

	$ci=& get_instance();
	$ci->load->database();
	if(isset($cId) && $cId!=""){
  $query =  $ci->db->query("SELECT * FROM tbl_category WHERE cat_parentid='".$catId."' and project_id='".$project_id."' and cat_id!='".$cId."' ");
	} else {
  $query =  $ci->db->query("SELECT * FROM tbl_category WHERE cat_parentid='".$catId."' and project_id='".$project_id."' ");
	}
  $category_info= $query->result_array();
	$query1 =  $ci->db->query("SELECT * FROM tbl_category WHERE cat_id='".$cId."' and project_id='".$project_id."' ");
	  $ParentId= $query1->row();
?>

<?php
foreach($category_info as $valCat){
				
	  //$query1 =  $ci->db->query("SELECT * FROM tbl_category WHERE cat_id='".$valCat['cat_parentid']."' ");
    //$numRows= $query1->num_rows();			
				if($valCat['cat_parentid']!="0"){
				$catName="--".$valCat['cat_name'];
				} else {	$catName="-".$valCat['cat_name'];}
				?><option value="<?php echo $valCat['cat_id'];?>" <?php if($category_id==$valCat['cat_id']){ echo "selected";} if($valCat['cat_parentid']!="0"){ if($category_id==$valCat['cat_id']){ echo "selected";} } ?> ><?php  echo $catName;
				category_tree1($valCat['cat_id'],$cId,$project_id);
				echo "</option>";
  }

    }
?>
