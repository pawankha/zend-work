
            
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Dashboard</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="<?php echo base_url(); ?>index.php/Dhasboard">Home</a>
                        </li>
                       
                        <li class="active">
                            <strong>Edit Profile</strong>
                        </li>
                    </ol>
                </div>
               
            </div>
        <div class="wrapper wrapper-content animated fadeInRight">
           
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Edit Profile </h5>
                        



                        </div>
                        <div class="ibox-content">
   <form method="post" class="form-horizontal" action="<?php echo base_url(); ?>index.php/Dashboard/updatePassword" ">
                                <div class="form-group"><label class="col-sm-2 control-label">Old Password</label>
                
                                 
                                    <div class="col-sm-10">
            <input type="password" name="oldpassword" placeholder="Old Password" class="form-control" >
                                  <?php echo form_error('oldpassword'); ?> </div>
                               </div>
 
                                <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-2 control-label"> New Password</label>
                                    <div class="col-sm-10">
           <input type="password" name="newpassword"  placeholder="New Password"    class="form-control">
                                  <?php echo form_error('newpassword'); ?>
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-2 control-label">Confirm Password</label>
                     <div class="col-sm-10">
           <input type="password" name="confirmpassword"  placeholder="Confirm Password"    class="form-control"> 
                                  <?php echo form_error('confirmpassword'); ?>
                                    </div>
                                </div>
                                    
                                
                                 <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <a href="<?php echo base_url(); ?>index.php/Dhasboard">    
                                        <button class="btn btn-white" type="button">Cancel</button></a>
                                       <button class="btn btn-primary" type="submit">Save changes</button> 
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
