<?php $session_data =$this->session->userdata('logged_in');?>

  <div class="row wrapper border-bottom white-bg page-heading">
         <div class="col-lg-10">
                    <h2><?php $project_data=get_project_name(encript($project_id)); echo "Project Name: ".$project_data['project_name'] ?></h2>
                    <ol class="breadcrumb">
		       <li>
                       Dashboard
                        </li>
                        <li>
                       Project
                        </li>
                        <li class="active">
                          <strong> Manage Project</strong>
                        </li>
                       
                       <!-- <li class="active">
                            <strong><?php //echo $this->lang->line('add_new_user'); ?></strong>
                        </li>-->
                    </ol>
                </div>
  </div>
 <div class="wrapper wrapper-content">
        <div class="row">
                

 <a href="<?php echo base_url(); ?>index.php/recipe/getrecipes/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">
<div class="col-lg-3">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                
                                <h5>Recipe</h5>
                            </div>
                            <div class="ibox-content">
                                <h1 class="no-margins"><?php if($count_recipe!=""){ echo $count_recipe;}else{ echo "0"; } ?></h1>
                               
                                <small>Total Recipe</small>
                            </div>
                        </div>
                    </div>
</a>

                   <a href="<?php echo base_url(); ?>index.php/Category/getCategory/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">
                    <div class="col-lg-3">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                             
                                <h5>Category</h5>
                            </div>
                            <div class="ibox-content">
                                <h1 class="no-margins"><?php if($count_category!=""){ echo $count_category;}else{ echo "0"; } ?></h1>
                      
                                <small>Total Category</small>
                            </div>
                        </div>
                    </div></a>
		    <a href="<?php echo base_url(); ?>index.php/supplier/getSupplier/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">
                    <div class="col-lg-3">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                             
                                <h5>Supplier</h5>
                            </div>
                            <div class="ibox-content">
                                <h1 class="no-margins"><?php if($count_supplier!=""){ echo $count_supplier;}else{ echo "0"; } ?></h1>
                      
                                <small>Total Supplier</small>
                            </div>
                        </div>
                    </div></a>
		     <a href="<?php echo base_url(); ?>index.php/Pricingtires/getTier/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">
                    <div class="col-lg-3">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                             
                                <h5>Pricing Tier</h5>
                            </div>
                            <div class="ibox-content">
                                <h1 class="no-margins"><?php if($count_tier!=""){ echo $count_tier;}else{ echo "0"; } ?></h1>
                      
                                <small>Total Pricing Tier</small>
                            </div>
                        </div>
                    </div></a>
		   
                 
            </div>
        </div>
