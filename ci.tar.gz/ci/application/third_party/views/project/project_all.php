            <div class="row wrapper border-bottom white-bg page-heading">
         <div class="col-lg-10">
                    <h2><?php $company_data=get_company_name(encript($company_id)); echo "Company Name: ".$company_data['company_name'] ?></h2>
                    <ol class="breadcrumb">
		       <li>
                       Dashboard
                        </li>
                        <li class="active">
                            <a href="#"><?php echo $this->lang->line('project'); ?></a>
                        </li>
                       
                       <!-- <li class="active">
                            <strong><?php //echo $this->lang->line('add_new_user'); ?></strong>
                        </li>-->
                    </ol>
                </div>
  </div>
	    <div class="wrapper wrapper-content animated fadeInRight">  
       <?php
	  $message = $this->session->flashdata('item');
if($message!="") {

  ?>
<div class="alert <?php echo $message['class']; ?>">
<button type="button" class="close close-sm" data-dismiss="alert">
                                    <i class="fa fa-times"></i>
                                </button>
<?php echo $message['message']; ?></div>
<?php
}
?>      <form  action="<?php echo base_url(); ?>index.php/Project/Deleteall" method="post"/>
       <input type="hidden" name="companyid" value="<?php echo encript($company_id); ?>" /> 
          <div class="row">
            <div class="col-lg-12">
            <div class="ibox float-e-margins">
            <div class="ibox-title">
                <h5> <?php echo $this->lang->line('project'); ?> </h5>
                
            </div>
            <div class="ibox-content">
           	 <?php 
		 $session_data=$this->session->userdata('logged_in');
      if($session_data['user_type']==2 || $session_data['user_type']==1){
	 ?> <div class="">
            <a  class="btn btn-primary" href="<?php echo base_url(); ?>index.php/Project/Addproject/<?php echo encript($company_id); ?>"><?php echo $this->lang->line('add new project'); ?> </a>
<button type="submit" value="submit"  id="delete" disabled="disabled" onclick="return confirm('Are you sure you want to delete this ?')" class="btn btn-primary">Delete All Selected</button>
            </div>
	    <?php } ?>
						
            <table class="table table-striped table-bordered table-hover " id="editable" >
            <thead>
            <tr><th><?php if(count($projects)>0){ ?><input type="checkbox" class="i-checks checkall"><?php } ?> </th>
                <th><?php echo $this->lang->line('serial no'); ?> </th>
                <th><?php echo $this->lang->line('project name'); ?></th>
			 <?php 
		 $session_data=$this->session->userdata('logged_in');
      if($session_data['user_type']==2 || $session_data['user_type']==1){
	 ?>
                <th><?php echo $this->lang->line('project status'); ?></th>
          
	 <?php } ?>
                 <th>Action</th>
                
            </tr>
            </thead>
            <tbody>
         
<?php

$i=1;
 foreach($projects as $projectinfo)
 {
	?>    <tr class="gradeX">
              <input type="hidden" name="companyid" value="<?php echo encript($company_id); ?>" /> 
          <td><input type="checkbox"    class="i-checks"    name="delete[]" value="<?php  echo $projectinfo['project_pid'];?>"></td>
               <td><?php  echo $i ?></td>
                <td><?php echo  $projectinfo['project_name'];?></td>
			 <?php 
		 $session_data=$this->session->userdata('logged_in');
      if($session_data['user_type']==2 || $session_data['user_type']==1){
	 ?>	
                 <td class="center">
<?php if ($projectinfo['project_status']==1)
{?>
<a href="<?php echo base_url(); ?>index.php/Project/Deactiveproject/<?php echo encript($projectinfo['project_pid']);?>/<?php echo encript($company_id) ?>"><span class="label label-primary"><?php echo $this->lang->line('active'); ?></span></a>

 <?php }
else
{  ?> <a href="<?php echo base_url(); ?>index.php/Project/Activeproject/<?php echo encript($projectinfo['project_pid']);?>/<?php echo encript($company_id) ?>"><span class="label label-default"><?php echo $this->lang->line('deactive'); ?></span></a> <?php }?>

</td>
		 <?php } ?>
                <td class="center">
		  <a  class="btn btn-white btn-sm" href="<?php echo base_url(); ?>index.php/Project/manageProject/<?php echo encript($projectinfo['project_pid']);?>/<?php echo encript($company_id) ?>">
<i class="fa fa-pencil"></i>Manage Project</a>
	 <?php 
		 $session_data=$this->session->userdata('logged_in');
      if($session_data['user_type']==2 || $session_data['user_type']==1){
	 ?>
		  <a  class="btn btn-white btn-sm" href="<?php echo base_url(); ?>index.php/Project/EditProject/<?php echo encript($projectinfo['project_pid']);?>/<?php echo encript($company_id); ?>">
      <i class="fa fa-pencil"></i><?php echo $this->lang->line('edit'); ?></a>
      <a  class="btn btn-white btn-sm" onclick="return confirm('Are you sure you want to delete this item?')"

 href="<?php echo base_url(); ?>index.php/Project/DeleteProject/<?php echo encript($projectinfo['project_pid']);?>/<?php echo encript($company_id) ?>"><?php echo $this->lang->line('delete'); ?></a>
 <a  class="btn btn-white btn-sm" href="<?php echo base_url(); ?>index.php/Project/EditProject/<?php echo encript($projectinfo['project_pid']);?>/<?php echo encript($company_id)."/copy"; ?>">
<i class="fa fa-copy"></i>Copy</a>
 <?php } ?>
                </td>
           </tr>

<?php $i++ ;} ?>

            </table>

            </div>
            </div>
            </div>
            </div>
       </form> 
        </div>
   <div style="clear:both"></div>
  <script src="<?php echo base_url(); ?>assets/js/plugins/iCheck/icheck.min.js"></script>
  <script>
        $(document).ready(function(){
            $('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-green',
                radioClass: 'iradio_square-green',
            });
        });
 $(document).ready(function(){
var checkboxes = $("input[type='checkbox']"),
checkboxes1 = $(".checkall"),
    submitButt = $("#delete");
 $('tbody .iCheck-helper').click(function()
{

    submitButt.attr("disabled", !checkboxes.is(":checked"));

});
 
 //select all//
 $('thead .iCheck-helper').click(function(){
   if (checkboxes1.is(":checked")) {
    $('tbody .i-checks').attr('checked',true);
   $( "tbody .icheckbox_square-green" ).addClass( "checked");
   submitButt.attr("disabled", !checkboxes.is(":checked"));
   }else{
      $('tbody .i-checks').removeAttr('checked'); 
   $( "tbody .icheckbox_square-green" ).removeClass( "checked");
   submitButt.attr("disabled", !checkboxes.is(":checked"));
   }
 //select all//

});
        });
    </script>
