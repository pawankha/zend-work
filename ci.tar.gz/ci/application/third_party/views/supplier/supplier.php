         <div class="wrapper wrapper-content animated fadeInRight">  
       <?php
	  $message = $this->session->flashdata('item');
if($message!="") {

  ?>
<div class="alert <?php echo $message['class']; ?>">
<button type="button" class="close close-sm" data-dismiss="alert">
                                    <i class="fa fa-times"></i>
                                </button>
<?php echo $message['message']; ?></div>
<?php
}
?>      
          <div class="row">
            <div class="col-lg-12">
            <div class="ibox float-e-margins">
            <div class="ibox-title">
                <h5> <?php echo $this->lang->line('supplier'); ?> </h5>
                
            </div>
            <div class="ibox-content">
            <div class="">
            <a  class="btn btn-primary" href="<?php echo base_url(); ?>index.php/Supplier/Addsupplier"><?php echo $this->lang->line('add supplier'); ?> </a>
            </div>
            <table class="table table-striped table-bordered table-hover " id="editable" >
            <thead>
            <tr>
                <th><?php echo $this->lang->line('serial no'); ?> </th>
                <th><?php echo $this->lang->line('supplier name'); ?></th>
								
               <th>Default Markup</th>
							    	<th><?php echo $this->lang->line('Created_by'); ?></th>
                <th></th>
         
                
            </tr>
            </thead>
             <tbody>
 <?php
foreach($supplier_info as $ValProject){
	 foreach($ValProject as $arrVal){
    $getArrVal[]=$arrVal;
	 }
}

foreach($getArrVal as $valUniq){
	$uniqueVal[]=$valUniq['sup_id'];
}

$arrUniq=array_unique($uniqueVal); 
 
$i=1;
 foreach($arrUniq as $catVal)
{
		$supplierinfo=$this->supplier_m->get_suppliername($catVal);
		 $userDetail= $this->supplier_m->get_pusername($supplierinfo->sup_userid);
	?>            
         
    <tr class="gradeX">
               <td><?php echo  $i ;?></td>
                <td><?php echo  $supplierinfo->sup_name;?></td>
                <td><?php echo  $supplierinfo->sup_percentage;?><?php echo "%"; ?></td>
                  <td><?php echo ucfirst($userDetail->user_fname)." ".ucfirst($userDetail->user_lname);?></td>             

                <td class="center"><a  class="btn btn-white btn-sm" href="<?php echo base_url(); ?>index.php/Supplier/Editsupplier/<?php echo $supplierinfo->sup_id; ?>">
<i class="fa fa-pencil"></i><?php echo $this->lang->line('edit'); ?></a>
               <a  class="btn btn-white btn-sm" onclick="return confirm('Are you sure you want to delete this item?')"

 href="<?php echo base_url(); ?>index.php/Supplier/Deletesupplier/<?php echo $supplierinfo->sup_id;?>"><?php echo $this->lang->line('delete'); ?></a>
                </td>
           </tr>
<?php $i++;}?>


             
                </tbody>
            
            
            </table>

            </div>
            </div>
            </div>
            </div>
        </div>
