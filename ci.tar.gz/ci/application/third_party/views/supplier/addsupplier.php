<?php
if(!empty($sId) && $action==""){

 $action="updateSupplier/".encript($project_id)."/".encript($company_id);
 
} else {
 $action="submitSupplier/".encript($project_id)."/".encript($company_id);
}
?>
              <div class="row wrapper border-bottom white-bg page-heading">
         <div class="col-lg-10">
                    <h2><?php $project_data=get_project_name(encript($project_id)); echo "Project Name: ".$project_data['project_name'] ?></h2>
                    <ol class="breadcrumb">
		       <li>
                       Dashboard
                        </li>
                        <li>
                         <a href="<?php echo base_url(); ?>index.php/supplier/getSupplier/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">Supplier </a>
                        </li>
                        <li class="active">
                          <strong> <?php
                           if($sId==0){
                          echo $this->lang->line('add supplier'); 
                            
                         } else {
                          echo $this->lang->line('edit supplier'); 
               
                             }
                         ?> </strong>
                        </li>
                        <!-- <li class="active">
                            <strong><?php //echo $this->lang->line('add_new_user'); ?></strong>
                        </li>-->
                    </ol>
                </div>
  </div>
        <div class="wrapper wrapper-content animated fadeInRight">
           
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5><?php
                           if($sId==0){
                          echo $this->lang->line('add supplier'); 
                            
                         } else {
                          echo $this->lang->line('edit supplier'); 
               
                             }
                         ?>  </h5>
                        



                        </div>
                        <div class="ibox-content">
   <form method="post" id="addsupform" class="form-horizontal" action="<?php echo site_url(); ?>/Supplier/<?php echo $action; ?>" >
                           <input type="hidden" name="supid" value="<?php if(!empty($supplier_info['sup_id'])){ echo  encript($supplier_info['sup_id']);} ?>"/>
                            <input type="hidden" name="project_id" value="<?php if(!empty($project_id)){ echo  encript($project_id);} ?>"/>
                             <input type="hidden" name="company_id" value="<?php if(!empty($company_id)){ echo  encript($company_id);} ?>"/>
                                 <div class="hr-line-dashed"></div>
                              <div class="form-group"><label class="col-sm-2 control-label"><?php echo $this->lang->line('supplier name'); ?></label>
                    
                                    <div class="col-lg-4">
           
            <input type="text" name="sup_name" placeholder="Supplier Name" class="form-control" required=""
                value="<?php if(!empty($supplier_info['sup_id'])){ echo  $supplier_info['sup_name'];} ?>"></div>
                                </div>
               <div class="hr-line-dashed"></div>
               <div class="form-group"><label class="col-sm-2 control-label">Default Markup</label>
                    
                                    <div class="col-lg-4">
            <input  name="sup_percentage" placeholder="Default Markup" class="form-control" type="number" min="0"  
                value="<?php if(!empty($supplier_info['sup_id'])){ echo  $supplier_info['sup_percentage'];} ?>"></div>
                                </div>
                 
                  
                               <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <a href="<?php echo base_url(); ?>index.php/supplier/getSupplier/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">    
                                        <button class="btn btn-white" type="button">Cancel</button></a>
                                       <button class="btn btn-primary" type="submit">Save changes</button> 
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<script>
 $().ready(function() {
 $("#addsupform").validate();
 });
</script>
