<?php $session_data =$this->session->userdata('logged_in'); ?> 
<style>
 .divtop{
  margin-top:10px;
 }
</style>
           <script >

 //function addfield() {
 //       var scntDiv = $('#p_scents');
 //       var i = $('#p_scents p').size() + 1;
 //       
 //       
 //               $('<p><label for="p_scnts"><input type="text" id="p_scnt" size="20" name="p_scnt_' + i +'" value="" placeholder="Input Value" /></label> <a href="#" onclick="javascript:removefield('+i+');" id="remScnt">Remove</a></p>').appendTo('.maincontent');
 //               i++;
 //               return false;
 //       }
//     $(document).ready(function() {
//    var max_fields      = 10; //maximum input boxes allowed
//    var wrapper         = $(".addfield"); //Fields wrapper
//    var add_button      = $("#addrule"); //Add button ID
//   
//    var x = 1; //initlal text box count
//    $(add_button).click(function(e){ //on add input button click
//        e.preventDefault();
//        if(x < max_fields){ //max input box allowed
//            x++; //text box increment
//            $(wrapper).append('<div class="a-'+x+'"> <div class="form-group"><label class="col-sm-2 control-label"></label><div class="col-lg-4"><select class="form-control"><option>value1</option><option>value2</option></select></div><div class="col-lg-2"><select class="form-control"><option>value1</option><option>value2</option></select></div></div><a href="#" class="remove_field col-lg-2">Remove</a></div>'); 
//        }
//    });
//   
//    $(wrapper).on("click","#removerule", function(e){ //user click on remove text
//        e.preventDefault(); $(this).parent('div').remove(); x--;
//    })
//});
 
$(document).ready(function(){
 
    var counter = 2;
 
    $("#addrule").click(function () {
 
	if(counter>10){
            alert("Only 10 textboxes allow");
            return false;
	}   
 
	var newTextBoxDiv = $(document.createElement('div'))
	     .attr("id", 'TextBoxDiv' + counter);
 
	newTextBoxDiv.after().html(' <div class="form-group"><div class="col-lg-2 divtop"><select class="form-control"  id="sfield'+counter+'" name="sign'+counter+'"><option value="+">plus+</option><option value="-">Minus-</option><option value="*">Times*</option><option value="/">Divided By /</option></select></div><div class="amt_textfield"><div class="col-lg-4 divtop "><select class="form-control" id="field'+counter+'" name="markup'+counter+'" onchange="javascript:textfield('+counter+')"> <option value="Cost Price">Cost Price</option><option value="Product Markup">Product Markup</option><option value="Category Markup">Category Markup</option><option value="Supliers Markup">Supliers Markup</option><option value="Enter Amount">Enter Amount</option><option value="Enter Percentage">Enter Percentage</option><option value="Tax">Tax</option></select><input type="hidden" name="count[]" value="'+counter+'"></div></div><div class="col-lg-2 divtop"><button class="btn btn-primary" id="" type="button" onclick="javascript:removefield('+counter+')">Remove Rule</button></div></div>');
 
	newTextBoxDiv.appendTo(".addfield");
 
 
	counter++;
     });
 

     
     $("#removeButton").click(function () {
	if(counter==2){
          alert("No more textbox to remove");
          return false;
       }   
 
	counter--;
 
        $("#TextBoxDiv" + counter).remove();
 
     });
 
     $("#getButtonValue").click(function () {
 
	var msg = '';
	for(i=1; i<counter; i++){
   	  msg += "\n Textbox #" + i + " : " + $('#textbox' + i).val();
	}
    	  alert(msg);
     });
  });
function textfield(id) {
//alert($('#field' + id).val());
 $('#percentdiv'+id).remove();
   $('#amtdiv'+id).remove();
if ($('#field' + id).val()=="Enter Amount") {
 $('#percentdiv'+id).remove();
 //alert('#TextBoxDiv' + id+ ' .form-group');
 $('#TextBoxDiv' + id+ ' .form-group .amt_textfield').append('<div class="col-lg-3 divtop" id="amtdiv'+id+'"><input type="text" name="amt'+id+'" id="amt'+id+'" value="" placeholder="Amount" class="form-control"></div>');
}
if ($('#field' + id).val()=="Enter Percentage") {
  $('#amtdiv'+id).remove();
 $('#TextBoxDiv' + id+ ' .form-group .amt_textfield').append('<div class="col-lg-3 divtop" id="percentdiv'+id+'"><input type="text" name="percent'+id+'" id="percent'+id+'" value="" placeholder="Percentage" class="form-control"></div>');
}

     };
     function removefield(id) {
      $("#TextBoxDiv" + id).remove();
     }
           </script>
                     <div class="row wrapper border-bottom white-bg page-heading">
         <div class="col-lg-10">
                    <h2><?php $project_data=get_project_name(encript($project_id)); echo "Project Name: ".$project_data['project_name'] ?></h2>
                    <ol class="breadcrumb">
		       <li>
                       Dashboard
                        </li>
                        <li>
                      <a href="<?php echo base_url(); ?>index.php/recipe/getrecipes/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>"> Recipe</a>
                        </li>
                        <li class="active">
                          <strong> Add New Recipe</strong>
                        </li>
                       
                       <!-- <li class="active">
                            <strong><?php //echo $this->lang->line('add_new_user'); ?></strong>
                        </li>-->
                    </ol>
                </div>
          </div>
           
        <div class="wrapper wrapper-content animated fadeInRight">
           
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Add Recipe </h5>
                        
                      </div>
                        <div class="ibox-content">
                        
   <form method="post" class="form-horizontal" id="addrecipeform" action="<?php echo site_url(); ?>/recipe/submitrecipe/<?php echo encript($project_id); ?>/<?php echo encript($company_id); ?>" >
    <input type="hidden" value="<?php echo encript($project_id); ?>" name="project_id" class="form-control" required>
     <input type="hidden" value="<?php echo encript($company_id); ?>" name="company_id" class="form-control" required>
     <div class="form-group">
      <label class="col-sm-2 control-label">Recipe Name</label>
<div class="col-lg-4 ">
<input type="text" value="" name="recipe_name" class="form-control" id="recipe_name" required>
</div>
</div>
     <div class="hr-line-dashed"></div>
            <div style="overflow:hidden">            
            <div class="col-lg-2">
            </div>
            <div class="col-lg-10" style="padding-left: 5px;">
       
           <div class="addfield">
           <div id="TextBoxDiv1">
<div class="form-group">
<div class="amt_textfield">

<div class="col-lg-4 divtop">
<select class="form-control" id="field1" name="markup1" onchange="javascript:textfield(1)">
 <option value="Cost Price">Cost Price</option>
 <option value="Enter Amount">Enter Amount</option>

</select>
<input type="hidden" name="count[]" value="1">
</div>
</div>
</div>
</div>
</div>
<button class="btn btn-primary" id="addrule" type="button">Add Rule</button> 
  </div>  </div>
                               

                               <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <a href="<?php echo base_url(); ?>index.php/recipe/getrecipes/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">    
                                        <button class="btn btn-white" type="button">Cancel</button></a>
                                       <button class="btn btn-primary" type="submit">Save changes</button> 
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<script>
 $().ready(function() {
 $("#addrecipeform").validate({
			rules: {
				recipe_name: "required",
			
				
				
			},
			messages: {
				recipe_name: "Please enter Recipe Title",
				
			}
		});
 });
</script>
