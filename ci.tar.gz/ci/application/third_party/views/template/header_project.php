<?php $session_data =$this->session->userdata('logged_in');?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Pricing App</title>

    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/font-awesome/css/font-awesome.css" rel="stylesheet">
     <link href="<?php echo base_url(); ?>assets/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/plugins/dataTables/dataTables.responsive.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/plugins/dataTables/dataTables.tableTools.min.css" rel="stylesheet">

    <!-- Toastr style -->
    <link href="<?php echo base_url(); ?>assets/css/plugins/toastr/toastr.min.css" rel="stylesheet">

    <!-- Gritter -->
    <link href="<?php echo base_url(); ?>assets/js/plugins/gritter/jquery.gritter.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/plugins/iCheck/custom.css" rel="stylesheet">

    <link href="<?php echo base_url(); ?>assets/css/animate.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet">
<script src="<?php echo base_url(); ?>assets/js/jquery-2.1.1.js"></script>

<script src="<?php echo base_url(); ?>assets/js/plugins/validate/jquery.validate.min.js"></script>

</head>

<body class="fixed-navigation">
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav metismenu" id="side-menu">
                    <li class="nav-header">
                        <div class="dropdown profile-element"> <span>
                     

                    <img alt="image" class="img-circle" width="60px " src="<?php if($user_data->user_image!=""){?><?php echo base_url(); ?>uploads/userimage/<?php echo $user_data->user_image;?><?php }else{?><?php echo base_url(); ?>assets/img/icondp.png<?php } ?>" />
                             </span>
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold"><?php echo ucfirst ($user_data->user_username);?>
</strong>
                             </span> <span class="text-muted text-xs block">Setting <b class="caret"></b></span> </span> </a>
                            <ul class="dropdown-menu animated fadeInRight m-t-xs">
                                <li><a href="<?php echo base_url(); ?>profile/profile"><?php echo $this->lang->line('profile'); ?></a></li>
                              


 <li><a href="<?php echo base_url(); ?>profile/password"><?php echo $this->lang->line('changepassword'); ?></a></li>
                                
                               
                                <li><a href="<?php echo base_url(); ?>index.php/login/logout"><?php echo $this->lang->line('lagout'); ?></a></li>
                            </ul>
                        </div>
                        <div class="logo-element">
                            
                        </div>
                    </li>
                     
                    <li class="active">
                        <a href="<?php echo base_url(); ?>index.php/Dashboard"><i class="glyphicon glyphicon-home"></i> <span class="nav-label"><?php echo "Dashboard"; ?></span> </a>
                       
                    </li>

                 <li >
                 <a href="#"><i class="glyphicon glyphicon-list"></i> <span class="nav-label"><?php echo $this->lang->line('category'); ?></span>
<span class="fa   arrow"></span> </a>
                        <ul class="nav nav-second-level collapse">
                            <li >  <a href="<?php echo base_url(); ?>index.php/Category/getCategory/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>"><?php echo $this->lang->line('category list'); ?></a></li>
                            <li><a href="<?php echo base_url(); ?>index.php/Category/AddCategory/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>"><?php echo $this->lang->line('add category'); ?></a></li>
                            
                        </ul>
                    </li>
<li>
                <a href="#"><i class="fa fa-th-large"></i> <span class="nav-label"><?php echo $this->lang->line('supplier'); ?></span>
<span class="fa   arrow"></span> </a>
                        <ul class="nav nav-second-level collapse">
                            <li >  <a href="<?php echo base_url(); ?>index.php/supplier/getSupplier/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>"><?php echo $this->lang->line('supplier list'); ?></a></li>
                            <li><a href="<?php echo base_url(); ?>index.php/supplier/Addsupplier/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>"><?php echo $this->lang->line('add supplier'); ?></a></li>
                            
                        </ul>
                    </li>
<li>
                <a href="#"><i class="fa fa-th-large"></i> <span class="nav-label">Pricing Tiers</span>
<span class="fa   arrow"></span> </a>
                        <ul class="nav nav-second-level collapse">
                            <li >  <a href="<?php echo base_url(); ?>index.php/Pricingtires/getTier/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">Pricingtiers List</a></li>
                            <li><a href="<?php echo base_url(); ?>index.php/Pricingtires/Addpricingtires/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">Add Pricingtiers</a></li>
                            
                        </ul>
                    </li>
                <li>
                <a href="#"><i class="fa fa-th-large"></i> <span class="nav-label">Recipe</span>
<span class="fa   arrow"></span> </a>
                        <ul class="nav nav-second-level collapse">
                            <li >  <a href="<?php echo base_url(); ?>index.php/recipe/getrecipes/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">Recipe List</a></li>
                            <li><a href="<?php echo base_url(); ?>index.php/recipe/addRecipe/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">Add Recipe</a></li>
                            
                        </ul>
                    </li>
           <li>
                <a href="#"><i class="fa fa-th-large"></i> <span class="nav-label">Product</span>
<span class="fa   arrow"></span> </a>
                        <ul class="nav nav-second-level collapse">
                            <li >  <a href="<?php echo base_url(); ?>index.php/product/getproducts/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">Product List</a></li>
                            <li><a href="<?php echo base_url(); ?>index.php/product/addProduct/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">Add Product</a></li>
                            
                        </ul>
                    </li>
           
            </div>
                </ul>
        </nav>
            </div>
      
        <div id="page-wrapper" class="gray-bg dashbard-1">
    <div class="row border-bottom">
        <nav style="margin-bottom: 0" role="navigation" class="navbar navbar-static-top white-bg">
        <div class="navbar-header">
            <a href="#" class="navbar-minimalize minimalize-styl-2 btn btn-primary "><i class="fa fa-bars"></i> </a>
         
        </div>
            <ul class="nav navbar-top-links navbar-right">
                <li>
                    <span class="m-r-sm text-muted welcome-message"><?php echo $this->lang->line('welcome_to'); ?> <?php echo ucfirst( $user_data->user_username);?>.</span>
                </li>
               
               

                <li>
                    <a href="<?php echo base_url(); ?>index.php/login/logout">
                        <i class="fa fa-sign-out"></i> <?php echo $this->lang->line('logout'); ?>
                    </a>
                </li>
                
            </ul>

        </nav>
        </div>
        
