
            <div class="row wrapper border-bottom white-bg page-heading">
   <?php
	  $message = $this->session->flashdata('item');
if($message!="") {

  ?>
<div class="alert <?php echo $message['class']; ?>">
<button type="button" class="close close-sm" data-dismiss="alert">
                                    <i class="fa fa-times"></i>
                                </button>
<?php echo $message['message']; ?></div>
<?php
}
?>   
                <div class="col-lg-10">
                    <h2><?php echo $this->lang->line('company'); ?></h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="<?php echo base_url(); ?>index.php/Company"><?php echo $this->lang->line('company'); ?></a>
                        </li>
                       
                        <li class="active">
                            <strong><?php if ($company_id==0){echo $this->lang->line('add_new_company');} else{ echo $this->lang->line('edit_company');} ?></strong>
                        </li>
                    </ol>
                </div>
               
            </div>
        <div class="wrapper wrapper-content animated fadeInRight">
           
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5><?php if ($company_id==0){echo $this->lang->line('add_new_company');} else{ echo $this->lang->line('edit_company');} ?></h5>
                            </div>
                        <div class="ibox-content">
   <form method="post" class="form-horizontal" id="companyform" action="<?php echo site_url(); ?>/company/<?php if(!empty($company_id) && $action==""){ echo "updatecompany"; }else{ echo "submitcompany";} ?>" >
    <input type="hidden" name="company_id" class="form-control" value="<?php if(!empty($company_id)){ echo $company_id; } ?>">
                                <div class="form-group"><label class="col-sm-2 control-label"><?php echo $this->lang->line('company_name'); ?></label>
                <div class="col-lg-4">
                             <input type="text" name="company_name" placeholder="Company Name" class="form-control" value="<?php if(!empty($company['company_name'])){ echo $company['company_name']; } ?>" required >
                  </div>
                                 </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-2 control-label"> <?php echo $this->lang->line('company_address'); ?></label>
                                <div class="col-lg-4">
           <input type="text" name="company_address"  placeholder="Company Address" class="form-control" value="<?php if(!empty($company['company_address'])){ echo $company['company_address']; } ?>" required>

                                    </div>
                                </div>
                     <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-2 control-label"> <?php echo $this->lang->line('owner_name'); ?></label>
                                    <div class="col-lg-4">
      <input type="text" name="owner_name"  placeholder="Owner Name" value="<?php if(!empty($company['owner_name'])){ echo $company['owner_name']; } ?>" class="form-control" required >
                                    </div>
                                </div>
                        <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-2 control-label"><?php echo $this->lang->line('status'); ?></label>
                                <div class="col-lg-4">
					  <?php if(!empty($company['status'])){ $status=$company['status']; }else{ $status=""; } ?>
					      <select name="status" class="input-sm form-control input-s-sm inline">
                        <option <?php if($status==1){echo "selected"; }?> value="1">Active</option>
                        <option <?php if($status==0){echo "selected"; }?> value="0">Deactive</option>
                      </select>
                                </div>
                                </div>
              <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <a href="<?php echo base_url(); ?>index.php/Company">    
                                        <button type="button" class="btn btn-white">Cancel</button></a>
                                       <button type="submit" class="btn btn-primary">Save changes</button> 
                                    </div>
                                </div>

	
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<script type="text/javascript">
$().ready(function() {
        // validate the comment form when it is submitted
        $("#companyform").validate();

    });
 
</script>
