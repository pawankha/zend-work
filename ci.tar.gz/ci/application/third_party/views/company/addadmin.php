
            <?php $session_data = $this->session->userdata('logged_in');?>
            <div class="row wrapper border-bottom white-bg page-heading">
   <?php
	  $message = $this->session->flashdata('item');
if($message!="") {

  ?>
<div class="alert <?php echo $message['class']; ?>">
<button type="button" class="close close-sm" data-dismiss="alert">
                                    <i class="fa fa-times"></i>
                                </button>
<?php echo $message['message']; ?></div>
<?php
}
?>   
                <div class="col-lg-10">
                    <h2><?php echo $this->lang->line('user'); ?></h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="<?php echo site_url(); ?>/manageadmin/"><?php echo $this->lang->line('user'); ?></a>
                        </li>
                       
                        <li class="active">
                            <strong><?php echo $this->lang->line('add_new_admin'); ?></strong>
                        </li>
                    </ol>
                </div>
               
            </div>
        <div class="wrapper wrapper-content animated fadeInRight">
           
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5><?php echo $this->lang->line('add_new_admin'); ?> </h5>
                        



                        </div>
			<?php if(!empty($admin_id) && $action==""){
			    $action="update_admin/".encript($company_id)."/".encript($admin_id);
			}else{
			    $action="submit_admin/".encript($company_id);
			}
			?>
                        <div class="ibox-content">
   <form method="post" class="form-horizontal" id="adduserform" action="<?php echo site_url(); ?>/company/<?php echo $action; ?>" >
    <input type="hidden" id="admin_id" name="admin_id" value="<?php if(!empty($admin_id)){ echo encript($admin_id); } ?>"  required >
                                <div class="form-group"><label class="col-sm-2 control-label"><?php echo $this->lang->line('first name'); ?></label>
                
                                 
                                    <div class="col-lg-4">
            <input type="text" id="user_fname" name="user_fname" placeholder="first name" class="form-control" value="<?php if(!empty($admin_info['user_fname'])){ echo $admin_info['user_fname']; } ?>"  required >
                                 </div>
                               </div>
 
                                <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-2 control-label"> <?php echo $this->lang->line('last name'); ?></label>
                                    <div class="col-lg-4">
           <input type="text" name="user_lname"  placeholder="last name" value="<?php if(!empty($admin_info['user_lname'])){ echo $admin_info['user_lname']; } ?>" class="form-control" required >
                        
                                    </div>
                                </div>
                     <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-2 control-label"> <?php echo $this->lang->line('user name'); ?></label>
                                    <div class="col-lg-4">
           <input type="text" id="user_username" name="user_username" value="<?php if(!empty($admin_info['user_username'])){ echo $admin_info['user_username']; } ?>"  onkeyup="userexist();" placeholder="Username"    class="form-control" required >
                                  <p id="result_user" class="error"><input type="hidden" value="0" id="userExist" name="userExist"></p><?php echo form_error('user_username'); ?>
                                    </div>
                                </div>
                        <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-2 control-label"><?php echo $this->lang->line('email'); ?></label>
                                    <div class="col-lg-4">
           <input type="email" name="user_email" id="user_email" placeholder="Email" class="form-control" value="<?php if(!empty($admin_info['user_email'])){ echo $admin_info['user_email']; } ?>" required >
                                
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-2 control-label"><?php echo $this->lang->line('password'); ?></label>
                     <div class="col-lg-4">
           <input type="password" name="user_password" id="<?php if(empty($admin_info['user_password'])){ echo "user_password"; }?>"  placeholder= "Password"    class="form-control" <?php if(empty($admin_info['user_password'])){ echo "required"; }?> > 
                           
                                    </div>
                                </div>
                                    
                                
                                 <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <a href="<?php echo base_url(); ?>Users">    
                                        <button class="btn btn-white" type="button">Cancel</button></a>
                                       <button class="btn btn-primary" type="button" onclick="return submitForm()">Save changes</button> 
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<script type="text/javascript">
 function userexist() {
	
var base_url="<?php echo site_url(); ?>";  
var query_string=$('#user_username').val();
var userId=$('#admin_id').val();
     $.ajax({
         type: "POST",
         url: base_url + "/company/userexist", 
         data: {username: $('#user_username').val()},
         dataType: "text",  
         cache:false,
         success: 
              function(data){
							 	$('#result_user').html(data);
              }
	
			
          });
     			
 };

function submitForm(){
var query_string=$('#userExist').val();

 if (query_string==0) {
   jQuery("#adduserform").submit();
	return true;
 } else {
	return false;
 }


}
$().ready(function() {
 $("#adduserform").validate({
			rules: {
				user_fname: "required",
				user_fname: "required",
				user_username: {
					required: true,
					minlength: 2
				},
				
				user_password: {
				   <?php if(empty($admin_info['user_password'])){?>
					required: true,
					<?php } ?>
					minlength: 6
				},
				
				//confirm_password: {
				//	required: true,
				//	minlength: 6,
				//	equalTo: "#password"
				//},
				email: {
					required: true,
					email: true
				},
				
				
			},
			messages: {
				user_fname: "Please enter your firstname",
				user_lname: "Please enter your lastname",
				user_username: {
					required: "Please enter a username",
					minlength: "Your username must consist of at least 2 characters"
				},
				
				user_password: {
				   <?php if(empty($admin_info['user_password'])){?>
					required: "Please provide a password",
					<?php } ?>
					minlength: "Your password must be at least 6 characters long"
				},
				
				//confirm_password: {
				//	required: "Please provide a password",
				//	minlength: "Your password must be at least 5 characters long",
				//	equalTo: "Please enter the same password as above"
				//},
				user_email: "Please enter a valid email address",
			}
		});
 });
</script>
