<?php
if(!empty($cId) && $action=="")
{
$action="/updateCategory/".encript($project_id)."/".encript($company_id);
} else 
{
$action="/submitCategory/".encript($project_id)."/".encript($company_id); 
$tree = array();
//$rows = $category_info;

//$tree = buildTree($rows);  
}
?>
    
            
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2><?php $project_data=get_project_name(encript($project_id)); echo "Project Name: ".$project_data['project_name'] ?></h2>
                    <ol class="breadcrumb">
                      <li>
                       Dashboard
                        </li>
                        <li>
                            <a  href="<?php echo base_url(); ?>category/getCategory/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>"><?php echo $this->lang->line('category'); ?></a>
                        </li>
                       
                        <li class="active">
                          <strong>  <?php
                           if(!empty($cId)){
                          echo $this->lang->line('edit category'); 
                            
                         } else {
                          echo $this->lang->line('add category'); 
               
                             }
                         ?> 
                           
                         </strong>
                        </li>
                    </ol>
                </div>
               
            </div>
        <div class="wrapper wrapper-content animated fadeInRight">
           
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>
                             
                             <?php
                           if(!empty($cId)){
                          echo $this->lang->line('edit category'); 
                            
                         } else {
                          echo $this->lang->line('add category'); 
               
                             }
                         ?>  </h5>
                        



                        </div>
                        <div class="ibox-content">
   <form method="post" class="form-horizontal" action="<?php echo base_url(); ?>category<?php echo $action; ?>" id="addcategoryform" >
                                <div class="form-group"><label class="col-sm-2 control-label"><?php echo $this->lang->line('parent category'); ?></label>
          
                                 <div class="col-lg-4">
<?php /* if(!empty($category_info['cat_id'])){

$tree = buildTree($category); 
print("<select name='parent_cat' >\n");
print("<option value='0' >\n");
echo 'Parent category';
print("</option>");
printTree($tree);
print("</select>");
}



else {



print("<select name='parent_cat' >\n");
print("<option value='0' >\n");
echo 'Parent category';
print("</option>");
printTree($tree);
print("</select>");

} */

        
?>
  
 <select name='parent_cat' class="input-sm form-control input-s-sm inline">
  <option value="0">-Parent Category-</option>
  <?php
  echo category_tree(0,$cId,$project_id);
  ?>
</select>
 <input type="hidden" name="cat_id" value="<?php if(!empty($category_info['cat_id'])){ echo  encript($category_info['cat_id']);} ?>" >
  <input type="hidden" name="project_id" value="<?php if(!empty($project_id)){ echo  encript($project_id);} ?>" >
   <input type="hidden" name="company_id" value="<?php if(!empty($company_id)){ echo  encript($company_id);} ?>" > 
                              </div>
                               </div>
                                 <div class="hr-line-dashed"></div>
                              <div class="form-group"><label class="col-sm-2 control-label"><?php echo $this->lang->line('category name'); ?></label>
                    
                                    <div class="col-lg-4">
            <input type="text" name="cat_name" placeholder="Category Name" class="form-control" required=""
                value="<?php if(!empty($category_info['cat_id'])){ echo  $category_info['cat_name'];} ?>"></div>
                                </div>
      <div class="hr-line-dashed"></div>
                              <div class="form-group"><label class="col-sm-2 control-label">Default Markup </label>

                 <div class="col-lg-4">
                <input  name="cat_markup" placeholder="Default Markup" class="form-control" required="" type="number" min="0"
                value="<?php if(!empty($category_info['cat_id'])){ echo  $category_info['cat_markup'];} ?>"></div>
                                </div>
                 
                               <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <a href="<?php echo base_url(); ?>category/getCategory/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">    
                                        <button class="btn btn-white" type="button">Cancel</button></a>
                                       <button class="btn btn-primary" type="submit">Save changes</button> 
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<script>
 $().ready(function() {
 $("#addcategoryform").validate();
 });
</script>
