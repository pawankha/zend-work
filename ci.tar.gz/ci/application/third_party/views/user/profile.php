
            
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2><?php echo $this->lang->line('profile'); ?></h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="<?php echo base_url(); ?>Profile/profile"><?php echo $this->lang->line('profile'); ?></a>
                        </li>
                       
                        <li class="active">
                            <strong><?php echo $this->lang->line('edit profile'); ?></strong>
                        </li>
                    </ol>
                </div>
               
            </div>
        <div class="wrapper wrapper-content animated fadeInRight">
           
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5><?php echo $this->lang->line('edit profile'); ?> </h5>
                        



                        </div>
                        <div class="ibox-content">
   <form method="post" class="form-horizontal" id="adduserform" action="<?php echo base_url(); ?>Profile/submitProfile" enctype="multipart/form-data">
    <input type="hidden" name="user_id" id="user_id" value="<?php echo encript($profile->user_id); ?>" />
                                <div class="form-group"><label class="col-sm-2 control-label">First Name</label>
                     <div class="col-lg-4">
            <input type="text" required="" name="user_fname" placeholder="First Name" class="form-control" value="<?php echo $profile->user_fname; ?>"></div>
                                </div>
                                 <div class="form-group"><label class="col-sm-2 control-label">Last Name</label>
                                    <div class="col-lg-4">
            <input type="text" required="" name="user_lname" placeholder="Last Name" class="form-control" value="<?php echo $profile->user_lname; ?>"></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-2 control-label"><?php echo $this->lang->line('user name'); ?></label>
                                    <div class="col-lg-4">
           <input type="text"  required="" id="username" name="username"  placeholder="Username"  onkeyup="userexist();" value="<?php echo $profile->user_username; ?>" class="form-control"> 
                                    <p id="result_user"><input type="hidden" value="0" id="userExist" name="userExist"></p> 
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-2 control-label"><?php echo $this->lang->line('email'); ?></label>

                                    <div class="col-lg-4">
                <input type="email" required="" class="form-control" name="email" value="<?php echo $profile->user_email; ?>"   placeholder="email"></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-2 control-label">Image</label>

                                    <div class="col-lg-4"><input type="file" name="userfile"></div>
                                </div>
                                 <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <a href="<?php echo site_url(); ?>Profile/profile">    
                                        <button class="btn btn-white" type="button">Cancel</button></a>
                                       <button class="btn btn-primary" type="submit">Save changes</button> 
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
 function userexist() {
	
var base_url="<?php echo site_url(); ?>";  
var query_string=$('#username').val();
var userId=$('#user_id').val();
     $.ajax({
         type: "POST",
         url: base_url + "/profile/userexist", 
         data: {username: $('#username').val(),userId:userId},
         dataType: "text",  
         cache:false,
         success: 
              function(data){
							 	$('#result_user').html(data);
              }
	
			
          });
     			
 };

function submitForm(){
var query_string=$('#userExist').val();

 if (query_string==0) {
   jQuery("#adduserform").submit();
	return true;
 } else {
	return false;
 }


}
</script>
