<?php $session_data =$this->session->userdata('logged_in'); ?>

                   <?php if($session_data['user_type']==2){ ?>
 <div class="wrapper wrapper-content">
        <div class="row">
 <a href="<?php echo base_url(); ?>index.php/Company">
<div class="col-lg-3">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                
                                <h5>Company</h5>
                            </div>
                            <div class="ibox-content">
                                <h1 class="no-margins"><?php if($count_company!=""){ echo $count_company;}else{ echo "0"; } ?></h1>
                               
                                <small>Total Company</small>
                            </div>
                        </div>
                    </div>
</a>
 <a href="<?php echo base_url(); ?>index.php/Company">
<div class="col-lg-3">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                
                                <h5>Admin</h5>
                            </div>
                            <div class="ibox-content">
                                <h1 class="no-margins"><?php if($count_admin!=""){ echo $count_admin;}else{ echo "0"; } ?></h1>
                               
                                <small>Total Admin</small>
                            </div>
                        </div>
                    </div>
</a>
	</div>
 </div>
<?php }elseif($session_data['user_type']==1){ ?>
 <div class="wrapper wrapper-content">
        <div class="row">
 <a href="<?php echo base_url(); ?>index.php/Project/getProjects/<?php echo encript($company_id) ?>">
<div class="col-lg-3">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                
                                <h5>Projects</h5>
                            </div>
                            <div class="ibox-content">
                                <h1 class="no-margins"><?php if($count_projects!=""){ echo $count_projects;}else{ echo "0"; } ?></h1>
                               
                                <small>Total Projects</small>
                            </div>
                        </div>
                    </div>
</a>

                   <a href="<?php echo base_url(); ?>index.php/Users/getUsers/<?php echo encript($company_id) ?>">
                    <div class="col-lg-3">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                             
                                <h5>Users</h5>
                            </div>
                            <div class="ibox-content">
                                <h1 class="no-margins"><?php if($count_users!=""){ echo $count_users;}else{ echo "0"; } ?></h1>
                      
                                <small>Total Users</small>
                            </div>
                        </div>
                    </div></a>
	</div></div>
		    <?php }else{?>
		     <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-sm-4">
                    <h2>Project list</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li class="active">
                            <strong>Project list</strong>
                        </li>
                    </ol>
                </div>
            </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="wrapper wrapper-content animated fadeInUp">

                    <div class="ibox">
                        <div class="ibox-title">
                            <h5>All projects assigned to this account</h5>
                           <!-- <div class="ibox-tools">
                                <a href="" class="btn btn-primary btn-xs">Create new project</a>
                            </div>-->
                        </div>
               <div class="ibox-content">
                            <!--<div class="row m-b-sm m-t-sm">
                                <div class="col-md-1">
                                    <button type="button" id="loading-example-btn" class="btn btn-white btn-sm" ><i class="fa fa-refresh"></i> Refresh</button>
                                </div>
                                <div class="col-md-11">
                                    <div class="input-group"><input type="text" placeholder="Search" class="input-sm form-control"> <span class="input-group-btn">
                                        <button type="button" class="btn btn-sm btn-primary"> Go!</button> </span></div>
                                </div>
                            </div>-->

                            <div class="project-list">

                                <table class="table table-hover">
                                    <tbody>
					<?php  foreach($projects as $project){ ?>
                                    <tr>
                                        <td class="project-status">
					  <?php if($project['project_status']==1){ ?>
                                            <span class="label label-primary">Active</span>
					    <?php }else{ ?>
					       <span class="label label-default">Unactive</span>
					    <?php } ?>
                                        </td>
                                        <td class="project-title">
                                            <a href="<?php echo base_url(); ?>index.php/Project/manageProject/<?php echo encript($project['project_pid']);?>/<?php echo encript($company_id) ?>"><?php echo $project['project_name'] ?></a>
                                            <br/>
                                            <small>Created <?php echo $project['project_date'] ?></small>
                                        </td>
                                        <td class="project-completion">
                                                <small>Completion with: 100%</small>
                                                <div class="progress progress-mini">
                                                    <div style="width: 100%;" class="progress-bar"></div>
                                                </div>
                                        </td>
                                        <td class="project-people">
                                         <!--   <a href=""><img alt="image" class="img-circle" src="img/a3.jpg"></a>
                                            <a href=""><img alt="image" class="img-circle" src="img/a1.jpg"></a>
                                            <a href=""><img alt="image" class="img-circle" src="img/a2.jpg"></a>
                                            <a href=""><img alt="image" class="img-circle" src="img/a4.jpg"></a>
                                            <a href=""><img alt="image" class="img-circle" src="img/a5.jpg"></a>-->
                                        </td>
                                        <td class="project-actions">
                                            <a href="<?php echo base_url(); ?>index.php/Project/manageProject/<?php echo encript($project['project_pid']);?>/<?php echo encript($company_id) ?>" class="btn btn-white btn-sm"><i class="fa fa-folder"></i> Resources </a>
                                   
                                        </td>
                                    </tr>
				    <?php } ?>
                                    
                                    </tbody>
                                </table>
                              </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

                
	    
		    <?php } ?>
                 
          
