
            <?php $session_data = $this->session->userdata('logged_in');?>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2><?php echo $this->lang->line('user'); ?></h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="<?php echo base_url(); ?>Users"><?php echo $this->lang->line('user'); ?></a>
                        </li>
                       
                        <li class="active">
                            <strong><?php echo $this->lang->line('edit user'); ?></strong>
                        </li>
                    </ol>
                </div>
               
            </div>
        <div class="wrapper wrapper-content animated fadeInRight">
           
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5><?php echo $this->lang->line('edit user'); ?> </h5>
                        
               


                        </div>
                        <div class="ibox-content">
   <form method="post" class="form-horizontal" id="adduserform" action="<?php echo base_url(); ?>index.php/Users/submitUser" enctype="multipart/form-data">
	
                                <div class="form-group"><label class="col-sm-2 control-label"><?php echo $this->lang->line('first name'); ?></label>
                     <input type="hidden" name="user_id" id="user_id" value=" <?php echo  $user_info['user_id'] ?>" />
                                    <div class="col-lg-4">
            <input type="text" required="" name="user_fname" placeholder="Fisrt Name" class="form-control" value="<?php echo  $user_info['user_fname'] ?>"></div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-2 control-label"><?php echo $this->lang->line('last name'); ?></label>
                                    <div class="col-lg-4">
           <input type="text" name="user_lname"  required="" placeholder="Last Name"   value="<?php echo  $user_info['user_lname'] ?>" class="form-control"> 
                                    </div>
                                </div>
         <div class="form-group"><label class="col-sm-2 control-label"> <?php echo $this->lang->line('user name'); ?></label>
                                    <div class="col-lg-4">
           <input type="text" id="username" name="user_username" value="<?php echo $user_info['user_username']; ?>" onkeyup="userexist();" placeholder=" Username"    class="form-control" required=""  >
            <p id="result_user"><input type="hidden" value="0" id="userExist" name="userExist"></p><?php echo form_error('user_username'); ?>
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-2 control-label"><?php echo $this->lang->line('email'); ?></label>

                                    <div class="col-lg-4">
                <input type="email" class="form-control" required="" name="user_email" value="<?php echo  $user_info['user_email'] ?>"   placeholder="email"></div>
                                </div>
         
          
                   <?php if($session_data['user_type']==2){ ?>
        <div class="form-group"><label class="col-sm-2 control-label">Usertype</label>
                                    <div class="col-lg-4">

                           <select name="user_type" class="input-sm form-control input-s-sm inline">
                        <option <?php if($user_info['user_type']==1){ echo "selected"; } ?> value="1">Admin</option>
                        <option <?php if($user_info['user_type']==0){ echo "selected"; } ?> value="0">User</option>
     </select>
          
                                    </div> </div>
					<?php }elseif($session_data['user_type']==1){ ?>
			
				<?php }else{ }?>
                       
                       <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-2 control-label"><?php echo $this->lang->line('password'); ?></label>
                     <div class="col-lg-4">
           <input type="password" name="user_password"  placeholder= "Password"    class="form-control" required="" value="" > 
                                  <?php echo form_error('user_password'); ?>
                                    </div>
                                </div>

                                
                                 <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <a href="<?php echo base_url(); ?>Users">    
                                        <button class="btn btn-white" type="button">Cancel</button></a>
                                     <button class="btn btn-primary" type="button" onclick="return submitForm()">Save changes</button> 
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<script type="text/javascript">
 function userexist() {
	
var base_url="<?php echo site_url(); ?>";  
var query_string=$('#username').val();
var userId=$('#user_id').val();
     $.ajax({
         type: "POST",
         url: base_url + "/users/userexist", 
         data: {username: $('#username').val(),userId:userId},
         dataType: "text",  
         cache:false,
         success: 
              function(data){
							 	$('#result_user').html(data);
              }
	
			
          });
     			
 };

function submitForm(){
var query_string=$('#userExist').val();

 if (query_string==0) {
   jQuery("#adduserform").submit();
	return true;
 } else {
	return false;
 }


}
 
</script>
