
            
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2><?php echo $this->lang->line('profile'); ?></h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="<?php echo base_url(); ?>Dhasboard"><?php echo $this->lang->line('profile'); ?></a>
                        </li>
                       
                        <li class="active">
                            <strong><?php echo $this->lang->line('change password'); ?></strong>
                        </li>
                    </ol>
                </div>
               
            </div>
 <?php
	  $message = $this->session->flashdata('item');
if($message!="") {

  ?>
<div class="alert <?php echo $message['class']; ?>">
<button type="button" class="close close-sm" data-dismiss="alert">
                                    <i class="fa fa-times"></i>
                                </button>
<?php echo $message['message']; ?></div>
<?php
}
?>
        <div class="wrapper wrapper-content animated fadeInRight">
           
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5><?php echo $this->lang->line('change password'); ?> </h5>
                        



                        </div>
                        <div class="ibox-content">
   <form method="post" class="form-horizontal" action="<?php echo base_url(); ?>Profile/updatePassword" >
                                <div class="form-group"><label class="col-sm-2 control-label"><?php echo $this->lang->line('old password'); ?></label>
                
                                 
                                    <div class="col-lg-4">
            <input type="password" name="oldpassword" placeholder="Old Password" class="form-control" required="" >
                                  <?php echo form_error('oldpassword'); ?> </div>
                               </div>
 
                                <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-2 control-label"> <?php echo $this->lang->line('new password'); ?></label>
                                    <div class="col-lg-4">
           <input type="password" name="newpassword"  placeholder="New Password"    class="form-control" required="">
                                  <?php echo form_error('newpassword'); ?>
                                    </div>
                                </div>
                                <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-2 control-label"><?php echo $this->lang->line('confirm password'); ?></label>
                     <div class="col-lg-4">
           <input type="password" name="confirmpassword"  placeholder="Confirm Password"    class="form-control" required=""> 
                                  <?php echo form_error('confirmpassword'); ?>
                                    </div>
                                </div>
                                    
                                
                                 <div class="hr-line-dashed"></div>
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <a href="<?php echo base_url(); ?>Dashboard">    
                                        <button class="btn btn-white" type="button">Cancel</button></a>
                                       <button class="btn btn-primary" type="submit">Save changes</button> 
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
