       <div class="row wrapper border-bottom white-bg page-heading">
         <div class="col-lg-10">
                    <h2><?php $company_data=get_company_name(encript($company_id)); echo "Company Name: ".$company_data['company_name'] ?></h2>
                    <ol class="breadcrumb">
		       <li>
                       Dashboard
                        </li>
                        <li class="active">
                            <a href="#"><?php echo $this->lang->line('user'); ?></a>
                        </li>
                       
                       <!-- <li class="active">
                            <strong><?php// echo $this->lang->line('add_new_user'); ?></strong>
                        </li>-->
                    </ol>
                </div>
  </div>
         <div class="wrapper wrapper-content animated fadeInRight">  
       <?php
	  $message = $this->session->flashdata('item');
if($message!="") {

  ?>
<div class="alert <?php echo $message['class']; ?>">
<button type="button" class="close close-sm" data-dismiss="alert">
                                    <i class="fa fa-times"></i>
                                </button>
<?php echo $message['message']; ?></div>
<?php
}
?><form  action="<?php echo base_url(); ?>Users/Deleteall" method="post"/>
 <input type="hidden" name="companyid" value="<?php echo encript($company_id); ?>" /> 

          <div class="row">
	    
            <div class="col-lg-12">
            <div class="ibox float-e-margins">
            <div class="ibox-title">
                <h5><?php echo $this->lang->line('user'); ?></h5>
                
            </div>
            <div class="ibox-content">
            <div class="">
            <a  class="btn btn-primary" href="<?php echo base_url(); ?>Users/Adduser/<?php echo encript($company_id); ?>"><?php echo $this->lang->line('add_new_user'); ?></a>
<button type="submit" value="submit"  id="delete" disabled="disabled" onclick="return confirm('Are you sure you want to delete this ?')" class="btn btn-primary">Delete All Selected</button>
            </div>
  
            <table class="table table-striped table-bordered table-hover " id="editable" >
            <thead>
            <tr>
               <th><?php if(count($users)>0){ ?><input type="checkbox" class="i-checks checkall"><?php } ?></th>
                <th><?php echo $this->lang->line('user_name'); ?></th>
		 <th><?php echo $this->lang->line('email'); ?></th>
						
                <th><?php echo $this->lang->line('user_type');?></th>
       
                <th><?php echo $this->lang->line('status'); ?></th>
                 <th></th>
                
            </tr>
            </thead>
            <tbody>
         
<?php foreach($users as $userinfo)
{
//$creator_id = $userinfo['created_by'];
//$creator_info_user = $this->Users_m->created_by_user($creator_id);



 ?>    <tr class="gradeX">
                <input type="hidden" name="companyid" value="<?php echo encript($company_id); ?>" /> 
              <td><input type="checkbox"    class="i-checks"    name="delete[]" value="<?php  echo $userinfo['user_id'];?>"></td>
                <td><?php echo ucfirst($userinfo['user_username']);?></td>
		<td class="center"><?php echo $userinfo['user_email'];?></td>
                <td><?php if($userinfo['user_type']==0) { echo $this->lang->line('user');} ?></td>
        
                 <td class="center">
<?php if ($userinfo['user_status']==1)
{?>
<a href="<?php echo base_url(); ?>Users/Deactiveuser/<?php echo encript($userinfo['user_id']);?>/<?php echo encript($company_id); ?>"><span class="label label-primary">Active</span></a>

 <?php }
else
{  ?> <a href="<?php echo base_url(); ?>Users/Activeuser/<?php echo encript($userinfo['user_id']);?>/<?php echo encript($company_id); ?>"><span class="label label-default">Deactive</span></a> <?php }?>

</td>
                <td class="center"><a  class="btn btn-white btn-sm" href="<?php echo base_url(); ?>Users/Edituser/<?php echo encript($userinfo['user_id']);?>/<?php echo encript($company_id); ?>"> <i class="fa fa-pencil"></i>Edit</a>

<a  class="btn btn-white btn-sm" onclick="return confirm('Are you sure you want to delete this item?')"

 href="<?php echo base_url(); ?>Users/Deleteuser/<?php echo encript($userinfo['user_id']);?>/<?php echo encript($company_id); ?>">Delete</a>
<a  class="btn btn-white btn-sm" href="<?php echo base_url(); ?>Users/Edituser/<?php echo encript($userinfo['user_id'])?>/<?php echo encript($company_id)."/copy";?>"> <i class="fa fa-copy"></i>Copy</a>
 </td>
           </tr>

<?php } ?>

             
                
            
            
            </table>
            </div>
           
            </div>
            </div>
            </div>
      </form> 
        </div>
  
       <div style="clear:both"></div>
  <script src="<?php echo base_url(); ?>assets/js/plugins/iCheck/icheck.min.js"></script>
  <script>
        $(document).ready(function(){
            $('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-green',
                radioClass: 'iradio_square-green',
            });
        });
 $(document).ready(function(){
var checkboxes = $("input[type='checkbox']"),
checkboxes1 = $(".checkall"),
    submitButt = $("#delete");
 $('tbody .iCheck-helper').click(function()
{

    submitButt.attr("disabled", !checkboxes.is(":checked"));

});
 
 //select all//
 $('thead .iCheck-helper').click(function(){
   if (checkboxes1.is(":checked")) {
    $('tbody .i-checks').attr('checked',true);
   $( "tbody .icheckbox_square-green" ).addClass( "checked");
   submitButt.attr("disabled", !checkboxes.is(":checked"));
   }else{
      $('tbody .i-checks').removeAttr('checked'); 
   $( "tbody .icheckbox_square-green" ).removeClass( "checked");
   submitButt.attr("disabled", !checkboxes.is(":checked"));
   }
 //select all//

});
        });
    </script>
