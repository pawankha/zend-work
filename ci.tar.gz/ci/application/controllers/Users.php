<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
require APPPATH . 'controllers/Common.php';
class Users extends Common
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('pagination');
        $this->load->model('login_m');
        $this->load->model('Users_m');
        // check if user logged in
        if ($this->session->userdata('logged_in') == "") {
            redirect('login', 'refresh');
        }
        $session_data = $this->session->userdata('logged_in');
        if ($session_data['user_type'] == 2 || $session_data['user_type'] == 1) {
        } else {
            redirect(base_url() . 'index.php/dashboard', 'refresh');
        }
    }
    
    // Display all users based on company
    function getUsers($company_id)
    {
        $company_id         = $this->decript($company_id);
        $data['user_data']  = $this->userdata();
        $data['users']      = $this->Users_m->getUsers($company_id);
        $data['company_id'] = $company_id;
        $this->load->view('template/header', $data);
        $this->load->view('user/users', $data);
        $this->load->view('template/footer', $data);
    }
    
    // Display Add new user based on company
    function Adduser($company_id)
    {
        $company_id         = $this->decript($company_id);
        $data['user_data']  = $this->userdata();
        $data['company_id'] = $company_id;
        $this->load->view('template/header', $data);
        $this->load->view('user/addusers', $data);
        $this->load->view('template/footer', $data);
    }
    
    // Add new user based on company
    function submitUser($company_id1)
    {
        $session_data = $this->session->userdata('logged_in');
        $company_id   = $this->decript($company_id1);
        $data         = array(
            'user_fname' => $this->input->post('user_fname'),
            'user_lname' => $this->input->post('user_lname'),
            'user_username' => $this->input->post('user_username'),
            'user_type' => 0,
            'user_email' => $this->input->post('user_email'),
            'user_password' => MD5($this->input->post('user_password')),
            'user_status' => '1',
            'created_by' => $session_data['user_id'],
            'company_id' => $company_id
        );
        $add          = $this->Users_m->Adduser($data);
        if ($add) {
            $this->session->set_flashdata('item', array(
                'message' => 'User Added successfully',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'index.php/users/getusers/' . $company_id1);
        }
    }
    
    // Display Edit user based on company
    function Edituser($userid1, $company_id1, $action = "")
    {
        $company_id         = $this->decript($company_id1);
        $userid             = $this->decript($userid1);
        $data['user_data']  = $this->userdata();
        $data['user_info']  = $this->Users_m->Edituser($userid, $company_id);
        $data['user_id']    = $userid;
        $data['company_id'] = $company_id;
        $data['action']     = $action;
        $this->load->view('template/header', $data);
        $this->load->view('user/addusers', $data);
        $this->load->view('template/footer', $data);
    }
    
    // Update user based on company
    function update_user($company_id1, $user_id)
    {
        $session_data = $this->session->userdata('logged_in');
        $company_id   = $this->decript($this->input->post('company_id'));
        $user_id      = $this->decript($this->input->post('user_id'));
        $data         = array(
            'user_fname' => $this->input->post('user_fname'),
            'user_lname' => $this->input->post('user_lname'),
            'user_username' => trim($this->input->post('user_username')),
            'user_email' => $this->input->post('user_email'),
            'user_status' => '1',
            'created_by' => $session_data['user_id']
        );
        if ($this->input->post('user_password') != "") {
            $array2 = array(
                'user_password' => MD5($this->input->post('user_password'))
            );
            $data   = array_merge($data, $array2);
        }
        $add = $this->Users_m->updateUser($data, $user_id);
        if ($add) {
            $this->session->set_flashdata('item', array(
                'message' => 'User Updated successfully',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'index.php/users/getusers/' . $company_id1);
        }
    }
    
    // Delete user based on company
    function Deleteuser($userid, $company_id)
    {
        $user_id = $this->decript($userid);
        $delete  = $this->Users_m->deleteuser($user_id);
        if ($delete) {
            $this->session->set_flashdata('item', array(
                'message' => 'deleted successfully',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'index.php/users/getusers/' . $company_id);
        }
    }
    
    // Activate user based on company
    function Activeuser($userid, $company_id)
    {
        $user_id = $this->decript($userid);
        $data    = array(
            'user_status' => '1'
        );
        $active  = $this->Users_m->activeuser($user_id, $data);
        if ($active) {
            $this->session->set_flashdata('item', array(
                'message' => 'User active successfully',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'index.php/users/getusers/' . $company_id);
        }
    }
    
    // Deactivate user based on company
    function Deactiveuser($userid, $company_id)
    {
        $user_id  = $this->decript($userid, $company_id);
        $data     = array(
            'user_status' => '0'
        );
        $deactive = $this->Users_m->deactiveuser($user_id, $data);
        if ($deactive) {
            $this->session->set_flashdata('item', array(
                'message' => 'User deactive  successfully',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'index.php/users/getusers/' . $company_id);
        }
    }
    
    // Check user is exist or not
    function userexist()
    {
        $username = $this->input->post('username');
        $userId   = $this->input->post('userId');
        $this->db->select('*');
        if ($userId != "") {
            $userId = $this->decript($this->input->post('userId'));
            $where  = "user_username='" . $username . "' and user_id!='" . $userId . "' ";
        } else {
            $where = "user_username='" . $username . "' ";
        }
        // echo "SELECT * FROM tbl_users WHERE ".$where." ";
        $query = $this->db->query("SELECT * FROM tbl_users WHERE " . $where . " ");
        if ($query->num_rows() > 0) {
            echo "Username already exist";
?>
	   <input type="hidden" value="1" id="userExist" name="userExist">
	 <?php
        } else {
?>
	   <input type="hidden" value="0" id="userExist" name="userExist">
	 <?php
        }
    }
    
    // Delete all users
    function Deleteall()
    {
        $data        = $this->input->post('delete');
        $project_id1 = $this->input->post('projectid');
        $company_id1 = $this->input->post('companyid');
        $delete      = $this->Users_m->deleteall($data);
        if ($delete) {
            $this->session->set_flashdata('item', array(
                'message' => 'Data deleted successfully',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'index.php/users/getusers/' . $company_id1);
        } else {
            $this->session->set_flashdata('item', array(
                'message' => 'Data deleted Failed',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'index.php/users/getusers/' . $company_id1);
        }
    }
}
?>