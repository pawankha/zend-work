<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
require APPPATH . 'controllers/Common.php';
class Dashboard extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        
        $this->load->library(array('pagination','session'));
        $this->load->model('login_m');
        if ($this->session->userdata('logged_in') == "") {
            redirect('login', 'refresh');
        }
    }
    
    // Display Dashboard of Panel
    function index()
    {
           $ses=$this->session->userdata('logged_in');
           if(isset($ses))
           {
          $this->load->view('template/head');
          $this->load->view('template/header');
          $this->load->view('template/left_menu');
          $this->load->view('dashboard');
          $this->load->view('template/footer');    
           }
           else{
            $this->load->view('login');
           }
          
       
       
    }
    
    // Get Userdata which is loged in
   
}
?>