<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Common extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('pagination');
        $this->load->model('login_m');
        $this->load->model('project_m');
        $this->load->model('common_m');
        // check if user logged in
        if ($this->session->userdata('logged_in') == "") {
            redirect('login', 'refresh');
        }
    }
    
    // Get User Data who loged in
    function userdata()
    {
        $session_data          = $this->session->userdata('logged_in');
        $data['user_username'] = $session_data['user_username'];
        $data['user_id']       = $session_data['user_id'];
        $data['user_type']     = $session_data['user_type'];
        $user_id               = $data['user_id'];
        $tbl_name              = 'tbl_users';
        $where                 = array(
            'user_id' => $user_id
        );
        $data['user_data']     = $this->login_m->get_row_wh($tbl_name, $where);
        return $data['user_data'];
    }
    
    // Decript URl 
    function decript($str)
    {
        $str1 = base64_decode(urldecode($str));
        return $str1;
    }
}
?>
