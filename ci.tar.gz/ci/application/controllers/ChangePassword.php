<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
require APPPATH . 'controllers/Common.php';
class ChangePassword extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        
        $this->load->library(array('pagination','session','form_validation'));
        $this->load->model('login_m');
        if ($this->session->userdata('logged_in') == "") {
            redirect('login', 'refresh');
        }
    }
    
    // Display Dashboard of Panel
    function index()
    {
           $ses=$this->session->userdata('logged_in');
           if(isset($ses))
           {
          $this->load->view('template/head');
          $this->load->view('template/header');
          $this->load->view('template/left_menu');
          $this->load->view('changepassword');
       //   $this->load->view('template/footer');    
           }
           else{
            $this->load->view('login');
           }
          
       
       
    }
    
    
    public  function changepwd()
    {
    
      
     $ses=$this->session->userdata('logged_in');
       $previouspassword = $this->input->post('previouspassword');
        $newpassword = $this->input->post('newpassword');
      //  $this->form_validation->set_rules('previouspassword', 'previouspassword', 'required');
         $this->form_validation->set_rules('previouspassword', 'Label', 'required');
        $this->form_validation->set_rules('newpassword', 'Newpassword', 'required');
       if ($this->form_validation->run() == FALSE) {
                redirect(base_url() . 'index.php/ChangePassword', 'refresh');
      
       }else{
         $previouspassword=MD5($previouspassword);
       $newpassword=MD5($newpassword);
       $tbl_name="de_login";
       $data=array();
       if($previouspassword!="" && $newpassword!="")
       {
       if($newpassword==$previouspassword)
       {
        $this->session->set_flashdata('item', array(
                'message' => 'Not be same previous and newpassword. please choose different Password'              
                ));
       redirect(base_url() . 'index.php/ChangePassword', 'refresh');
        
       }
       else{
        $data['password']=$newpassword;
        $userid=$ses['id'];
        $where        = array(
            'id' => $userid,
           );
        $result121= $this->login_m->get_row_wh($tbl_name,$where);
        $pre_pwd=$result121->password;
        if($pre_pwd==$previouspassword)
        {
      
        $result= $this->login_m->get_password_update($userid,$data,$tbl_name);
        if($result==1)
       {
        $this->session->set_flashdata('item', array(
       'message' => 'Password Successfully Changed'              
       ));
       redirect(base_url() . 'index.php/ChangePassword', 'refresh');
       }
       else
       {
         $this->session->set_flashdata('item', array(
         'message' => 'Password Not be Changed'              
         ));
        redirect(base_url() . 'index.php/ChangePassword', 'refresh');
       }
        }
        else{
            $this->session->set_flashdata('item', array(
         'message' => 'Previous Password Not be match'              
         ));
        redirect(base_url() . 'index.php/ChangePassword', 'refresh');
        }
        
        
       }
       }
        
       }
       
          
       
       
    }
    
  
   
}
?>