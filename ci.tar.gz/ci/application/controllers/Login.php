<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Login extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('pagination');
        $this->load->model('login_m');
    }
    
    // Display user login page
    function index()
    {
      $sess = $this->session->userdata('logged_in');
         
        if (!empty($sess)) {
            
            redirect(base_url() . 'index.php/dashboard');
        } else {
            $this->load->view('login');
            $this->load->view('template/head');
           //  $this->load->view('template/header');
             $this->load->view('template/footer');
        }
    }
    
    // Check user login with Serverside validation
    function login()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required|callback_check_database');
        if ($this->form_validation->run() == FALSE) {
            //Field validation failed.  User redirected to login page
          // $this->load->view('index.php/login');
            redirect(base_url() . 'index.php/login', 'refresh');
        } else {
           $session_data =$this->session->userdata('logged_in');
          // print_r($session_data);exit;
          
           redirect('dashboard');
        }
    }
    
    // Check user login in Database
    function check_database($password)
    {
        //Field validation succeeded.  Validate against database
        $username     = $this->input->post('username');
        $tbl_name     = 'de_login';
        $userpassword = MD5($password);
        $where        = array(
            'username' => $username,
            'password' => $userpassword,
           );
        $result       = $this->login_m->get_row_wh($tbl_name, $where);
        if ($result) {
            $sess_array = array();
            $sess_array = array(
                'id' => $result->id,
                'user_name' => $result->username,
                'user_email' => $result->email                
            );
           // print_r($sess_array);exit;
            $this->session->set_userdata('logged_in', $sess_array);
            return TRUE;
        } else {
            $this->form_validation->set_message('check_database', 'Invalid username or password');
            return false;
        }
    }
    
    // Logout User
    function logout()
    {
        $this->session->unset_userdata('logged_in');
        $this->session->sess_destroy();
        redirect(base_url() . 'index.php/login', 'refresh');
    }
}
?>