<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
require APPPATH . 'controllers/Common.php';
class ViewProfile extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        
        $this->load->library(array('pagination','session','form_validation'));
		$this->load->model('login_m');
		$this->load->helper('url');
        		
        if ($this->session->userdata('logged_in') == "") {
            redirect('login', 'refresh');
        }
    }
    function index()
    {
        
	    $editid= $this->input->get('id');
		if(isset($editid))
        {
			$id=$editid;
			$table="de_login";
			 $data['userdata']= $this->login_m->edit_user($id,$table);
            $this->load->view('template/head');
            $this->load->view('template/header');
            $this->load->view('template/left_menu');
            $this->load->view('viewprofile',$data);
            //$this->load->view('template/footer');    
           }
           else{
            $this->load->view('login');
           }
    }
    
}
?>