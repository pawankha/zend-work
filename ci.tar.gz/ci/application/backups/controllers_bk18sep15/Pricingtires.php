<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
//we need to call PHP's session object to access it through CI
require APPPATH . 'controllers/Common.php';
class Pricingtires extends Common
{
    
    function __construct()
    {
        parent::__construct();
        
        
        $this->load->library('pagination');
        $this->load->model('login_m');
        $this->load->model('pricingt_m');
        
        
        
        if ($this->session->userdata('logged_in') == "") {
            redirect(base_url() . 'login', 'refresh');
        }
        
    }
    
    function getTier($project_id, $company_id)
    {
        
        $project_id         = $this->decript($project_id);
        $company_id         = $this->decript($company_id);
        $data['project_id'] = $project_id;
        $data['company_id'] = $company_id;
        $data['user_data']  = $this->userdata();
        
        $data['pricingts'] = $this->pricingt_m->getAllpricingtires($project_id, $company_id);
        $this->load->view('template/header_project', $data);
        $this->load->view('pricingtires/pricingtiresall', $data);
        $this->load->view('template/footer', $data);
        
    }
    function Addpricingtires($project_id, $company_id)
    {
        $project_id         = $this->decript($project_id);
        $company_id         = $this->decript($company_id);
        $data['project_id'] = $project_id;
        $data['company_id'] = $company_id;
        $data['user_data']  = $this->userdata();
        $data['recipes']    = $this->pricingt_m->getrecipes($project_id);
        
        $this->load->view('template/header_project', $data);
        $this->load->view('pricingtires/addpricingtires');
        $this->load->view('template/footer');
        
    }
    
    function submitPricetier($project_id1, $company_id1)
    {
        $project_id   = $this->decript($project_id1);
        $company_id   = $this->decript($company_id1);
        $session_data = $this->session->userdata('logged_in');
        
        $data = array(
            'pricingt_name' => $this->input->post('pricingt_name'),
            'default_recipe' => $this->input->post('default_recipe'),
            'pricingt_createdby' => $session_data['user_id'],
            
            'project_id' => $project_id,
            'company_id' => $company_id
        );
        
        
        
        $add = $this->pricingt_m->Addpricingtires($data);
        
        if ($add) {
            $this->session->set_flashdata('item', array(
                'message' => '  Pricingtires Added successfully',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'pricingtires/gettier/' . $project_id1 . '/' . $company_id1);
        }
        
    }
    function updatePricetier($project_id1, $company_id1)
    {
        
        $session_data = $this->session->userdata('logged_in');
        
        $pricingtid = $this->decript($this->input->post('pricingtid'));
        $project_id = $this->decript($project_id1);
        $company_id = $this->decript($company_id1);
        $data       = array(
            'pricingt_name' => $this->input->post('pricingt_name'),
            'default_recipe' => $this->input->post('default_recipe'),
            'pricingt_createdby' => $session_data['user_id'],
            'pricingt_userid' => $this->input->post('userid')
            
        );
        
        $add = $this->pricingt_m->Updatepricingtires($pricingtid, $data);
        if ($add) {
            
            // $table="tbl_product";
            // $where=array('category'=>$cat_id);
            // $this->common_m->set_newprice($table,$where);
            
            $this->session->set_flashdata('item', array(
                'message' => '  Pricingtires Upadted successfully',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'pricingtires/gettier/' . $project_id1 . '/' . $company_id1);
        }
    }
    
    
    function Editpricingtires($pricingtid = "", $project_id, $company_id, $action = "")
    {
        $project_id            = $this->decript($project_id);
        $company_id            = $this->decript($company_id);
        $pricingtid            = $this->decript($pricingtid);
        $data['project_id']    = $project_id;
        $data['company_id']    = $company_id;
        $data['ptId']          = $pricingtid;
        $data['pricingt_info'] = $this->pricingt_m->Editpricingtires($pricingtid);
        $data['user_data']     = $this->userdata();
        $data['recipes']       = $this->pricingt_m->getrecipes($project_id);
        $data['action']        = $action;
        $this->load->view('template/header_project', $data);
        $this->load->view('pricingtires/addpricingtires', $data);
        $this->load->view('template/footer', $data);
        
    }
    
    
    
    function Deletepricingtires($pricingtid, $project_id1, $company_id1)
    {
        $project_id = $this->decript($project_id1);
        $company_id = $this->decript($company_id1);
        $pricingtid = $this->decript($pricingtid);
        $delete     = $this->pricingt_m->Deletepricingtires($pricingtid);
        if ($delete) {
            $this->session->set_flashdata('item', array(
                'message' => ' Pricingtires deleted successfully',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'pricingtires/gettier/' . $project_id1 . '/' . $company_id1);
        }
        
    } //change by rohit
    function Deleteall()
    {
        $data        = $this->input->post('delete');
        $project_id1 = $this->input->post('projectid');
        $company_id1 = $this->input->post('companyid');
        $delete      = $this->pricingt_m->deleteall($data);
        if ($delete) {
            $this->session->set_flashdata('item', array(
                'message' => 'Data deleted successfully',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'pricingtires/gettier/' . $project_id1 . '/' . $company_id1);
        } else {
            $this->session->set_flashdata('item', array(
                'message' => 'Data deleted Failed',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'pricingtires/gettier/' . $project_id1 . '/' . $company_id1);
        }
    }
    
}
?>
