<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
//we need to call PHP's session object to access it through CI
require APPPATH . 'controllers/Common.php';
class Category extends Common
{
    
    function __construct()
    {
        parent::__construct();
        
        
        $this->load->library('pagination');
        $this->load->model('login_m');
        $this->load->model('category_m');
        $this->load->model('common_m');
        $this->load->model('recipe_m');
        
        
        if ($this->session->userdata('logged_in') == "") {
            redirect(base_url() . 'login', 'refresh');
        }
        
    }
    
    function getCategory($project_id, $company_id)
    {
        $project_id         = $this->decript($project_id);
        $company_id         = $this->decript($company_id);
        $data['project_id'] = $project_id;
        $data['company_id'] = $company_id;
        $data['user_data']  = $this->userdata();
        $data['categories'] = $this->category_m->getcategory($project_id);
        $this->load->view('template/header_project', $data);
        
        $this->load->view('category/category_all', $data);
        $this->load->view('template/footer', $data);
        
    }
    
    function AddCategory($project_id = "", $company_id)
    {
        $project_id         = $this->decript($project_id);
        $company_id         = $this->decript($company_id);
        $data['project_id'] = $project_id;
        $data['company_id'] = $company_id;
        $data['user_data']  = $this->userdata();
        $this->load->view('template/header_project', $data);
        $this->load->view('category/addcategory', $data);
        $this->load->view('template/footer', $data);
        
    }
    function submitCategory($project_id1 = "", $company_id1 = "")
    {
        $session_data = $this->session->userdata('logged_in');
        $project_id   = $this->decript($this->input->post('project_id'));
        $company_id   = $this->decript($this->input->post('company_id'));
        $data         = array(
            'cat_parentid ' => $this->input->post('parent_cat'),
            'cat_userid' => $session_data['user_id'],
            'cat_name' => $this->input->post('cat_name'),
            'cat_markup' => $this->input->post('cat_markup'),
            'project_id' => $project_id,
            'company_id' => $company_id
            
        );
        
        $add = $this->category_m->Addcategory($data);
        if ($add) {
            $this->session->set_flashdata('item', array(
                'message' => 'Category Added successfully',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'category/getcategory/' . $project_id1 . '/' . $company_id1);
        }
    }
    function updateCategory($project_id1 = "", $company_id1 = "")
    {
        $session_data = $this->session->userdata('logged_in');
        $project_id   = $this->decript($this->input->post('project_id'));
        $company_id   = $this->decript($this->input->post('company_id'));
        $cat_id       = $this->decript($this->input->post('cat_id'));
        $data         = array(
            'cat_parentid ' => $this->input->post('parent_cat'),
            'cat_userid' => $session_data['user_id'],
            'cat_name' => $this->input->post('cat_name'),
            'cat_markup' => $this->input->post('cat_markup'),
            'project_id' => $project_id,
            'company_id' => $company_id
            
        );
        
        
        
        $add = $this->category_m->updateCategory($data, $cat_id);
        if ($add) {
            
            $table = "tbl_product";
            $where = array(
                'category' => $cat_id
            );
            $this->common_m->set_newprice($table, $where);
            $this->session->set_flashdata('item', array(
                'message' => 'Category Updated successfully',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'category/getcategory/' . $project_id1 . '/' . $company_id1);
        }
    }
    
    
    
    
    function Editcategory($catid = "", $project_id = "", $company_id, $action = "")
    {
        $catid                 = $this->decript($catid);
        $project_id            = $this->decript($project_id);
        $company_id            = $this->decript($company_id);
        $data['project_id']    = $project_id;
        $data['company_id']    = $company_id;
        $data['cId']           = $catid;
        $data['user_data']     = $this->userdata();
        $data['category_info'] = $this->category_m->Editcategory($catid);
        $data['category']      = $this->category_m->getCategory($project_id);
        $data['action']        = $action;
        $this->load->view('template/header', $data);
        $this->load->view('category/addcategory', $data);
        $this->load->view('template/footer', $data);
    }
    
    function Deletecategory($catid, $project_id1, $company_id1)
    {
        
        $cat_id = $this->decript($catid);
        
        $delete = $this->category_m->Deletecategory($cat_id);
        if ($delete) {
            $this->session->set_flashdata('item', array(
                'message' => 'Category deleted successfully',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'category/getcategory/' . $project_id1 . '/' . $company_id1);
        }
        
    }
    //change by rohit
    function Deleteall()
    {
        $data        = $this->input->post('delete');
        $project_id1 = $this->input->post('projectid');
        $company_id1 = $this->input->post('companyid');
        $delete      = $this->category_m->deleteall($data);
        if ($delete) {
            $this->session->set_flashdata('item', array(
                'message' => 'Data deleted successfully',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'category/getcategory/' . $project_id1 . '/' . $company_id1);
        } else {
            $this->session->set_flashdata('item', array(
                'message' => 'Data deleted Failed',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'category/getcategory/' . $project_id1 . '/' . $company_id1);
        }
        
        
        
    }
    
}
?>
