<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
//we need to call PHP's session object to access it through CI
require APPPATH . 'controllers/Common.php';
class Profile extends Common
{
    
    function __construct()
    {
        parent::__construct();
        
        
        $this->load->library('pagination');
        $this->load->model('login_m');
        
        
        
        if ($this->session->userdata('logged_in') == "") {
            redirect(base_url() . 'login', 'refresh');
        }
        
    }
    
    function index()
    {
        $data['user_data'] = $this->userdata();
        $this->load->view('template/header', $data);
        $this->load->view('user/profilelist', $data);
        $this->load->view('template/footer', $data);
        
    }
    
    function editProfile($user_id)
    {
        $data['profile']   = $this->userdata();
        $data['user_data'] = $this->userdata();
        $this->load->view('template/header', $data);
        $this->load->view('user/profile', $data);
        $this->load->view('template/footer', $data);
        
    }
    
    
    function submitProfile()
    {
        $userid                  = decript($this->input->post('user_id'));
        $config['upload_path']   = 'uploads/userimage';
        $config['allowed_types'] = 'gif|jpg|png';
        $new_name                = time() . $_FILES["userfile"]['name'];
        $config['file_name']     = $new_name;
        
        $this->load->library('upload', $config);
        if ($this->upload->do_upload()) {
            $upload_data = $this->upload->data();
            $data        = array(
                
                'user_image' => $upload_data['file_name'],
                'user_fname' => $this->input->post('user_fname'),
                'user_lname' => $this->input->post('user_lname'),
                'user_username' => $this->input->post('username'),
                'user_email' => $this->input->post('email')
                
                
                
            );
        }
        
        else {
            
            $data = array(
                'user_fname' => $this->input->post('user_fname'),
                'user_lname' => $this->input->post('user_lname'),
                'user_username' => $this->input->post('username'),
                'user_email' => $this->input->post('email')
            );
        }
        
        $update = $this->login_m->get_profile_update($userid, $data);
        
        if ($update) {
            $this->session->set_flashdata('item', array(
                'message' => 'update successfully',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'profile');
        }
        
        
        
    }
    
    
    function Password()
    {
        $session_data = $this->session->userdata('logged_in');
        
        $data['user_data'] = $this->userdata();
        $this->load->view('template/header', $data);
        $this->load->view('user/changepassword');
        $this->load->view('template/footer');
        
        
    }
    
    
    
    function updatePassword()
    {
        
        
        $session_data          = $this->session->userdata('logged_in');
        $data['user_username'] = $session_data['user_username'];
        $data['user_id']       = $session_data['user_id'];
        $user_id               = $data['user_id'];
        $user_name             = $data['user_username'];
        $tbl_name              = 'tbl_users';
        $where                 = array(
            'user_id' => $user_id
        );
        $data['user_data']     = $this->login_m->get_row_wh($tbl_name, $where);
        $user_data             = $data['user_data'];
        $userpassword          = $user_data->user_password;
        $password              = $this->input->post('oldpassword');
        $oldpassword           = MD5($password);
        $newpassword           = $this->input->post('newpassword');
        $confirmpassword       = $this->input->post('confirmpassword');
        $this->form_validation->set_rules('oldpassword', 'Old password', 'required');
        $this->form_validation->set_rules('newpassword', 'New Password', 'required');
        $this->form_validation->set_rules('confirmpassword', 'Confirm Password', 'required');
        if ($this->form_validation->run() != true) {
            $this->load->view('template/header', $data);
            $this->load->view('user/changepassword');
            $this->load->view('template/footer');
            
        } else {
            if ($userpassword == $oldpassword) {
                if ($newpassword == $confirmpassword) {
                    $data = array(
                        'user_password' => MD5($newpassword)
                        
                    );
                    
                    $update = $this->login_m->get_password_update($user_id, $data);
                    
                    
                    if ($update) {
                        $this->session->set_flashdata('item', array(
                            'message' => ' Password update successfully',
                            'class' => 'alert-success'
                        ));
                        redirect(base_url() . 'profile/password');
                    }
                    
                    
                    
                } else {
                    
                    $this->session->set_flashdata('item', array(
                        'message' => ' Confirm password is  wrong ',
                        'class' => 'alert-success'
                    ));
                    redirect(base_url() . 'profile/password');
                }
            } else {
                $this->session->set_flashdata('item', array(
                    'message' => ' Old password is  wrong ',
                    'class' => 'alert-success'
                ));
                redirect(base_url() . 'profile/password');
                
                
                
            }
            
            
            
        }
    }
    function userexist()
    {
        
        
        $username = $this->input->post('username');
        $userId   = $this->input->post('userId');
        
        $this->db->select('*');
        if ($userId != "") {
            $userId = $this->decript($this->input->post('userId'));
            $where  = "user_username='" . $username . "' and user_id!='" . $userId . "' ";
        } else {
            $where = "user_username='" . $username . "' ";
        }
        // echo "SELECT * FROM tbl_users WHERE ".$where." ";
        $query = $this->db->query("SELECT * FROM tbl_users WHERE " . $where . " ");
        
        if ($query->num_rows() > 0) {
            echo "Username already exist";
?><input type="hidden" value="1" id="userExist" name="userExist"><?php
        } else {
?><input type="hidden" value="0" id="userExist" name="userExist"><?php
        }
        
        
    }
}
?>
