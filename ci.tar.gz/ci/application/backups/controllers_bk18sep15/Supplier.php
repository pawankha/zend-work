<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
//we need to call PHP's session object to access it through CI
require APPPATH . 'controllers/Common.php';
class Supplier extends Common
{
    public $sess;
    function __construct()
    {
        parent::__construct();
        
        $this->load->library('pagination');
        $this->load->model('login_m');
        $this->load->model('supplier_m');
        $this->load->model('common_m');
        $this->load->model('recipe_m');
        $sess = $this->session->userdata('logged_in');
        
        if (empty($sess)) {
            redirect(base_url() . 'login', 'refresh');
        }
        
        
    }
    
    function getSupplier($project_id, $company_id)
    {
        $project_id         = $this->decript($project_id);
        $company_id         = $this->decript($company_id);
        $data['project_id'] = $project_id;
        $data['company_id'] = $company_id;
        $data['user_data']  = $this->userdata();
        $data['suppliers']  = $this->supplier_m->getSupplier($project_id, $company_id);
        
        $this->load->view('template/header_project', $data);
        $this->load->view('supplier/supplier_all', $data);
        $this->load->view('template/footer', $data);
        
    }
    function Addsupplier($project_id = "", $company_id = "")
    {
        $project_id         = $this->decript($project_id);
        $company_id         = $this->decript($company_id);
        $data['project_id'] = $project_id;
        $data['company_id'] = $company_id;
        $data['user_data']  = $this->userdata();
        
        
        $this->load->view('template/header_project', $data);
        $this->load->view('supplier/addsupplier', $data);
        $this->load->view('template/footer', $data);
        
    }
    function submitSupplier($project_id1, $company_id1)
    {
        
        $session_data = $this->session->userdata('logged_in');
        
        $project_id         = $this->decript($this->input->post('project_id'));
        $company_id         = $this->decript($this->input->post('company_id'));
        $data['project_id'] = $project_id;
        $data['company_id'] = $company_id;
        
        $data = array(
            'sup_name' => $this->input->post('sup_name'),
            'sup_userid' => $session_data['user_id'],
            'sup_percentage' => $this->input->post('sup_percentage'),
            'project_id' => $project_id,
            'company_id' => $company_id
        );
        
        $add = $this->supplier_m->Addsupplier($data);
        
        if ($add) {
            $this->session->set_flashdata('item', array(
                'message' => 'Supplier Added successfully',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'supplier/getsupplier/' . $project_id1 . '/' . $company_id1);
        }
        
    }
    
    function updateSupplier($project_id1, $company_id1)
    {
        
        $session_data       = $this->session->userdata('logged_in');
        $project_id         = $this->decript($this->input->post('project_id'));
        $company_id         = $this->decript($this->input->post('company_id'));
        $supid              = $this->decript($this->input->post('supid'));
        $data['project_id'] = $project_id;
        $data['company_id'] = $company_id;
        $data               = array(
            'sup_name ' => $this->input->post('sup_name'),
            'sup_userid' => $session_data['user_id'],
            'sup_percentage' => $this->input->post('sup_percentage'),
            'project_id' => $project_id,
            'company_id' => $company_id
        );
        $add                = $this->supplier_m->Updatesupplier($supid, $data);
        if ($add) {
            $table = "tbl_product";
            $where = array(
                'supplier_SKU' => $supid,
                'project_id'=>$project_id,
                'company_id'=>$company_id,
            );
            $this->common_m->set_newprice($table, $where);
            
            $this->session->set_flashdata('item', array(
                'message' => 'Supplier Updated successfully',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'supplier/getsupplier/' . $project_id1 . '/' . $company_id1);
        }
        
    }
    function Editsupplier($supid = "", $project_id, $company_id, $action = "")
    {
        $project_id            = $this->decript($project_id);
        $company_id            = $this->decript($company_id);
        $sup_id                = $this->decript($supid);
        $data['project_id']    = $project_id;
        $data['company_id']    = $company_id;
        $data['sId']           = $sup_id;
        $data['user_data']     = $this->userdata();
        $data['supplier_info'] = $this->supplier_m->Editsupplier($sup_id, $project_id);
        $data['action']        = $action;
        $this->load->view('template/header_project', $data);
        $this->load->view('supplier/addsupplier', $data);
        $this->load->view('template/footer', $data);
    }
    
    
    
    function Deletesupplier($supid, $project_id1, $company_id1)
    {
        $project_id = $this->decript($project_id1);
        $company_id = $this->decript($company_id1);
        $sup_id     = $this->decript($supid);
        $delete     = $this->supplier_m->Deletesupplier($sup_id);
        if ($delete) {
            $this->session->set_flashdata('item', array(
                'message' => 'Supplier deleted successfully',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'supplier/getsupplier/' . $project_id1 . '/' . $company_id1);
        }
        
    }
    //change by rohit
    function Deleteall()
    {
        $data        = $this->input->post('delete');
        $project_id1 = $this->input->post('projectid');
        $company_id1 = $this->input->post('companyid');
        $delete      = $this->supplier_m->deleteall($data);
        if ($delete) {
            $this->session->set_flashdata('item', array(
                'message' => 'Data deleted successfully',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'supplier/getsupplier/' . $project_id1 . '/' . $company_id1);
        } else {
            $this->session->set_flashdata('item', array(
                'message' => 'Data deleted Failed',
                'class' => 'alert-success'
            ));
            redirect(base_url() . 'supplier/getsupplier/' . $project_id1 . '/' . $company_id1);
        }
        
        
    }
    
}
?>
