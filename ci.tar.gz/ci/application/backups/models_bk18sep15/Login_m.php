<?Php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Login_m extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
    public function get_row($tbl_name)
    {
        
        $query = $this->db->get($tbl_name);
        if ($query->num_rows() > 0) {
            return $query->row();
        } //$query->num_rows() > 0
    }
    
    
    public function get_row_wh($tbl_name, $where)
    {
        
        $this->db->where($where);
        $query = $this->db->get($tbl_name);
        
        
        if ($query->num_rows() > 0) {
            return $query->row();
        } //$query->num_rows() > 0
    }
    
    
    public function get_num_rows($tbl_name)
    {
        
        $query = $this->db->get($tbl_name);
        if ($query->num_rows() > 0) {
            return $query->num_rows();
        } //$query->num_rows() > 0
    }
    
    public function get_result($tbl_name)
    {
        
        $this->db->where($where);
        $query = $this->db->get($tbl_name);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } //$query->num_rows() > 0
    }
    
    public function get_result_wh($tbl_name, $where)
    {
        
        $this->db->where($where);
        $query = $this->db->get($tbl_name);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } //$query->num_rows() > 0
    }
    
    function get_password_update($user_id, $data)
    {
        $this->db->where('user_id', $user_id);
        $update = $this->db->update('tbl_users', $data);
        return $update;
    }
    
    function get_profile_update($userid, $data)
    {
        $this->db->where('user_id', $userid);
        $update = $this->db->update('tbl_users', $data);
        return $update;
    }
    
    
    function get_user()
    {
        
        $session_data = $this->session->userdata('logged_in');
        $this->db->select('*');
        if ($session_data['user_type'] == 2) {
            $where = "user_type='0' or user_type='1'";
            $this->db->where($where);
        } //$session_data['user_type'] == 2
        else {
            $where = "user_type='0' and created_by=" . $session_data['user_id'];
            $this->db->where($where);
        }
        
        $this->db->from('tbl_users');
        $query = $this->db->get();
        return $query->result_array();
        
        
    }
    
    function get_project($selfId, $users)
    {
        
        
        $session_data      = $this->session->userdata('logged_in');
        $data['user_type'] = $session_data['user_type'];
        $this->db->select('*');
        if ($session_data['user_type'] == 2) {
        } //$session_data['user_type'] == 2
        else if ($session_data['user_type'] == 1) {
            $arrProject = "";
            
            foreach ($users as $UserVal) {
                
                $where = "project_userid=" . $session_data['user_id'] . " OR project_created_by=" . $UserVal['user_id'] . " OR project_created_by=" . $session_data['user_id'];
                $this->db->where($where);
                $this->db->from('tbl_project');
                $query        = $this->db->get();
                $arrProject[] = $query->result_array();
                
            } //$users as $UserVal
            
            return $arrProject;
        } //$session_data['user_type'] == 1
        else {
            $where = "project_userid=" . $session_data['user_id'];
            $this->db->where($where);
            $this->db->from('tbl_project');
            $query = $this->db->get();
            return $query->result_array();
        }
        
        
        
    }
    
    function get_category()
    {
        
        $session_data      = $this->session->userdata('logged_in');
        $data['user_type'] = $session_data['user_type'];
        
        $this->db->select('*');
        if ($session_data['user_type'] == 2) {
        } //$session_data['user_type'] == 2
        else if ($session_data['user_type'] == 1) {
            $this->db->select('user_id,created_by');
            $this->db->where('created_by', $session_data['user_id']);
            $this->db->from('tbl_users');
            $query      = $this->db->get();
            $arrProject = "";
            foreach ($query->result_array() as $UserVal) {
                $where = "cat_userid=" . $session_data['user_id'] . " OR cat_userid=" . $UserVal['user_id'];
                $this->db->where($where);
                $this->db->select('cat_id');
                $query        = $this->db->get('tbl_category');
                $arrProject[] = $query->result_array();
                
            } //$query->result_array() as $UserVal
            
            return $arrProject;
            
        } //$session_data['user_type'] == 1
        else {
            $where = "cat_userid =" . $session_data['user_id'];
            $this->db->where($where);
        }
        $this->db->from('tbl_category');
        $query = $this->db->get();
        return $query->result_array();
        
    }
    
    
    function get_supplier()
    {
        
        $session_data      = $this->session->userdata('logged_in');
        $data['user_type'] = $session_data['user_type'];
        $this->db->select('*');
        if ($session_data['user_type'] == 2) {
        } //$session_data['user_type'] == 2
        else if ($session_data['user_type'] == 1) {
            
            $this->db->select('user_id,created_by');
            $this->db->where('created_by', $session_data['user_id']);
            $this->db->from('tbl_users');
            $query      = $this->db->get();
            $arrProject = "";
            foreach ($query->result_array() as $UserVal) {
                $where = "sup_userid=" . $session_data['user_id'] . " OR sup_userid=" . $UserVal['user_id'];
                $this->db->where($where);
                $this->db->select('sup_id');
                $query        = $this->db->get('tbl_supplier');
                $arrProject[] = $query->result_array();
                
            } //$query->result_array() as $UserVal
            
            return $arrProject;
            
        } //$session_data['user_type'] == 1
        else {
            $where = "sup_userid =" . $session_data['user_id'];
            $this->db->where($where);
        }
        $this->db->from('tbl_supplier');
        $query = $this->db->get();
        return $query->result_array();
        
        
        
    }
    
    
    
    
}

?>
