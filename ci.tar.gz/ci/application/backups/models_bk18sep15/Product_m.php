<?Php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Product_m extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function getproducts($project_id, $company_id)
    {
                
        $this->db->select('*');
        $this->db->where('tbl_product.project_id', $project_id);
        $this->db->from('tbl_product');
        $this->db->join('tbl_category', 'tbl_category.cat_id = tbl_product.category');
        $this->db->join('tbl_productgroup', 'tbl_productgroup.product_groupid = tbl_product.product_groupid','left');
        $this->db->join('tbl_supplier', 'tbl_supplier.sup_id = tbl_product.supplier_SKU');
        //$this->db->join('tbl_recipe', 'tbl_recipe.id = tbl_product.minimum_price_recipe');
        //$this->db->join('tbl_product_tier', 'tbl_product_tier.product_id = tbl_product.id');
        $query    = $this->db->get();
        $products = $query->result_array();
        
        
        // echo "<pre>";print_r($query->result_array()); die;
        return $products;
        
    }
    
    function get_recipe_det($recipe_id_min)
    {
        $this->db->select('recipe_name');
        $this->db->where('tbl_recipe.id', $recipe_id_min);
        $this->db->from('tbl_recipe');
        $query       = $this->db->get();
        $recipe_dtls = $query->row();
        if (!empty($recipe_dtls->recipe_name)) {
            return $recipe_dtls->recipe_name;
        } //!empty($recipe_dtls->recipe_name)
        else {
            return false;
        }
        
    }
    
    function getPricingtier($project_id, $company_id)
    {
        
        $this->db->select('pricingt_name');
        $this->db->where('tbl_pricingt.project_id', $project_id);
        $this->db->where('tbl_pricingt.company_id', $company_id);
        $this->db->from('tbl_pricingt');
        // $this->db->join('tbl_pricingt', 'tbl_pricingt.project_id=tbl_product.project_id');
        
        $query         = $this->db->get();
        $pricing_tiers = $query->result_array();
        return $pricing_tiers;
    }
    
    function getCategory($project_id)
    {
        $this->db->select('*');
        $this->db->where('project_id', $project_id);
        $query = $this->db->get('tbl_category');
        return $query->result_array();
    }
    function gettier($project_id)
    {
        $this->db->select('*');
        $this->db->where('tbl_pricingt.project_id', $project_id);
        $this->db->from('tbl_pricingt');
        
        $this->db->join('tbl_recipe', 'tbl_recipe.id = tbl_pricingt.default_recipe');
        $query = $this->db->get();
        return $query->result_array();
    }
    function getrecipes($project_id, $company_id)
    {
        
        $this->db->select('*');
        $this->db->where('project_id', $project_id);
        $this->db->from('tbl_recipe');
        
        $query   = $this->db->get();
        $recipes = $query->result_array();
        
        return $recipes;
        
    }
    function getsuppliers($project_id, $company_id)
    {
        
        $this->db->select('*');
        $this->db->where('project_id', $project_id);
        $this->db->from('tbl_supplier');
        
        $query   = $this->db->get();
        $recipes = $query->result_array();
        
        return $recipes;
        
    }
    function getcategorymarkup($id)
    {
        $this->db->select('*');
        $this->db->where('cat_id', $id);
        $this->db->from('tbl_category');
        
        $query    = $this->db->get();
        $category = $query->row_array();
        
        return $category;
    }
    function getsuppliermarkup($id)
    {
        $this->db->select('*');
        $this->db->where('sup_id', $id);
        $this->db->from('tbl_supplier');
        
        $query    = $this->db->get();
        $supplier = $query->row_array();
        
        return $supplier;
    }
    function getproduct($product_id)
    {
        
        $this->db->select('*');
        $this->db->where('tbl_product.id', $product_id);
        $this->db->from('tbl_product');
        
        $query    = $this->db->get();
        $products = $query->row_array();
        
        return $products;
        
    }
    function getproduct_tier($product_id)
    {
        
        $this->db->select('*');
        $this->db->where('product_id', $product_id);
        $this->db->from('tbl_product_tier');
        
        $query    = $this->db->get();
        $products = $query->result_array();
        
        return $products;
        
    }
    function getrecipe($recipe_id)
    {
        
        $this->db->select('*');
        $this->db->where('id', $recipe_id);
        $this->db->from('tbl_recipe');
        $query    = $this->db->get();
        $products = $query->row();
        
        return $products;
        
    }
    function submitproduct($data)
    {
        
        $insert = $this->db->insert('tbl_product', $data);
        return $insert;
    }
    function submitproducttier($data)
    {
        $insert = $this->db->insert('tbl_product_tier', $data);
        return $insert;
    }
    
    function updateProduct($data, $id)
    {
        $this->db->where('id', $id);
        $update = $this->db->update('tbl_product', $data);
        return $update;
    }
    function updateproducttier($data, $id, $tpid)
    {
        $this->db->where('product_id', $id);
        $this->db->where('tier_id', $tpid);
        $delete = $this->db->delete('tbl_product_tier');
        
        $insert = $this->db->insert('tbl_product_tier', $data);
        return $insert;
    }
    function deleteProduct($id)
    {
        $this->db->where('id', $id);
        $delete = $this->db->delete('tbl_product');
        if ($delete) {
            $this->db->where('product_id', $id);
            $delete = $this->db->delete('tbl_product_tier');
            return $delete;
        } //$delete
    }
    //change by rohit
    function deleteall($data)
    {
        
        foreach ($data as $id) {
            $this->db->where('product_id', $id);
            $delete1 = $this->db->delete('tbl_product_tier');
            
            $this->db->where('id', $id);
            $delete = $this->db->delete('tbl_product');
            
        } //$data as $id
        return true;
    }
    function getprojecttax($project_id)
    {
        $this->db->select('tax_percentage');
        $this->db->where('project_pid', $project_id);
        $this->db->from(' tbl_project');
        
        $query    = $this->db->get();
        $products = $query->row();
        
        return $products;
        
    }
    function getproductgroup($project_id, $company_id)
    {
        $this->db->select('*');
        $this->db->where('project_id', $project_id);
        
        $this->db->from('tbl_productgroup');
        $query = $this->db->get();
        return $query->result_array();
        
    }
    
    
    
    
    function Addproductgroup($data)
    {
        $insert = $this->db->insert('tbl_productgroup', $data);
        return $insert;
    }
    function Editproductgroup($pgid, $project_id)
    {
        $this->db->select('*');
        $this->db->where('product_groupid', $pgid);
        $this->db->from('tbl_productgroup');
        $query = $this->db->get();
        return $query->row_array();
        
    }
    function Updateproductgroup($pgid, $data)
    {
        $this->db->where('product_groupid', $pgid);
        $update = $this->db->update('tbl_productgroup', $data);
        return $update;
    }
    function Deleteproductgroup($pg_id)
    {
        $this->db->where('product_groupid', $pg_id);
        $delete = $this->db->delete('tbl_productgroup');
        return $delete;
    }
    function deleteallgroup($data)
    {
        foreach ($data as $id) {
            $this->db->where('product_groupid', $id);
            $delete = $this->db->delete('tbl_productgroup');
            
        } //$data as $id
        return $delete;
    }
    
    function getscreenoption()
    {
        $this->db->select('*');
        $this->db->from(' tbl_screenoptions');
        $this->db->order_by("screen_order", "asc");
        $query = $this->db->get();
        return $query->result_array();
        
    }
    
    function getProductDetails($pid)
    {
        
        $this->db->where('id', $pid);
        $this->db->select('project_id,company_id');
        $query = $this->db->get('tbl_product');
        return $query->row();
    }
    /*
    function updatescreenoption($status,$screenid)
    { 
    
    for($i=0; $i<count($screenid); $i++)
    {
    if($status[$i]==""){
    $data = array('screen_status'=>0);
    }else{
    $data = array('screen_status'=>$status[$i]);
    }
    
    $this->db->where('screen_id',$screenid[$i]);
    $update=$this->db->update('tbl_screenoptions',$data);
    }
    return $update;
    
    }*/
    function updatescreenoption($active_tab, $screenid, $order_arr)
    {
        $this->db->select('screen_id');
        $this->db->from(' tbl_screenoptions');
        $this->db->order_by("screen_order", "asc");
        $query       = $this->db->get();
        $all_screens = $query->result_array();
        
        if (!empty($all_screens)) {
            foreach ($all_screens as $v => $each_screen) {
                $screen_id_single = $each_screen['screen_id'];
                
                if (in_array($screen_id_single, $active_tab)) {
                    $data = array(
                        'screen_status' => 1,
                        'screen_order' => $order_arr[$screen_id_single]
                    );
                    $this->db->where('screen_id', $screen_id_single);
                    $update = $this->db->update('tbl_screenoptions', $data);
                } //in_array($screen_id_single, $active_tab)
                else {
                    $data = array(
                        'screen_status' => 0,
                        'screen_order' => $order_arr[$screen_id_single]
                    );
                    $this->db->where('screen_id', $screen_id_single);
                    $update = $this->db->update('tbl_screenoptions', $data);
                }
            } //$all_screens as $v => $each_screen
        } //!empty($all_screens)
        return $update;
        
    }
    
    /*********search***********/
    function search_product_details_model($search_data)
    {
        
        $project_id = $search_data['project_id'];
        $company_id = $search_data['company_id'];
        
        
        
        
        $title_search          = trim($search_data['title_search']);
        $supplier_search       = trim($search_data['supplier_search']);
        $sku_search            = trim($search_data['sku_search']);
        $product_group_search  = trim($search_data['product_group_search']);
        $supplier_sku_search   = trim($search_data['supplier_sku_search']);
        $category_search       = trim($search_data['category_search']);
        $pricing_tiers_search  = trim($search_data['pricing_tiers_search']);
        $default_markup_search = trim($search_data['default_markup_search']);
        $minimum_price_search  = trim($search_data['minimum_price_search']);
        $default_price_search  = trim($search_data['default_price_search']);
        $cost_search           = trim($search_data['cost_search']);
        $recipe_name_search    = trim($search_data['recipe_name_search']);
        
        
        $this->db->select('pt.id,pt.product_title,pt.SKU,sp.sup_name,pg.product_groupname,pt.supplier_sku1,cat.cat_name,pt.product_default_markup,pt.default_price,pt.minimum_price,pt.cost,rp.recipe_name'); //pin.pricingt_name
        $this->db->where('pt.project_id', $project_id);
        $this->db->where('pt.company_id', $company_id);
        
        if (!empty($title_search)) {
            $this->db->like('product_title', $title_search);
        } //!empty($title_search)
        
        if (!empty($supplier_search)) {
            
            $this->db->like('sup_name', $supplier_search);
        } //!empty($supplier_search)
        
        if (!empty($sku_search)) {
            $this->db->like('SKU', $sku_search);
        } //!empty($sku_search)
        
        if (!empty($product_group_search)) {
            $this->db->like('product_groupname', $product_group_search);
        } //!empty($product_group_search)
        
        if (!empty($supplier_sku_search)) {
            $this->db->like('supplier_sku1', $supplier_sku_search);
        } //!empty($supplier_sku_search)
        
        if (!empty($category_search)) {
            $this->db->like('cat_name', $category_search);
        } //!empty($category_search)
        
        if (!empty($default_markup_search)) {
            $this->db->like('product_default_markup', $default_markup_search);
        } //!empty($default_markup_search)
        
        if (!empty($minimum_price_search)) {
            $this->db->like('minimum_price', $minimum_price_search);
        } //!empty($minimum_price_search)
        
        if (!empty($default_price_search)) {
            $this->db->like('default_price', $default_price_search);
        } //!empty($default_price_search)
        
        if (!empty($cost_search)) {
            $this->db->like('cost', $cost_search);
        } //!empty($cost_search)
        
        if (!empty($recipe_name_search)) {
            $this->db->like('recipe_name', $recipe_name_search);
        } //!empty($recipe_name_search)
        
        //if(!empty($pricing_tiers_search)){
        //     $this->db->like('pricingt_name', $pricing_tiers_search);
        //     $this->db->group_by("pricingt_name"); 
        //}
        /*****************************************************************************/
        $this->db->from('tbl_product as pt');
        
        
        // if(!empty($product_group_search)){
        $this->db->join('tbl_productgroup as pg', 'pg.product_groupid = pt.product_groupid');
        // }
        
        //  if(!empty($supplier_search)){
        
        $this->db->join('tbl_supplier sp', 'sp.sup_id = pt.supplier_SKU');
        //  }
        
        // if(!empty($category_search)){
        $this->db->join('tbl_category cat', 'cat.cat_id = pt.category');
        //  }
        
        // if(!empty($recipe_name_search)){
        $this->db->join('tbl_recipe rp', 'rp.id = pt.default_price_recipe');
        //  }
        
        //if(!empty($pricing_tiers_search)){
        //  $this->db->join('tbl_pricingt pin', 'pin.project_id = pt.project_id','left');
        //}
        
        
        
        // $this->db->join('tbl_productgroup', 'tbl_productgroup.product_groupid = pt.product_groupid');
        // $this->db->join('tbl_supplier', 'tbl_supplier.sup_id = pt.supplier_SKU');
        $query = $this->db->get();
        
        //echo $this->db->last_query(); die;
        $products = $query->result_array();
        
        
        return $products;
        
    }
    
    /*********************/
    
    function getTiers($pid, $cid)
    {
        $this->db->where('t.project_id', $pid);
        $this->db->where('t.company_id', $cid);
        $this->db->group_by('tier_id');
        $this->db->select('t.pricingt_id,t.pricingt_name,pt.product_id,pt.tier_id,pt.select_recipe_price,pt.select_recipe');
        $this->db->from('tbl_product_tier pt');
        $this->db->join('tbl_pricingt t', 'pt.tier_id=t.pricingt_id');
        $query = $this->db->get();
        
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } //$query->num_rows() > 0
        else {
            return 'x';
        }
    }
    
    function getTiersPrice($pId)
    {
        
        $this->db->where('product_id', $pId);
        $query = $this->db->get('tbl_product_tier');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } //$query->num_rows() > 0
        else {
            return 'x';
        }
    }
    
    function getRecipeName($rcId)
    {
        $this->db->where('id', $rcId);
        $query = $this->db->get('tbl_recipe');
        if ($query->num_rows() > 0) {
            return $query->row();
        } //$query->num_rows() > 0
        else {
            return 'x';
        }
    }
    
}

?>
