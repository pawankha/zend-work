<?Php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Recipe_m extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    function getrecipes($project_id, $company_id)
    {
        
        $this->db->select('*');
        
        if(!empty($project_id)){
            $this->db->where('project_id', $project_id);
        }
        if(!empty($company_id)){
            $this->db->where('company_id', $company_id);
        }
        
        $this->db->from('tbl_recipe');
        $query   = $this->db->get();
        $recipes = $query->result_array();
        
        return $recipes;
        
    }
    function getroundname($round_id)
    {
        
        $this->db->select('round_id,method_name');
        $this->db->where('round_id', $round_id);
        $this->db->from('tbl_roundmethod');
        $query   = $this->db->get();
        $recipes = $query->row();
        
        return $recipes;
        
    }
    function getmethod()
    {
        
        $this->db->select('*');
        
        $this->db->from('tbl_roundmethod');
        $query    = $this->db->get();
        $r_method = $query->result_array();
        
        return $r_method;
        
    }
    
    
    
    function submitrecipe($data)
    {
        
        $insert = $this->db->insert('tbl_recipe', $data);
        return $insert;
    }
    
    function getrecipe($id)
    {
        
        $this->db->select('*');
        $this->db->where('id', $id);
        $this->db->from('tbl_recipe');
        
        $query = $this->db->get();
        return $query->row_array();
    }
    function updateRecipe($data, $id)
    {
        $this->db->where('id', $id);
        $update = $this->db->update('tbl_recipe', $data);
        return $update;
    }
    function deleteRecipe($id)
    {
        $this->db->where('id', $id);
        $delete = $this->db->delete('tbl_recipe');
        return $delete;
    }
    
    //change by rohit
    function deleteall($data)
    {
        foreach ($data as $id) {
            $this->db->where('id', $id);
            $delete = $this->db->delete('tbl_recipe');
            
        } //$data as $id
        return $delete;
    }
    
    
}
?>
