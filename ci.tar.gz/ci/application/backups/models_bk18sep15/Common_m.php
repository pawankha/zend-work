<?Php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Common_m extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
    function getCount($tbl, $select, $where)
    {
        
        $this->db->select($select);
        $this->db->from($tbl);
        $this->db->where($where);
        $query = $this->db->get();
        return count($query->result_array());
    }
    function get_row_data($tbl, $select, $where)
    {
        
        $this->db->select($select);
        $this->db->from($tbl);
        $this->db->where($where);
        $query = $this->db->get();
        return $query->row_array();
    }
    function get_all_data($tbl, $select, $where)
    {
        
        $this->db->select($select);
        $this->db->from($tbl);
        $this->db->where($where);
        $query = $this->db->get();
        return $query->result_array();
    }
    
    // Work in recipe to set price based on round methods
    
    function set_newprice_recipe($tbl, $recipeId,$project_id,$company_id)
    {
        
        //$this->db->where('minimum_price_recipe', $recipeId);
       // $this->db->or_where('default_price_recipe', $recipeId);
       $this->db->where('project_id', $project_id);
       $this->db->where('company_id', $company_id);
        $query = $this->db->get($tbl);
        
       //$tbl.'$recipeId'.$recipeId.'$project_id'.$project_id.'$company_id'.$company_id.'numrows'.$query->num_rows(); die;
        if ($query->num_rows() > 0) {
            $result = $query->result_array();
          
            foreach ($result as $val) {
                $minimum_price_recipe = $this->getrecipe($val['minimum_price_recipe']);
                $tax                  = $this->getprojecttax($val['project_id']);
                $tax12                = $tax['tax_percentage'];
                $productid1           = $val['id'];
                
                
                
                $category_markup        = $this->getcategorymarkup($val['category']);
                $supplier_markup        = $this->getsuppliermarkup($val['supplier_SKU']);
                $cost                   = $val['cost'];
                $product_default_markup = $val['product_default_markup'];
                
                $category_default_markup = $category_markup['cat_markup'];
                $supplier_default_markup = $supplier_markup['sup_percentage'];
                $recipe                  = $minimum_price_recipe['formula1'];
                
                $minimum_price = $this->makeformulastr($recipe, $cost, $product_default_markup, $category_default_markup, $supplier_default_markup, $tax12);
                
                $roundVal          = $minimum_price_recipe['rounding_value'];
                $newPrice          = $this->roundMethod($minimum_price, $roundVal);
                $minimum_price_new = $newPrice; //minimum price (12.00)
                
              
                $default_price_recipe = $this->getrecipe($val['default_price_recipe']);
                $recipe               = $default_price_recipe['formula1'];
                $default_price        = $this->makeformulastr($recipe, $cost, $product_default_markup, $category_default_markup, $supplier_default_markup, $tax12);
                
                $roundVal1         = $default_price_recipe['rounding_value'];
                $newPrice1         = $this->roundMethod($default_price, $roundVal1);
                $default_price_new = $newPrice1; // default price (12.00)
                 
                  $default_price_tier_recipe             = $this->getrecipe($recipeId);
                  //echo '<pre>'; print_r($default_price_tier_recipe);
                  $default_price_tier_recipe_formula     = $default_price_tier_recipe['formula1'];
                  $default_price_tier_recipe_round_value = $default_price_tier_recipe['rounding_value'];
                   // echo 'cost='.$cost.'promarkup='.$product_default_markup.'catmarkup='.$category_default_markup.'suppmarkup='.$supplier_default_markup.'tax='.$tax12.'<br>';
                     $dynamic_recipe_price = $this->makeformulastr($default_price_tier_recipe_formula, $cost, $product_default_markup, $category_default_markup, $supplier_default_markup, $tax12);
                     
                     $dynamic_recipes_price_final  = $this->roundMethod($dynamic_recipe_price, $default_price_tier_recipe_round_value);
                    
                //echo '<pre>'; print_r($dynamic_recipes_price_final);
                $newMinprice = array(
                    'minimum_price' => $minimum_price_new,
                    'default_price' => $default_price_new
                );
                $this->db->where('id', $val['id']);
                $update = $this->db->update($tbl, $newMinprice);
                if ($update) {
                     
                    $newMinprice1 = array(
                        'select_recipe_price' => $dynamic_recipes_price_final
                    );
                    $where        = array(
                        'select_recipe ' => $recipeId,
                        'product_id' => $productid1
                    );
                    $this->db->where($where);
                    $this->db->update('tbl_product_tier', $newMinprice1);
                } //$update
                
                
                
            } //$result as $val
            
        } //$query->num_rows() > 0
    }
    
    // Update price on Recipe change from pricing Tiers
    
    function updatePriceOnTierRecipeUpdate($table, $container,$action='')
    {
        // table => tbl_product;
        
        $project_id                = $container['project_id']; //5
        $company_id                = $container['company_id']; //3
        $price_tier_id             = $container['price_tier_id']; //21
        $price_tier_name           = $container['price_tier_detail']['pricingt_name']; //amezon price
        $price_tier_default_recipe = $container['price_tier_detail']['default_recipe']; //27
        $price_tier_created_by     = $container['price_tier_detail']['pricingt_createdby']; //3
        
        if (!empty($project_id) && !empty($company_id)) {
            $this->db->where('project_id', $project_id);
            $this->db->where('company_id', $company_id);
            $query = $this->db->get($table);
            if ($query->num_rows() > 0) {
                $result = $query->result_array();
                
                foreach ($result as $kk => $vv) {
                    
                    $product_id                   = $vv['id'];
                    $product_category             = $vv['category'];
                    $product_cost                 = $vv['cost'];
                    $product_default_markup       = $vv['product_default_markup'];
                    $product_minimum_price_recipe = $vv['minimum_price_recipe'];
                    $product_supplier_SKU         = $vv['supplier_SKU'];
                    $product_minimum_price        = $vv['minimum_price'];
                    $product_default_price_recipe = $vv['default_price_recipe'];
                    $product_default_price        = $vv['default_price'];
                    
                    $minimum_price_recipe             = $this->getrecipe($product_minimum_price_recipe);
                    $minimum_price_recipe_formula     = $minimum_price_recipe['formula1'];
                    $minimum_price_recipe_round_value = $minimum_price_recipe['rounding_value'];
                    
                    $default_price_recipe             = $this->getrecipe($product_default_price_recipe);
                    $default_price_recipe_formula     = $default_price_recipe['formula1'];
                    $default_price_recipe_round_value = $default_price_recipe['rounding_value'];
                    
                    
                    $default_price_tier_recipe             = $this->getrecipe($price_tier_default_recipe);
                    $default_price_tier_recipe_formula     = $default_price_tier_recipe['formula1'];
                    $default_price_tier_recipe_round_value = $default_price_tier_recipe['rounding_value'];
                    
                    $category_markup         = $this->getcategorymarkup($product_category);
                    $category_default_markup = $category_markup['cat_markup'];
                    
                    $supplier_markup         = $this->getsuppliermarkup($product_supplier_SKU);
                    $supplier_default_markup = $supplier_markup['sup_percentage'];
                    
                    $tax            = $this->getprojecttax($project_id);
                    $tax_percentage = $tax['tax_percentage'];
                    
                    // Round method start for minimum price recipe 
                    $minimum_price   = $this->makeformulastr($minimum_price_recipe_formula, $product_cost, $product_default_markup, $category_default_markup, $supplier_default_markup, $tax_percentage);
                    $MinimumPriceNew = $this->roundMethod($minimum_price, $minimum_price_recipe_round_value);
                    
                    // Round method start for default price recipe 
                    $default_price   = $this->makeformulastr($default_price_recipe_formula, $product_cost, $product_default_markup, $category_default_markup, $supplier_default_markup, $tax_percentage);
                    $DefaultPriceNew = $this->roundMethod($default_price, $default_price_recipe_round_value);
                    
                     // Round method start for Dynamic price Tiers recipe 
                    $default_price_tiers = $this->makeformulastr($default_price_tier_recipe_formula, $product_cost, $product_default_markup, $category_default_markup, $supplier_default_markup, $tax_percentage);
                    $DefaultPriceTierNew = $this->roundMethod($default_price_tiers, $default_price_tier_recipe_round_value);
                    
                    // Update minimum price & default price in product table
                    $where = array(
                        'minimum_price' => $MinimumPriceNew,
                        'default_price' => $DefaultPriceNew
                    );
                    $this->db->where('id', $product_id);
                    $updated = $this->db->update($table, $where);
                    
                    
                    
                    // Update Price for Each Dynamic Tiers in
                    if ($updated) {

                        if($action=='update'){
                         
                         // Update Tier price based on updated recipe
                        $updates               = array(
                            'select_recipe_price' => $DefaultPriceTierNew,
                            'select_recipe' => $price_tier_default_recipe
                        );
                        $where_for_productTier = array(
                            'tier_id ' => $price_tier_id,
                            'product_id' => $product_id
                        );
                        $this->db->where($where_for_productTier);
                        $this->db->update('tbl_product_tier', $updates);
                        
                        }
                        
                        if($action=='insert'){
                         
                          // Update Tier price of products based on new tiers created
                        $insert               = array(
                            'select_recipe_price' => $DefaultPriceTierNew,
                            'select_recipe' => $price_tier_default_recipe,
                            'tier_id ' => $price_tier_id,
                            'product_id' => $product_id,
                        );
                        $this->db->insert('tbl_product_tier', $insert);
                         
                        }
                        
                    } //$updated
                    
                    
                } //$result as $kk => $vv
                
            } //$query->num_rows() > 0
        } //!empty($project_id) && !empty($company_id)
        
        
    }
    
    
    // Works in supplier section & category section & Tax section to set price based on round methods
    
    function set_newprice($tbl,$where)
    {
        $this->db->where($where);
        
        $query = $this->db->get($tbl);
        if ($query->num_rows() > 0) {
            $result = $query->result_array();
            
            foreach ($result as $val) {
                $minimum_price_recipe = $this->getrecipe($val['minimum_price_recipe']);
                $tax                  = $this->getprojecttax($val['project_id']);
                $tax12                = $tax['tax_percentage'];
                
                
                $productid1              = $val['id'];
                $category_markup         = $this->getcategorymarkup($val['category']);
                $supplier_markup         = $this->getsuppliermarkup($val['supplier_SKU']);
                $cost                    = $val['cost'];
                $product_default_markup  = $val['product_default_markup'];
                $category_default_markup = $category_markup['cat_markup'];
                $supplier_default_markup = $supplier_markup['sup_percentage'];
                $recipe                  = $minimum_price_recipe['formula1'];
                
                $minimum_price = $this->makeformulastr($recipe, $cost, $product_default_markup, $category_default_markup, $supplier_default_markup, $tax12);
                
                $roundVal          = $minimum_price_recipe['rounding_value'];
                $newPrice          = $this->roundMethod($minimum_price, $roundVal);
                $minimum_price_new = $newPrice;
                
                $default_price_recipe = $this->getrecipe($val['default_price_recipe']);
                $recipe               = $default_price_recipe['formula1'];
                $default_price        = $this->makeformulastr($recipe, $cost, $product_default_markup, $category_default_markup, $supplier_default_markup, $tax12);
              
                $roundVal1         = $default_price_recipe['rounding_value'];
                $newPrice1         = $this->roundMethod($default_price, $roundVal1);
                $default_price_new = $newPrice1;
                
                $newMinprice = array(
                    'minimum_price' => $minimum_price_new,
                    'default_price' => $default_price_new
                );
                $this->db->where('id', $val['id']);
                $update = $this->db->update($tbl, $newMinprice);
                if ($update) {
                    /*******************************************************/
                    $dynamic_recipes      = $this->recipe_m->getrecipes($val['project_id'],$val['company_id']);
                    
                    foreach($dynamic_recipes as $krex=>$vrex){
                    $dynamic_recipes_id    = $vrex['id'];
                    $default_price_tier_recipe_formula     = $vrex['formula1'];
                    $default_price_tier_recipe_round_value = $vrex['rounding_value'];
                    
                    // Round method start for Dynamic price Tiers recipe 
                    $default_price_tiers = $this->makeformulastr($default_price_tier_recipe_formula, $cost, $product_default_markup, $category_default_markup, $supplier_default_markup, $tax12);
                    
                    $dynamic_recipes_price = $this->roundMethod($default_price_tiers, $default_price_tier_recipe_round_value);
                   
                   $update_dynamic_recipe = array(
                        'select_recipe_price' => $dynamic_recipes_price
                    );
                   
                   $where        = array(
                        'select_recipe' => $dynamic_recipes_id,
                        'product_id' => $productid1
                    );
                    $this->db->where($where);
                    $this->db->update('tbl_product_tier', $update_dynamic_recipe);
                    
                   
                    }
                    
                    /************************************************/
                    
                    
                } //$update
                
            } //$result as $val
            
        } //$query->num_rows() > 0
    }
    
    // Work in project to set price based on round methods
    
    function set_new($tbl, $where)
    {
        $this->db->where($where);
        $query = $this->db->get($tbl);
        if ($query->num_rows() > 0) {
            $result = $query->result_array();
            foreach ($result as $val) {
                
                
                
                $minimum_price_recipe = $this->getrecipe($val['minimum_price_recipe']);
                $tax                  = $this->getprojecttax($val['project_id']);
                $tax12                = $tax['tax_percentage'];
                $rep1                 = $this->recipe_m->getrecipes($val['project_id']);
                foreach ($rep1 as $rep2) {
                } //$rep1 as $rep2
                $recipeId   = $rep2['id'];
                $productid1 = $val['id'];
                
                $category_markup         = $this->getcategorymarkup($val['category']);
                $supplier_markup         = $this->getsuppliermarkup($val['supplier_SKU']);
                $cost                    = $val['cost'];
                $product_default_markup  = $val['product_default_markup'];
                $category_default_markup = $category_markup['cat_markup'];
                $supplier_default_markup = $supplier_markup['sup_percentage'];
                $recipe                  = $minimum_price_recipe['formula1'];
                
                $minimum_price     = $this->makeformulastr($recipe, $cost, $product_default_markup, $category_default_markup, $supplier_default_markup, $tax12);
                $roundVal          = $minimum_price_recipe['rounding_value'];
                $newPrice          = $this->roundMethod($minimum_price, $roundVal);
                $minimum_price_new = $newPrice;
                
                $default_price_recipe = $this->getrecipe($val['default_price_recipe']);
                $recipe               = $default_price_recipe['formula1'];
                $default_price        = $this->makeformulastr($recipe, $cost, $product_default_markup, $category_default_markup, $supplier_default_markup, $tax12);
                
                $roundVal1         = $default_price_recipe['rounding_value'];
                $newPrice1         = $this->roundMethod($default_price, $roundVal1);
                $default_price_new = $newPrice1;
                
                $newMinprice = array(
                    'minimum_price' => $minimum_price_new,
                    'default_price' => $default_price_new
                );
                $this->db->where('id', $val['id']);
                $update = $this->db->update($tbl, $newMinprice);
                if ($update) {
                    $newMinprice1 = array(
                        'select_recipe_price' => $minimum_price_new
                    );
                    $where        = array(
                        'select_recipe ' => $recipeId,
                        'product_id' => $productid1
                    );
                    $this->db->where($where);
                    $this->db->update('tbl_product_tier', $newMinprice1);
                } //$update
            } //$result as $val
            
        } //$query->num_rows() > 0
    }
    
    
    
    function getprojecttax($project_id12)
    {
        $this->db->select('tax_percentage');
        $this->db->where('project_pid', $project_id12);
        $this->db->from(' tbl_project');
        
        $query    = $this->db->get();
        $products = $query->row_array();
        
        return $products;
        
    }
    function getrecipe($recipe_id)
    {
        
        $this->db->select('*');
        $this->db->where('id', $recipe_id);
        $this->db->from('tbl_recipe');
        
        $query    = $this->db->get();
        $products = $query->row_array();
        
        return $products;
        
    }
    
    function getcategorymarkup($id)
    {
        $this->db->select('*');
        $this->db->where('cat_id', $id);
        $this->db->from('tbl_category');
        
        $query    = $this->db->get();
        $category = $query->row_array();
        
        return $category;
    }
    
    function getsuppliermarkup($id)
    {
        $this->db->select('*');
        $this->db->where('sup_id', $id);
        $this->db->from('tbl_supplier');
        
        $query    = $this->db->get();
        $supplier = $query->row_array();
        
        return $supplier;
    }
    
    
    
    
    
    
    
    function makeformulastr($recipe, $cost = "0", $product_default_markup = "0", $category_default_markup = "0", $supplier_default_markup = "0", $tax = "0")
    {
        
        $plus     = "+";
        $minus    = "-";
        $time     = "*";
        $division = "/";
        $arr      = explode(":", $recipe);
        
        $i          = 1;
        $str        = "";
        $newCost    = 0;
        $newsetCost = 0;
        foreach ($arr as $arrs) {
            if ($arrs == "+") {
                $str .= "+";
            } //$arrs == "+"
            if ($arrs == "-") {
                $str .= "-";
            } //$arrs == "-"
            if ($arrs == "*") {
                $str .= "*";
            } //$arrs == "*"
            if ($arrs == "/") {
                $str .= "/";
            } //$arrs == "/"
            if ($arrs == "Cost_Price") {
                $str .= $cost;
                $newsetCost = $cost;
            } //$arrs == "Cost_Price"
            if ($arrs == "Product_Markup") {
                
                $str .= ($newsetCost * $product_default_markup / 100);
                $newCost    = ($newsetCost * $product_default_markup / 100);
                $newsetCost = $newsetCost + $newCost;
                
            }
            //$arrs == "Product_Markup"
            if ($arrs == "Category_Markup") {
                
                $str .= ($newsetCost * $category_default_markup / 100);
                $newCost    = ($newsetCost * $category_default_markup / 100);
                $newsetCost = $newsetCost + $newCost;
                
                
            } //$arrs == "Category_Markup"
            if ($arrs == "Supliers_Markup") {
                $str .= ($newsetCost * $supplier_default_markup / 100);
                $newCost    = ($newsetCost * $supplier_default_markup / 100);
                $newsetCost = $newsetCost + $newCost;
                
            } //$arrs == "Supliers_Markup"
            if ($arrs == "Tax") {
                
                $str .= ($newsetCost * $tax / 100);
                $newCost    = ($newsetCost * $tax / 100);
                $newsetCost = $newsetCost + $newCost;
                
            } //$arrs == "Tax"
            if (substr($arrs, 0, 16) == "Enter_Percentage") {
                $string = explode("(", $arrs);
                $no     = trim($string[1], '()');
                $str .= $newsetCost * $no / 100;
                $newCost    = ($newsetCost * $no / 100);
                $newsetCost = $newsetCost + $newCost;
                
            } //substr($arrs, 0, 16) == "Enter_Percentage"
            if (substr($arrs, 0, 12) == "Enter_Amount") {
                $string = explode("(", $arrs);
                $no     = trim($string[1], '()');
                
                
                $str .= $no;
                
            } //substr($arrs, 0, 12) == "Enter_Amount"
        } //$arr as $arrs
        
        $eq = $this->evaluate($str);
        if ($eq != "") {
            $result = @eval("return " . $eq . ";");
            
        } //$eq != ""
        else {
            $result = 0;
        }
        
        return number_format($result, 2);
    }
    
    
    
     function roundMethod($price, $roundVal)
    {
        $getDesimalVal = explode(".", $price);
        $gnNewPrice    = 0;
        if ($roundVal == 2) {
            if ($getDesimalVal[1] >= 0) {
                $gnNewPrice = $getDesimalVal[0] + 1;
            } else {
                $gnNewPrice = $price;
            }
            return number_format($gnNewPrice, 2);
        } else if ($roundVal == 3) {
            
            if ($getDesimalVal[1] >= 0) {
                $gnNewPrice = $getDesimalVal[0] + 0.99;
            } else {
                $gnNewPrice = $price;
            }
            return number_format($gnNewPrice, 2);
        } else if ($roundVal == 4) {
            
            if ($getDesimalVal[1] >= 0) {
                $gnNewPrice = $getDesimalVal[0] + 0.95;
            } else {
                $gnNewPrice = $price;
            }
            return number_format($gnNewPrice, 2);
        } else if ($roundVal == 5) {
            
            if ($getDesimalVal[1] >= 50) {
                $gnNewPrice = $getDesimalVal[0] + 1;
            } else if ($getDesimalVal[1] < 50) {
                $gnNewPrice = $getDesimalVal[0] + 0.50;
            } else {
                $gnNewPrice = $price;
            }
            return number_format($gnNewPrice, 2);
        } else if ($roundVal == 6) {
            
            if ($getDesimalVal[1] > 0) {
                $gnNewPrice = $getDesimalVal[0];
            }elseif($getDesimalVal[1] == 0){
	         $gnNewPrice = $getDesimalVal[0]-1;
	    }
	    else {
                $gnNewPrice = $price;
            }
            return number_format($gnNewPrice, 2);
        } else if ($roundVal == 7) {
            
            if ($getDesimalVal[1] >= 0) {
                $getPrice   = $getDesimalVal[0] - 1;
                $gnNewPrice = $getPrice + 0.99;
            } else {
                $gnNewPrice = $price;
            }
            return number_format($gnNewPrice, 2);
        } else if ($roundVal == 8) {
            
            if ($getDesimalVal[1] >= 0) {
                $getPrice   = $getDesimalVal[0] - 1;
                $gnNewPrice = $getPrice + 0.95;
            } else {
                $gnNewPrice = $price;
            }
            return number_format($gnNewPrice, 2);
        } else if ($roundVal == 9) {
            
            if ($getDesimalVal[1] > 50) {
                $gnNewPrice = $getDesimalVal[0] + 0.50;
                
            } else if ($getDesimalVal[1] < 50) {
                $gnNewPrice = $getDesimalVal[0];
            } else {
                $gnNewPrice = $price;
            }
            return number_format($gnNewPrice, 2);
        } else {
            $gnNewPrice = $price;
            return $gnNewPrice;
        }
        
    }
    
    function evaluate($equation)
    {
        $result   = 0;
        // sanitize imput
        $equation = preg_replace("/[^a-z0-9+\-.*\/()%]/", "", $equation);
        
        // convert alphabet to $variabel 
        $equation = preg_replace("/([a-z])+/i", "\$$0", $equation);
        
        
        // convert percentages to decimal
        $equation = preg_replace("/([+-])([0-9]{1})(%)/", "*(1\$1.0\$2)", $equation);
        $equation = preg_replace("/([+-])([0-9]+)(%)/", "*(1\$1.\$2)", $equation);
        $equation = preg_replace("/([0-9]{1})(%)/", ".0\$1", $equation);
        $equation = preg_replace("/([0-9]+)(%)/", ".\$1", $equation);
        /* 
        if ( $equation != "" )
        {
        $result = @eval("return " . $equation . ";" );
        
        }
        */
        /* 
        if ($result == null)
        {
        throw new Exception("Unable to calculate equation");
        }
        
        return $result;
        */
        return $equation;
        
    }
    
    
    
}
?>
