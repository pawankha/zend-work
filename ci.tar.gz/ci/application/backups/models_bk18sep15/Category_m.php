<?Php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Category_m extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
    function Addcategory($data)
    {
        
        $insert = $this->db->insert('tbl_category', $data);
        return $insert;
    }
    function getCategory($project_id)
    {
        
        
        $this->db->select('*');
        $this->db->where('project_id', $project_id);
        $query        = $this->db->get('tbl_category');
        $arrProject[] = $query->result_array();
        return $query->result_array();
    }
    
    
    function Editcategory($catid)
    {
        $this->db->select('*');
        $this->db->where('cat_id', $catid);
        $this->db->from('tbl_category');
        $query = $this->db->get();
        return $query->row_array();
        
    }
    function updateCategory($data, $catid)
    {
        $this->db->where('cat_id', $catid);
        $update = $this->db->update('tbl_category', $data);
        return $update;
    }
    function Deletecategory($catid)
    {
        
        $this->db->where('cat_id', $catid);
        
        $delete = $this->db->delete('tbl_category');
        return $delete;
    }
    
    
    
    public function get_subcategory($parentId)
    {
        $this->db->where('cat_id', $parentId);
        $query = $this->db->get('tbl_category');
        if ($query->num_rows() > 0) {
            return $query->row();
        } //$query->num_rows() > 0
        else {
            return 'x';
        }
    }
    
    public function get_categoryname($catId)
    {
        
        $this->db->where('cat_id', $catId);
        $query = $this->db->get('tbl_category');
        if ($query->num_rows() > 0) {
            return $query->row();
        } //$query->num_rows() > 0
    }
    
    public function getUserlist($userId, $userType)
    {
        
        if ($userType == 2) {
            $query = $this->db->query("SELECT user_username,user_id FROM tbl_users WHERE user_id!='" . $userId . "' and user_type!=2 ");
        } //$userType == 2
        else if ($userType == 1) {
            $query = $this->db->query("SELECT user_username,user_id FROM tbl_users WHERE created_by='" . $userId . "' and user_type!=1 ");
        } //$userType == 1
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } //$query->num_rows() > 0
    }
    
    function get_pusername($userId)
    {
        $this->db->where('user_id', $userId);
        $this->db->select('user_fname,user_id,user_lname');
        $query = $this->db->get('tbl_users');
        if ($query->num_rows() > 0) {
            return $query->row();
        } //$query->num_rows() > 0
    }
    //change by rohit
    function deleteall($data)
    {
        foreach ($data as $id) {
            $this->db->where('cat_id', $id);
            $delete = $this->db->delete('tbl_category');
            
        } //$data as $id
        return $delete;
    }
}
?>
