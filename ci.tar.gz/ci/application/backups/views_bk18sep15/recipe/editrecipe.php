<?php $session_data =$this->session->userdata('logged_in'); ?> 
<style>
   .divtop{
   margin-top:10px;
   }
</style>
<div class="row wrapper border-bottom white-bg page-heading">
   <div class="col-lg-10">
      <h2><?php $project_data=get_project_name(encript($project_id)); echo "Project Name: ".$project_data['project_name'] ?></h2>
      <ol class="breadcrumb">
         <li>
            <a href="<?php echo base_url(); ?>dashboard"> Dashboard</a>
         </li>
         <li>
            <a href="<?php echo base_url(); ?>recipe/getrecipes/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>"> Recipes</a>
         </li>
         <li class="active">
            <strong> Edit Recipe</strong>
         </li>
         <!-- <li class="active">
            <strong><?php //echo $this->lang->line('add_new_user'); ?></strong>
            </li>-->
      </ol>
   </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
<div class="row">
<div class="col-lg-12">
   <div class="ibox float-e-margins">
      <div class="ibox-title">
         <h5>Edit Recipe </h5>
      </div>
      <div class="ibox-content">
         <?php if(!empty($recipe_id) && $action=="")
            {
            $action="updateRecipe/".encript($project_id)."/".encript($company_id);
            }
            else
            {
            $action="submitrecipe/".encript($project_id)."/".encript($company_id);
            }
            ?>
         <form method="post" class="form-horizontal" id="addrecipeform" action="<?php echo base_url(); ?>recipe/<?php echo $action; ?>" >
            <input type="hidden" value="<?php echo encript($recipe_id); ?>" name="recipe_id" class="form-control" required>
            <input type="hidden" value="<?php echo encript($project_id); ?>" name="project_id" class="form-control" required>
            <input type="hidden" value="<?php echo encript($company_id); ?>" name="company_id" class="form-control" required>
            <div class="form-group">
               <label class="col-sm-2 control-label">Recipe Name</label>
               <div class="col-lg-4 ">
                  <input type="text" value="<?php echo $recipe['recipe_name'];?>" id="recipe_name" name="recipe_name" class="form-control" required>
               </div>
            </div>
            <div class="form-group">
               <label class="col-sm-2 control-label">Rounding Method</label>
               <div class="col-lg-4 ">
                  <select class="form-control" name="rounding_id" >
                     <?php foreach($r_method as $roundvalue) {?>
                     <option <?php if(!empty($recipe['id'])){ if($recipe['rounding_value']==$roundvalue['round_id']){ echo "selected"; } } ?> value="<?php  echo $roundvalue[round_id] ?>" > <?php echo $roundvalue['method_name'] ?>  </option>
                     <?php }?>
                  </select>
               </div>
            </div>
            <div class="hr-line-dashed"></div>
            <div style="overflow:hidden">
               <div class="col-lg-2">
               </div>
               <div class="col-lg-10" style="padding-left: 5px;">
                  <div class="addfield">
                     <?php
                        $plus="+";
                        $minus="-";
                        $time="*";
                        $division="/";
                        $arr=explode(":", $recipe['formula1']);
                        //echo $recipe['formula1'];
                        ?>
                     <?php
                        $i=1;
                        foreach($arr as $arrs){?>
                     <?php if($i==1){ ?>
                     <div id="TextBoxDiv<?php echo $i; ?>">
                        <div class="form-group">
                           <?php } ?>
                           <?php if($arrs=="+" || $arrs=="-" || $arrs=="*" || $arrs=="/"){ ?>
                           <div id="TextBoxDiv<?php echo $i; ?>">
                              <div class="form-group">
                                 <div class="col-lg-2 divtop">
                                    <select class="form-control"  id="sfield<?php echo $i; ?>" onchange="javascript:setdisfield('<?php echo $i;?>')" name="sign<?php echo $i; ?>">
                                       <option <?php if($arrs=="+"){ echo "selected"; } ?> value="+">plus+</option>
                                       <option <?php if($arrs=="-"){ echo "selected"; } ?> value="-">Minus-</option>
                                       <option <?php if($arrs=="*"){ echo "selected"; } ?> value="*">Times*</option>
                                       <option <?php if($arrs=="/"){ echo "selected"; } ?> value="/">Divided By /</option>
                                    </select>
                                 </div>
                                 <?php }else{  ?>
                                 <div class="amt_textfield">
                                    <div class="col-lg-4 divtop">
                                       <?php if($i==1){ ?>
                                       <select class="form-control" id="field<?php echo $i; ?>" name="markup<?php echo $i; ?>" onchange="javascript:textfield(<?php echo $i; ?>)">
                                          <option <?php if($arrs=="Cost_Price"){ echo "selected"; } ?> value="Cost Price">Cost Price</option>
                                          <option <?php if(substr($arrs, 0, 12)=="Enter_Amount"){ echo "selected"; } ?> value="Enter Amount">Enter Amount</option>
                                       </select>
                                       <?php }else{ ?>
                                       <select class="form-control" id="field<?php echo $i; ?>" name="markup<?php echo $i; ?>" onchange="javascript:textfield(<?php echo $i; ?>)">
                                          <option <?php if($arrs=="Cost_Price"){ echo "selected"; } ?> value="Cost Price">Cost Price</option>
                                          <option <?php if($arrs=="Product_Markup"){ echo "selected"; } ?> value="Product Markup">Product Markup</option>
                                          <option <?php if($arrs=="Category_Markup"){ echo "selected"; } ?> value="Category Markup">Category Markup</option>
                                          <option <?php if($arrs=="Supliers_Markup"){ echo "selected"; } ?> value="Supliers Markup">Supliers Markup</option>
                                          <option <?php if(substr($arrs, 0, 12)=="Enter_Amount"){ echo "selected"; } ?> value="Enter Amount">Enter Amount</option>
                                          <option <?php if(substr($arrs, 0, 16)=="Enter_Percentage"){ echo "selected"; } ?> value="Enter Percentage">Enter Percentage</option>
                                          <option <?php if($arrs=="Tax"){ echo "selected"; } ?> value="Tax">Tax</option>
                                       </select>
                                       <?php } ?>
                                       <input type="hidden" name="count[]" value="<?php echo $i; ?>">
                                    </div>
                                 </div>
                                 <?php if(substr($arrs, 0, 16)=="Enter_Percentage"){
                                    $string=explode("(", $arrs);
                                    $no=trim($string[1], '()');
                                    
                                     ?>
                                 <div class="col-lg-3 divtop" id="percentdiv<?php echo $i ?>"><input type="text" name="percent<?php echo $i ?>" id="percent<?php echo $i ?>" value="<?php echo $no ?>" placeholder="Percentage" class="form-control"></div>
                                 <?php }
                                    if(substr($arrs, 0, 12)=="Enter_Amount"){
                                       $string=explode("(", $arrs);
                                    $no=trim($string[1], '()');
                                    ?>
                                 <div class="col-lg-3 divtop" id="amtdiv<?php echo $i ?>"><input type="text" name="amt<?php echo $i ?>" id="amt<?php echo $i ?>" value="<?php echo $no ?>" placeholder="Amount" class="form-control"></div>
                                 <?php } ?>
                                 <?php if($i!=1){ ?>
                                 <div class="col-lg-2 divtop"><button class="btn btn-primary" id="" type="button" onclick="javascript:removefield('<?php echo $i; ?>')">Remove Rule</button></div>
                                 <?php } ?>
                              </div>
                           </div>
                           <?php $i++; }?>
                           <?php } ?>
                        </div>
                        <button class="btn btn-primary" id="addrule" type="button">Add Rule</button>
                     </div>
                  </div>
                  <div class="hr-line-dashed"></div>
                  <div class="form-group">
                     <div class="col-sm-4 col-sm-offset-2">
                        <a href="<?php echo base_url(); ?>recipe/getrecipes/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">    
                        <button class="btn btn-white" type="button">Cancel</button></a>
                        <button class="btn btn-primary" type="submit">Save changes</button> 
                     </div>
                  </div>
         </form>
         </div>
         </div>
      </div>
   </div>
</div>
<script >
   $(document).ready(function(){
   
       var counter = <?php echo $i; ?>;
    
       $("#addrule").click(function () {
    
   //	if(counter>10){
   //            alert("Only 10 textboxes allow");
   //            return false;
   //	}   
    
   	var newTextBoxDiv = $(document.createElement('div'))
   	     .attr("id", 'TextBoxDiv' + counter);
    
   	newTextBoxDiv.after().html('<div class="form-group"><div class="col-lg-2 divtop"><select class="form-control" onchange="javascript:setdisfield('+counter+')" id="sfield'+counter+'" name="sign'+counter+'"><option value="+">plus+</option><option value="-">Minus-</option><option value="*">Times*</option><option value="/">Divided By /</option></select></div><div class="amt_textfield"><div class="col-lg-4 divtop "><select class="form-control" id="field'+counter+'" name="markup'+counter+'" onchange="javascript:textfield('+counter+')"> <option value="Cost Price">Cost Price</option><option value="Product Markup">Product Markup</option><option value="Category Markup">Category Markup</option><option value="Supliers Markup">Supliers Markup</option><option value="Enter Amount">Enter Amount</option><option value="Enter Percentage">Enter Percentage</option><option value="Tax">Tax</option></select><input type="hidden" name="count[]" value="'+counter+'"></div></div><div class="col-lg-2 divtop"><button class="btn btn-primary" id="" type="button" onclick="javascript:removefield('+counter+')">Remove Rule</button></div></div>');
    
   	newTextBoxDiv.appendTo(".addfield");
    
    
   	counter++;
        });
    
   
        
        $("#removeButton").click(function () {
   	if(counter==2){
             alert("No more textbox to remove");
             return false;
          }   
    
   	counter--;
    
           $("#TextBoxDiv" + counter).remove();
    
        });
    
        $("#getButtonValue").click(function () {
    
   	var msg = '';
   	for(i=1; i<counter; i++){
      	  msg += "\n Textbox #" + i + " : " + $('#textbox' + i).val();
   	}
       	  alert(msg);
        });
     });
   
   	function setdisfield(id){
   
   	 if($('#sfield' + id).val()=="*" || $('#sfield' + id).val()=="/"){
   	
   		$("#field"+id+" option[value='Product Markup']").prop('disabled','disabled');
   		$("#field"+id+" option[value='Category Markup']").prop('disabled','disabled');
   		$("#field"+id+" option[value='Supliers Markup']").prop('disabled','disabled');
   		$("#field"+id+" option[value='Enter Percentage']").prop('disabled','disabled');
   		$("#field"+id+" option[value='Tax']").prop('disabled','disabled');
   		
   	 } else {
   		$("#field"+id+" option[value='Product Markup']").prop('disabled',false);
   		$("#field"+id+" option[value='Category Markup']").prop('disabled',false);
   		$("#field"+id+" option[value='Supliers Markup']").prop('disabled',false);
   		$("#field"+id+" option[value='Enter Percentage']").prop('disabled',false);
   		$("#field"+id+" option[value='Tax']").prop('disabled',false);
   	 }
   	}	
   	
   function textfield(id) {
   //alert($('#field' + id).val());
    $('#percentdiv'+id).remove();
      $('#amtdiv'+id).remove();
   if ($('#field' + id).val()=="Enter Amount") {
    $('#percentdiv'+id).remove();
    $('#TextBoxDiv' + id+ ' .form-group .amt_textfield').append('<div class="col-lg-3 divtop" id="amtdiv'+id+'"><input type="text" name="amt'+id+'" id="amt'+id+'" value="" placeholder="Amount" class="form-control"></div>');
   }
   if ($('#field' + id).val()=="Enter Percentage") {
     $('#amtdiv'+id).remove();
    $('#TextBoxDiv' + id+ ' .form-group .amt_textfield').append('<div class="col-lg-3 divtop" id="percentdiv'+id+'"><input type="text" name="percent'+id+'" id="percent'+id+'" value="" placeholder="Percentage" class="form-control"></div>');
   }
   
        };
        function removefield(id) {
         $("#TextBoxDiv" + id).remove();
        }
              
</script>
<script>
   $().ready(function() {
   $("#addrecipeform").validate({
   		rules: {
   			recipe_name: "required",
   		
   			
   			
   		},
   		messages: {
   			recipe_name: "Please enter Recipe Title",
   			
   		}
   	});
   });
</script>