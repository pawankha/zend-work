<div class="row wrapper border-bottom white-bg page-heading">
   <div class="col-lg-10">
      <h2><?php $project_data=get_project_name(encript($project_id)); echo "Project Name: ".$project_data['project_name'] ?></h2>
      <ol class="breadcrumb">
         <li>
            <a href="<?php echo base_url(); ?>dashboard"> Dashboard</a>
         </li>
         <li class="active">
            All Recipes 
         </li>
         <!-- <li class="active">
            <strong><?php //echo $this->lang->line('add_new_user'); ?></strong>
            </li>-->
      </ol>
   </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
<?php
   $message = $this->session->flashdata('item');
   if($message!="") {
   
   ?>
<div class="alert <?php echo $message['class']; ?>">
   <button type="button" class="close close-sm" data-dismiss="alert">
   <i class="fa fa-times"></i>
   </button>
   <?php echo $message['message']; ?>
</div>
<?php
   }
   ?>      
<form  action="<?php echo base_url(); ?>recipe/deleteall" method="post">
   <input type="hidden" name="companyid" value="<?php echo encript($company_id); ?>" />  
   <div class="row">
      <div class="col-lg-12">
         <div class="ibox float-e-margins">
            <div class="ibox-title">
               <h5> Product Recipes </h5>
            </div>
            <div class="ibox-content">
               <div class="">
                  <a  class="btn btn-primary" href="<?php echo base_url(); ?>recipe/addrecipe/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">Add Recipe </a>
                  <button type="submit" value="submit"  id="delete" disabled="disabled" onclick="return confirm('Are you sure you want to delete this ?')" class="btn btn-primary">Delete All Selected</button>
               </div>
               <div class="table-responsive" >
                  <table class="table table-striped table-bordered table-hover dataTables-example" style="width:99%"   id="editable" >
                     <thead>
                        <tr>
                           <th><?php if(count($recipes)>0){ ?><input type="checkbox" class="i-checks checkall"><?php } ?> </th>
                           <th>Serial No.</th>
                           <th>Recipe Name</th>
                           <th>Recipe Formula</th>
                           <th>Rounding Method Name</th>
                           <th>Action</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php
                           $i=1;
                            foreach($recipes as $recipe)
                            { ?>
                        <tr class="gradeX">
                           <td><input type="checkbox"    class="i-checks"    name="delete[]" value="<?php echo $recipe['id']?>"></td>
                           <td><?php  echo $i ?></td>
                           <td><?php echo  $recipe['recipe_name'];?></td>
                           <input type="hidden" name="projectid" value="<?php echo encript($project_id); ?>" />
                           <input type="hidden" name="companyid" value="<?php echo encript($company_id); ?>" /> 
                           <td><?php echo  $recipe['formula'];?></td>
                           <td> <?php
                              $round_id=$recipe['rounding_value'];
                              $roundname=$this->recipe_m->getroundname($round_id);
                              echo $roundname->method_name;
                              ?></td>
                           <td class="center">
                              <a  class="btn btn-white btn-sm" href="<?php echo base_url(); ?>recipe/editrecipe/<?php echo encript($recipe['id']);?>/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>"> <i class="fa fa-pencil"></i> Edit</a>
                              <a class="btn btn-white btn-sm" onclick="return confirm('Are you sure you want to delete this item?')"
                                 href="<?php echo base_url(); ?>recipe/deleterecipe/<?php echo encript($recipe['id']);?>/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>"> Delete</a>
                              <a  class="btn btn-white btn-sm" href="<?php echo base_url(); ?>recipe/editrecipe/<?php echo encript($recipe['id']);?>/<?php echo encript($project_id)?>/<?php echo encript($company_id)."/copy";?>"> <i class="fa fa-copy"></i> Copy</a>
                           </td>
                        </tr>
                        </tr>
                        <?php $i++ ;} ?>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
</form>
<div>
<div style="clear:both"></div>
<script src="<?php echo base_url(); ?>assets/js/plugins/iCheck/icheck.min.js"></script>
<script>
   $(document).ready(function(){
       $('.i-checks').iCheck({
           checkboxClass: 'icheckbox_square-green',
           radioClass: 'iradio_square-green',
       });
   });
   $(document).ready(function(){
   var checkboxes = $("input[type='checkbox']"),
   checkboxes1 = $(".checkall"),
   submitButt = $("#delete");
   $('tbody .iCheck-helper').click(function()
   {
   
   submitButt.attr("disabled", !checkboxes.is(":checked"));
   
   });
   
   //select all//
   $('thead .iCheck-helper').click(function(){
   if (checkboxes1.is(":checked")) {
   $('tbody .i-checks').attr('checked',true);
   $( "tbody .icheckbox_square-green" ).addClass( "checked");
   submitButt.attr("disabled", !checkboxes.is(":checked"));
   }else{
   $('tbody .i-checks').removeAttr('checked'); 
   $( "tbody .icheckbox_square-green" ).removeClass( "checked");
   submitButt.attr("disabled", !checkboxes.is(":checked"));
   }
   //select all//
   
   });
   });
</script>