<?php $session_data =$this->session->userdata('logged_in'); ?> 
<?php
   if(!empty($ptId) && $action==""){
   
    $action="updatePricetier/".encript($project_id)."/".encript($company_id);
    
   } else {
    $action="submitPricetier/".encript($project_id)."/".encript($company_id);
   }
   
   ?>
<div class="row wrapper border-bottom white-bg page-heading">
   <div class="col-lg-10">
      <h2><?php $project_data=get_project_name(encript($project_id)); echo "Project Name: ".$project_data['project_name'] ?></h2>
      <ol class="breadcrumb">
         <li>
            <a href="<?php echo base_url(); ?>dashboard"> Dashboard</a>
         </li>
         <li><a href="<?php echo base_url(); ?>pricingtiers/gettier/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">Pricing Tiers</a>
         </li>
         <li class="active">
            <strong> <?php
               if(!empty($ptId)){
               echo "Edit Pricing Tier";
                
               } else {
               echo " Add Pricing Tier" ;
               
                 }
               ?> </strong>
         </li>
         <!-- <li class="active">
            <strong><?php //echo $this->lang->line('add_new_user'); ?></strong>
            </li>-->
      </ol>
   </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
   <div class="row">
      <div class="col-lg-12">
         <div class="ibox float-e-margins">
            <div class="ibox-title">
               <h5><?php
                  if(!empty($ptId)){
                  echo "Edit Pricing Tier";
                   
                  } else {
                  echo " Add Pricing Tier" ;
                  
                    }
                  ?>  </h5>
            </div>
            <div class="ibox-content">
               <form method="post" id="addtierform"class="form-horizontal" action="<?php echo base_url(); ?>pricingtiers/<?php echo $action; ?>" >
                  <input type="hidden" name="pricingtid" value="<?php if(!empty($pricingt_info['pricingt_id'])){ echo encript($pricingt_info['pricingt_id']);} ?>"/>
                  <input type="hidden" name="project_id" value="<?php if(!empty($project_id)){ echo encript($project_id);} ?>"/>
                  <input type="hidden" name="company_id" value="<?php if(!empty($company_id)){ echo encript($company_id);} ?>"/>
                  <div class="hr-line-dashed"></div>
                  <div class="form-group">
                     <label class="col-sm-2 control-label"><?php echo 'Pricing Tier Name' ?></label>
                     <div class="col-lg-4">
                        <input type="text" name="pricingt_name" placeholder="Pricing Tier Name" class="form-control" required=""
                           value="<?php if(!empty($pricingt_info['pricingt_id'])){ echo  $pricingt_info['pricingt_name'];} ?>">
                     </div>
                  </div>
                  <div class="hr-line-dashed"></div>
                  <div class="form-group">
                     <label class="col-sm-2 control-label"><?php echo 'Default Recipe' ?></label>
                     <div class="col-lg-4">
                        <select name='default_recipe' class="input-sm form-control input-s-sm inline" required>
                           <option value="">Select</option>
                           <?php foreach($recipes as $recipe){?>
                           <option <?php if(!empty($pricingt_info['pricingt_id'])){ if($pricingt_info['default_recipe']==$recipe['id']){ echo "selected"; } } ?> value="<?php echo $recipe['id']?>"><?php echo $recipe['recipe_name'] ?></option>
                           <?php } ?>
                        </select>
                     </div>
                  </div>
                  <div class="hr-line-dashed"></div>
                  <div class="form-group">
                     <div class="col-sm-4 col-sm-offset-2">
                        <a href="<?php echo base_url(); ?>pricingtiers/gettier/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">    
                        <button class="btn btn-white" type="button">Cancel</button></a>
                        <button class="btn btn-primary" type="submit">Save changes</button> 
                     </div>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
<script>
   $().ready(function() {
   $("#addtierform").validate();
   });
</script>