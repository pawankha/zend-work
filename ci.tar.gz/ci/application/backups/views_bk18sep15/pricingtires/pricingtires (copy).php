<div class="wrapper wrapper-content animated fadeInRight">
   <?php
      $message = $this->session->flashdata('item');
      if($message!="") {
      
      ?>
   <div class="alert <?php echo $message['class']; ?>">
      <button type="button" class="close close-sm" data-dismiss="alert">
      <i class="fa fa-times"></i>
      </button>
      <?php echo $message['message']; ?>
   </div>
   <?php
      }
      ?>      
   <div class="row">
      <div class="col-lg-12">
         <div class="ibox float-e-margins">
            <div class="ibox-title">
               <h5> Pricing Tires </h5>
            </div>
            <div class="ibox-content">
               <div class="">
                  <a  class="btn btn-primary" href="<?php echo base_url(); ?>Pricingtires/Addpricingtires">Add Pricing Tires </a>
               </div>
               <table class="table table-striped table-bordered table-hover " id="editable" >
                  <thead>
                     <tr>
                        <th><?php echo $this->lang->line('serial no'); ?> </th>
                        <th>Pricing Tires Name</th>
                        <th></th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php
                        $i=1;
                         foreach($pricingt_info as $pricingtinfo)
                        
                        { ?>            
                     <tr class="gradeX">
                        <td><?php echo  $i ;?></td>
                        <td><?php echo  $pricingtinfo['pricingt_name'];?></td>
                        <td class="center"><a  class="btn btn-white btn-sm" href="<?php echo base_url(); ?>Pricingtires/Editpricingtires/<?php echo $pricingtinfo['pricingt_id']; ?>">
                           <i class="fa fa-pencil"></i><?php echo $this->lang->line('edit'); ?></a>
                           <a  class="btn btn-white btn-sm" onclick="return confirm('Are you sure you want to delete this item?')"
                              href="<?php echo base_url(); ?>Pricingtires/Deletepricingtires/<?php echo $pricingtinfo['pricingt_id'];?>"><?php echo $this->lang->line('delete'); ?></a>
                        </td>
                     </tr>
                     <?php $i++;}?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>