<div class="wrapper wrapper-content animated fadeInRight">
   <?php
      $message = $this->session->flashdata('item');
      if($message!="") {
      
      ?>
   <div class="alert <?php echo $message['class']; ?>">
      <button type="button" class="close close-sm" data-dismiss="alert">
      <i class="fa fa-times"></i>
      </button>
      <?php echo $message['message']; ?>
   </div>
   <?php
      }
      ?>      
   <div class="row">
      <div class="col-lg-12">
         <div class="ibox float-e-margins">
            <div class="ibox-title">
               <h5> Pricing Tiers </h5>
            </div>
            <div class="ibox-content">
               <div class="">
                  <a  class="btn btn-primary" href="<?php echo base_url(); ?>pricingtiers/addpricingtires">Add Pricing Tiers </a>
               </div>
               <table class="table table-striped table-bordered table-hover " id="editable" >
                  <thead>
                     <tr>
                        <th><?php echo $this->lang->line('serial no'); ?> </th>
                        <th>Pricing Tiers Name</th>
                        <?php if($user_type!=0){ ?>
                        <th><?php echo $this->lang->line('Created_by'); ?></th>
                        <?php } ?>
                        <th></th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php
                        foreach($pricingt_info as $Valpricingtinfo){
                        	 foreach($Valpricingtinfo as $arrVal){
                            $getArrVal[]=$arrVal;
                        	 }
                        }
                        
                        foreach($getArrVal as $valUniq){
                        	$uniqueVal[]=$valUniq['pricingt_id'];
                        }
                        
                        $arrUniq=array_unique($uniqueVal);
                        
                        $i=1;
                        
                        foreach($arrUniq as $proId)
                        {
                        	$proResult=$this->pricingt_m->getpricingtname($proId);
                        	 $userDetail= $this->pricingt_m->get_pusername($proResult->pricingt_userid);
                         
                        	?>
                     <tr class="gradeX">
                        <td><?php echo  $i ;?></td>
                        <td><?php echo $proResult->pricingt_name;;?></td>
                        <?php if($user_type!=0){ ?>
                        <td><?php echo ucfirst($userDetail->user_fname)." ".ucfirst($userDetail->user_lname);?></td>
                        <?php } ?>
                        <td class="center"><a  class="btn btn-white btn-sm" href="<?php echo base_url(); ?>pricingtiers/editpricingtiers/<?php echo$proResult->pricingt_id;; ?>">
                           <i class="fa fa-pencil"></i><?php echo $this->lang->line('edit'); ?></a>
                           <a  class="btn btn-white btn-sm" onclick="return confirm('Are you sure you want to delete this item?')"
                              href="<?php echo base_url(); ?>pricingtiers/deletepricingtiers/<?php echo $proResult->pricingt_id;?>"><?php echo $this->lang->line('delete'); ?></a>
                        </td>
                     </tr>
                     <?php $i++;}?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>