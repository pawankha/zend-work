<div class="row wrapper border-bottom white-bg page-heading">
   <div class="col-lg-10">
      <h2><?php $project_data=get_project_name(encript($project_id)); echo "Project Name: ".$project_data['project_name'] ?></h2>
      <ol class="breadcrumb">
         <li>
            <a href="<?php echo base_url(); ?>dashboard"> Dashboard</a>
         </li>
         <li class="active">
            <strong>All Products </strong>
         </li>
         <!-- <li class="active">
            <strong><?php //echo $this->lang->line('add_new_user'); ?></strong>
            </li>-->
      </ol>
   </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
   <?php
      $message = $this->session->flashdata('item');
      if($message!="") {
      
      ?>
   <div class="alert <?php echo $message['class']; ?>">
      <button type="button" class="close close-sm" data-dismiss="alert">
      <i class="fa fa-times"></i>
      </button>
      <?php echo $message['message']; ?>
   </div>
   <?php
      }
      ?>      
   <form  nmae ="" action="<?php echo base_url(); ?>product/deleteall" method="post"/>
      <input type="hidden" name="projectid" value="<?php echo encript($project_id); ?>" />
      <input type="hidden" name="companyid" value="<?php echo encript($company_id); ?>" /> 
      <div class="row">
         <div class="col-lg-12">
            <div class="ibox float-e-margins">
               <div class="ibox-title">
                  <h5> Products</h5>
               </div>
               <div class="ibox-content">
                  <div class="">
                     <a  class="btn btn-primary" href="<?php echo base_url(); ?>product/addproduct/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">Add Product </a>
                     <button type="submit" value="submit"  id="delete" disabled="disabled" onclick="return confirm('Are you sure you want to delete this ?')" class="btn btn-primary">Delete All Selected</button>
                     <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModalScreen">Screen Option</button></a>
                     <a  class="btn btn-primary" id="export_csv" href="<?php echo base_url(); ?>index.php/product/export?project_id=<?php echo encript($project_id)?>&company_id=<?php echo encript($company_id)?>" >Export</a>
                  </div>
                  <div id="test"></div>
                  <div class="table-responsive" >
                     <table class="table table-striped table-bordered table-hover dataTables-example" style="width:99%"   id="editable" >
                        <thead>
                           <tr class="gradeX">
                              <td></td>
                              <td></td>
                              <?php if(!empty($screenoption1)){
                                 foreach($screenoption1 as $screenoptions){
                                 
                                 
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='Title'){
                                 echo '<td>
                                 <input class="search_input_c" type="text" id="title_search" name="title_search" >
                                 </td>';
                                 }
                                 
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='Supplier'){
                                 echo '<td>
                                 <input class="search_input_c" type="text" id="supplier_search" name="supplier_search"  >
                                 </td>';
                                 }
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='SKU'){
                                 echo '<td>
                                 <input class="search_input_c" type="text" id="sku_search" name="sku_search"  >
                                 </td>';
                                 }
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='Product Group'){
                                 echo '<td>
                                 <input class="search_input_c" type="text" id="product_group_search"  name="product_group_search"  >
                                 </td>';
                                 }
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='Supplier Sku'){
                                 echo '<td>
                                 <input class="search_input_c" type="text" id="supplier_sku_search" name="supplier_sku_search"  >
                                 </td>';
                                 }
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='Category'){
                                 echo '<td>
                                 <input class="search_input_c" type="text" id="category_search" name="category_search"  >
                                 </td>';
                                 }
                                 if($screenoptions['screen_status']==1 && trim($screenoptions['screen_name'])=='Pricing Tiers'){
                                 $getProTiers=$this->product_m->getTiers($project_id,$company_id);
                                 foreach($getProTiers as $Valtiers){
                                 
                                 
                                 echo '<td></td>';
                                 }
                                 //<input class="search_input_c" type="text" id="pricing_tiers_search" name="pricing_tiers_search" >
                                 
                                 }
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='Default Markup'){
                                 echo '<td>
                                 <input class="search_input_c" type="text" id="default_markup_search" name="default_markup_search" >
                                 </td>';
                                 }
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='Minimum Price'){
                                 echo '<td>
                                 <input class="search_input_c" type="text" id="minimum_price_search"  name="minimum_price_search"  >
                                 </td>';
                                 }
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='Default Price'){
                                 echo '<td>
                                 <input class="search_input_c" type="text" id="default_price_search" name="default_price_search"  >
                                 </td>';
                                 }
                                 
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='Cost'){
                                 echo '<td>
                                 <input class="search_input_c" type="text" id="cost_search" name="cost_search"  >
                                 </td>';
                                 }
                                 
                                 }
                                 } ?>
                              <td></td>
                           </tr>
                           <tr>
                              <th><?php if(count($products)>0){ ?><input type="checkbox" class="i-checks checkall"><?php } ?> </th>
                              <th>No.</th>
                              <?php 
                                 foreach ($screenoption1 as $screenoption2){?>
                              <?php if($screenoption2['screen_status']==1 && $screenoption2['screen_id']!=11) {?>
                              <th>
                                 <?php  echo $screenoption2['screen_name']; ?>
                              </th>
                              <?php }?>
                              <?php
                                 $getProTiers=$this->product_m->getTiers($project_id,$company_id);
                                   if($screenoption2['screen_status']==1 && $screenoption2['screen_id']==11) {
                                 
                                 foreach($getProTiers as $Valtiers){
                                 		echo "<th>".ucfirst($Valtiers['pricingt_name'])."</th>";
                                 }
                                 	}
                                 ?>
                              <?php } ?>
                              <th>Action</th>
                           </tr>
                        </thead>
                        <tbody id="pro_body">
                           <?php
                              $i=1;
                               foreach($products as $product)
                               { ?>
                           <tr class="gradeX">
                              <td><input type="checkbox"    class="i-checks"    name="delete[]" value="<?php echo $product['id']?>"></td>
                              <td><?php  echo $i ?></td>
                              <?php
                                 if(!empty($screenoption1)){
                                 
                                 foreach($screenoption1 as $screenoptions){
                                 
                                 
                                 
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='Title'){
                                  echo '<td class="title">'.$product['product_title'];
                                  ?>
                              <a class="Quick_edit" data-toggle="modal" backdrop="true" onclick="javascript:clickeditajax(<?php echo $product['id'];?>)"   data-target="#EditProductModal" id="<?php echo $product['id'];?>" >Quick edit</a>
                              <?php
                                 echo '</td>';
                                 }
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='Product Group'){
                                 echo '<td>'.$product['product_groupname'].'</td>';   
                                 }
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='SKU'){
                                 echo '<td>'.$product['SKU'].'</td>';   
                                 }
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='Supplier'){
                                 echo '<td>'.$product['sup_name'].'</td>';   
                                 }
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='Supplier Sku'){
                                 echo '<td>'.$product['supplier_sku1'].'</td>';   
                                 }
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='Category'){
                                 echo '<td>'.$product['cat_name'].'</td>';   
                                 }
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='Cost'){
                                 echo '<td>'.$product['cost'].'</td>';   
                                 }
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='Default Markup'){
                                 echo '<td>'.$product['product_default_markup'].'</td>';   
                                         }
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='Minimum Price'){
                                 echo '<td>'.$product['minimum_price'].'</td>';   
                                 }
                                 if($screenoptions['screen_status']==1 && $screenoptions['screen_name']=='Default Price'){
                                 echo '<td>'.$product['default_price'].'</td>';   
                                 }
                                 if($screenoptions['screen_status']==1 && trim($screenoptions['screen_name'])==trim('Pricing Tiers')){
                                 $getProTiersPrice=$this->product_m->getTiersPrice($product['id']);
                                 
                                 //echo '<pre>'; print_r($getProTiers); print_r($getProTiersPrice); die;			
                                 for($k=0;$k<count($getProTiers); $k++){
                                 if($getProTiersPrice[$k]['select_recipe']!=""){
                                 $recipeName= $this->product_m->getRecipeName($getProTiersPrice[$k]['select_recipe']);
                                 echo "<td>".$getProTiersPrice[$k]['select_recipe_price']."<br><span style='text-align: center;' class='label label-info'>".$recipeName->recipe_name."</span></td>";
                                 } else {
                                 echo "<td>N/A</td>";			
                                 }
                                 
                                    }
                                 }
                                                     
                                 
                                 
                                 }
                                 
                                 }
                                 
                                 ?>
                              <input type="hidden" name="projectid" value="<?php echo encript($project_id); ?>" />
                              <input type="hidden" name="companyid" value="<?php echo encript($company_id); ?>" /> 
                              <td class="center">
                                 <a  class="btn btn-white btn-sm" href="<?php echo base_url(); ?>product/editproduct/<?php echo encript($product['id']);?>/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>"> <i class="fa fa-pencil"></i> Edit</a>
                                 <a class="btn btn-white btn-sm" onclick="return confirm('Are you sure you want to delete this item?')"
                                    href="<?php echo base_url(); ?>product/deleteProduct/<?php echo encript($product['id']);?>/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>"> Delete</a>
                                 <a  class="btn btn-white btn-sm" href="<?php echo base_url(); ?>product/editproduct/<?php echo encript($product['id']);?>/<?php echo encript($project_id)?>/<?php echo encript($company_id)."/copy"?>"> <i class="fa fa-copy"></i> Copy</a>
                              </td>
                           </tr>
                           </tr>
                           <?php $i++ ;} ?>
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </form>
</div>
<div class="modal fade" id="myModalScreen" role="dialog">
<div class="modal-dialog">
   <!-- Modal content-->
   <div class="modal-content">
      <div class="modal-header">
         <h4 class="modal-title"> Select Products Screen Option</h4>
      </div>
      <form name="pop_from_table" id="pop_from_table" action="<?php echo base_url(); ?>product/updatescreenoption" method="post"/>
         <input type="hidden" name="project_id" id="project_id" value="<?php if(!empty($project_id)){ echo  encript($project_id);} ?>"/>
         <input type="hidden" name="company_id" id="company_id" value="<?php if(!empty($company_id)){ echo  encript($company_id);} ?>"/>
         <div class="ibox-content">
            <?php
               //$screenoption=$this->product_m->getscreenoption();
               if(!empty($screenoption1)){
               	$screenoption_bro=$screenoption1;   
               }
               
               foreach($screenoption1 as $screenoption11)
               {
               	   
               ?>
            <div class="col-lg-12" >
               <div class="col-lg-4" >
                  <input type="checkbox"    class="i-checks"    name="title[]"  value="<?php echo  $screenoption11['screen_id']?>" <?php echo ($screenoption11['screen_status']==1 ? 'checked' : '');?> > <?php  echo $screenoption11['screen_name'];?>
               </div>
               <input type="hidden"    name="screen_id[]"  value="<?php echo  $screenoption11['screen_id']?>" >
               <div class="col-lg-4">
                  <select id="order_position<?php echo $screenoption11['screen_id']?>" name="order_position<?php echo $screenoption11['screen_id']?>" class="form-control">
                  <?php if(!empty($screenoption_bro)){
                     foreach($screenoption_bro as $screenoption_bro2){
                      
                      if($screenoption11['screen_order']==$screenoption_bro2['screen_order']){
                     echo '<option value="'.$screenoption_bro2['screen_order'].'" selected="selected">'.$screenoption_bro2['screen_order'].'</option>';      
                      }else{
                      echo '<option value="'.$screenoption_bro2['screen_order'].'" >'.$screenoption_bro2['screen_order'].'</option>';    
                      }
                      
                     }
                     }?>
                  </select>
               </div>
            </div>
            <br>
            <?php } ?>
         </div>
         <div class="modal-footer" style="border-top: 0px;">
            <button type="button" id="close_button" class="btn btn-white" data-dismiss="modal">Cancel</button>
            <button class="btn btn-primary" type="submit"   id="testButton">Save </button> 
         </div>
      </form>
   </div>
</div>
<div class="modal fade" id="myModal" role="dialog">
   <div class="modal-dialog">
      <form method="post" id="productform1"  action="<?php echo base_url() ?>index.php/product/submitproductgroups/<?php echo encript($project_id)?>/<?php echo encript($company_id); ?>" >
         <!-- Modal content-->
         <input type="hidden" name="project_id" id="project_id" value="<?php if(!empty($project_id)){ echo  encript($project_id);} ?>"/>
         <input type="hidden" name="company_id" id="company_id" value="<?php if(!empty($company_id)){ echo  encript($company_id);} ?>"/>
         <div class="modal-content">
            <div class="modal-header">
               <h4 class="modal-title">Create Product Group</h4>
            </div>
            <div class="ibox-content">
               <div class="form-group"><label ><?php echo "Product Group Name"; ?>:</label>
                  <input type="text" name="group_name" id="group_name" placeholder="Product Group Name" class="form-control" required=""
                     >
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" id="close_button" class="btn btn-white" data-dismiss="modal">Cancel</button></a>
               <button type="button" style="display: none;" id="close_button" class="btn btn-default" data-dismiss="modal">Close</button>
               <button class="btn btn-primary" type="submit"   id="testButton">Save </button> 
            </div>
         </div>
      </form>
   </div>
   <div class="modal fade" id="EditProductModal" role="dialog" >
      <div class="modal-dialog">
         <div class="modal-content">
            <div class="ibox-content">
               <div id="productData"></div>
            </div>
         </div>
      </div>
      <div class="out_layer"></div>
   </div>
</div>
<div style="clear:both"></div>
<script src="<?php echo base_url(); ?>assets/js/plugins/iCheck/icheck.min.js"></script>
<script>
   /*
   $(document).ready(function() {
   $('.dataTables-example').dataTable({
     
             responsive: true,
             "dom": 'T<"clear">lfrtip',
             
             "tableTools": {
         "aButtons": [ 
   
   {
   "sExtends": "csv",
             "mColumns": [0, 1, 2, 3,4,5,6],
   },
   
   ],
         
                 "sSwfPath": "<?php echo base_url() ?>assets/js/plugins/dataTables/swf/copy_csv_xls_pdf.swf"
   
             }
         });
   });
   */
   
   function clickeditajax(id){
   var Pid=id;
   
   var base_url="<?php echo base_url(); ?>";
   dataString="product_d="+Pid
   $.ajax({
      type: "POST",
      url: base_url + "product/editajaxproduct", 
      data: dataString,
      dataType: "text",  
      cache:false,
      success: 
           function(data){
            $('#productData').html(data);
   	
   	$("#saveEditVal").click(function(){
   
   var project_id = $("#project_id").val();
    var company_id = $("#company_id").val();
   var product_title=$("#product_title").val();
   var product_id1=$("#product_id1").val();
   var product_id2=$("#product_id2").val();
   var r2=$("#r2").val();
   var SKU=$("#SKU").val();
   var supplier_SKU=$("#supplier_SKU").val();
   var suppliersku1=$("#suppliersku1").val();
   var product_category=$("#product_category").val();
   var cost=$("#cost").val();
    var product_default_markup=$("#product_default_markup").val();
    var minimum_price_recipe=$("#minimum_price_recipe").val();
     var default_price_recipe=$("#default_price_recipe").val();
   var tax=$("#tax").val();
   
   var n = $("input[name^='tier_id']").length;
   var array = $("input[name^='tier_id']");
   var tier_value = [];
   for(i=0; i < n; i++) {
   tier_value.push(array.eq(i).val()); // otherwise it'd be .eq(i).val(); (if you wanted the text value)
   }
   
   var n1 = $("select[name^='tier_recipe']").length;
   var array1 = $("select[name^='tier_recipe']");
   
   var recipe_value = [];
   for(j=0; j < n1; j++) {
   recipe_value.push(array1.eq(j).val()); // otherwise it'd be .eq(i).val(); (if you wanted the text value)
   }
   
   
   var str="action=quickEdit&project_id="+project_id+"&company_id="+company_id+"&product_title="+product_title+"&product_groupid="+r2+"&SKU="+SKU+"&supplier_SKU="+supplier_SKU+"&suppliersku1="+suppliersku1+"&product_category="+product_category+"&cost="+cost+"&product_default_markup="+product_default_markup+"&minimum_price_recipe="+minimum_price_recipe+"&default_price_recipe="+default_price_recipe+"&tier_id="+tier_value+"&tier_recipe="+recipe_value+"&tax="+tax+"&product_id1="+product_id1
   
   
   var base_url="<?php echo base_url(); ?>";
    $.ajax({
      type: "POST",
      url: base_url + "product/search_product_details", 
      data: str,
      dataType: "text",  
      cache:false,
      success: 
           function(data){
      $('#pro_body').html(data);
   
      $('#EditProductModal').modal('hide');
   
   $(".search_input_c").keyup();
   
   //$('body').on('hidden.bs.modal', '.modal', function () {
   //  $(this).removeData('bs.modal');
   //});
   //$('#EditProductModal').dialog('close');
   $('#close_button').click();
   
   
   
   
           }
       });
   return false;
   
   });
   
   
   	
           }
       });   
   }
     $(document).ready(function(){
   
   
   /******************SEARCH FUNCTIONALITY**********************************/
   
   $(".search_input_c").keyup(function(){
   
   var project_id = '<?php echo encript($project_id); ?>';
   var company_id = '<?php echo encript($company_id); ?>';
   
   var title_search = $("#title_search").val();
   var supplier_search = $("#supplier_search").val();
   var sku_search = $("#sku_search").val();
   var product_group_search = $("#product_group_search").val();
   var supplier_sku_search = $("#supplier_sku_search").val();
   var category_search = $("#category_search").val();
   var pricing_tiers_search = $("#pricing_tiers_search").val();
   var default_markup_search = $("#default_markup_search").val();
   var minimum_price_search = $("#minimum_price_search").val();
   var default_price_search = $("#default_price_search").val();
   var cost_search = $("#cost_search").val();
   var recipe_name_search = $("#recipe_name_search").val();
   
   
   if ($( "#title_search" ).length==0) {
   title_search='';
   }
   
   if ($( "#supplier_search" ).length==0) {
   supplier_search='';
   }
   
   if ($( "#sku_search" ).length==0) {
   sku_search='';
   }
   if ($( "#product_group_search" ).length==0) {
   product_group_search='';
   }
   if ($( "#supplier_sku_search" ).length==0) {
   supplier_sku_search='';
   }
   if ($( "#category_search" ).length==0) {
   category_search='';
   }
   if ($( "#pricing_tiers_search" ).length==0) {
   pricing_tiers_search='';
   }
   if ($( "#default_markup_search" ).length==0) {
   default_markup_search='';
   }
   if ($( "#minimum_price_search" ).length==0) {
   minimum_price_search='';
   }
   if ($( "#default_price_search" ).length==0) {
   default_price_search='';
   }
   if ($( "#cost_search" ).length==0) {
   cost_search='';
   }
   
   if ($( "#recipe_name_search" ).length==0) {
   recipe_name_search='';
   }
   
   
   //if (title_search!="" || supplier_search!="" || sku_search!="" || product_group_search!="" || supplier_sku_search!="" || category_search!="" || pricing_tiers_search!="" || default_markup_search!="" || minimum_price_search!="" || default_price_search!="" || cost_search!="" || recipe_name_search!="") {
   var dataString = 'project_id='+project_id+'&company_id='+company_id+'&title_search='+title_search+'&supplier_search='+supplier_search+'&sku_search='+sku_search+'&product_group_search='+product_group_search+'&supplier_sku_search='+supplier_sku_search+'&category_search='+category_search+'&pricing_tiers_search='+pricing_tiers_search+'&default_markup_search='+default_markup_search+'&minimum_price_search='+minimum_price_search+'&default_price_search='+default_price_search+'&cost_search='+cost_search+'&recipe_name_search='+recipe_name_search;
   
   var base_url="<?php echo base_url(); ?>";
   
    $.ajax({
      type: "POST",
      url: base_url + "product/search_product_details/", 
      data: dataString,
      dataType: "text",  
      cache:false,
      success: 
           function(data){
            $('#pro_body').html(data);
   var href="<?php echo base_url(); ?>index.php/product/export?"+dataString;
   $("#export_csv").attr("href", href)				 
           }
       });
   //}
   
   //  var dataString = 'Product_name_search='+Product_name_search;
   
   });
   /************************END******************************/
   
   
   var order_arr=[];
   /*************************/
   function hasDuplicates(array) {
   var valuesSoFar = [];
   for (var i = 0; i < array.length; ++i) {
     var value = array[i];
     if (valuesSoFar.indexOf(value) !== -1) {
         return true;
     }
     valuesSoFar.push(value);
   }
   return false;
   }
   
   $("#pop_from_table").submit(function(){
   
   
   var op1=document.getElementById('order_position1').value;
   var op2=document.getElementById('order_position2').value;
   var op3=document.getElementById('order_position3').value;
   var op4=document.getElementById('order_position4').value;
   var op5=document.getElementById('order_position5').value;
   var op6=document.getElementById('order_position6').value;
   var op7=document.getElementById('order_position7').value;
   var op8=document.getElementById('order_position8').value;
   var op9=document.getElementById('order_position9').value;
   var op10=document.getElementById('order_position10').value;
   var op11=document.getElementById('order_position11').value;
   
   
   order_arr=[op1,op2,op3,op4,op5,op6,op7,op8,op9,op10,op11];
   
   
   var dpl=hasDuplicates(order_arr);
   
   if (dpl==true) {
   alert('Could not use same positions');
   return false;
   }
   
   return true;
       
   
   });
   
   /*************************/
         $('.i-checks').iCheck({
             checkboxClass: 'icheckbox_square-green',
             radioClass: 'iradio_square-green',
         });
     });
   $(document).ready(function(){
   var checkboxes = $("input[type='checkbox']"),
   checkboxes1 = $(".checkall"),
   submitButt = $("#delete");
   $('tbody .iCheck-helper').click(function()
   {
   
   submitButt.attr("disabled", !checkboxes.is(":checked"));
   
   });
   
   //select all//
   $('thead .iCheck-helper').click(function(){
   if (checkboxes1.is(":checked")) {
   $('tbody .i-checks').attr('checked',true);
   $( "tbody .icheckbox_square-green" ).addClass( "checked");
   submitButt.attr("disabled", !checkboxes.is(":checked"));
   }else{
   $('tbody .i-checks').removeAttr('checked'); 
   $( "tbody .icheckbox_square-green" ).removeClass( "checked");
   submitButt.attr("disabled", !checkboxes.is(":checked"));
   }
   //select all//
   
   });
   
   
   });
   
   
   
</script>