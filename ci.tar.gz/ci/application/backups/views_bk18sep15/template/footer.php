<div class="footer">
   <div class="pull-right">
      <strong></strong>.
   </div>
   <div>
      <strong><?php echo $this->lang->line('pricing_copy_right'); ?> </strong>
   </div>
</div>
</div>
</div>
</div>
</div>
<!-- Mainly scripts -->
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="<?php echo base_url(); ?>assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
<script src="<?php echo base_url(); ?>assets/s/plugins/jeditable/jquery.jeditable.js"></script>
<script src="<?php echo base_url(); ?>assets/js/plugins/dataTables/jquery.dataTables.js"></script>
<script src="<?php echo base_url(); ?>assets/js/plugins/dataTables/dataTables.bootstrap.js"></script>
<script src="<?php echo base_url(); ?>assets/s/plugins/dataTables/dataTables.responsive.js"></script>
<script src="<?php echo base_url(); ?>assets/js/plugins/dataTables/dataTables.tableTools.min.js"></script>
<!-- Flot -->
<script src="<?php echo base_url(); ?>assets/js/plugins/flot/jquery.flot.js"></script>
<script src="<?php echo base_url(); ?>assets/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/plugins/flot/jquery.flot.spline.js"></script>
<script src="<?php echo base_url(); ?>assets/js/plugins/flot/jquery.flot.resize.js"></script>
<script src="<?php echo base_url(); ?>assets/js/plugins/flot/jquery.flot.pie.js"></script>
<script src="<?php echo base_url(); ?>assets/js/inspinia.js"></script>
<script src="<?php echo base_url(); ?>assets/js/plugins/pace/pace.min.js"></script>  
<!-- Peity -->
<script src="<?php echo base_url(); ?>assets/js/plugins/peity/jquery.peity.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/demo/peity-demo.js"></script>
<!-- Custom and plugin javascript -->
<!-- jQuery UI -->
<script src="<?php echo base_url(); ?>assets/js/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- GITTER -->
<script src="<?php echo base_url(); ?>assets/js/plugins/gritter/jquery.gritter.min.js"></script>
<!-- Sparkline -->
<script src="<?php echo base_url(); ?>assets/js/plugins/sparkline/jquery.sparkline.min.js"></script>
<!-- Sparkline demo data  -->
<script src="<?php echo base_url(); ?>assets/js/demo/sparkline-demo.js"></script>
<!-- ChartJS-->
<script src="<?php echo base_url(); ?>assets/js/plugins/chartJs/Chart.min.js"></script>
<!-- Toastr -->
<script src="<?php echo base_url(); ?>assets/js/plugins/toastr/toastr.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/plugins/dataTables/swf/copy_csv_xls_pdf.swf"></script>
<script>
   $(document).ready(function() {
   $('.dataTables-example').dataTable({
           responsive: true,
           "dom": 'T<"clear">lfrtip',
           
           "tableTools": {
       "aButtons": [],
       
               "sSwfPath": "<?php echo base_url() ?>assets/js/plugins/dataTables/swf/copy_csv_xls_pdf.swf"
   
           }
       });
      
   
       /* Init DataTables */
       var oTable = $('#editable').dataTable();
   
       /* Apply the jEditable handlers to the table */
       oTable.$('td').editable( '../example_ajax.php', {
           "callback": function( sValue, y ) {
               var aPos = oTable.fnGetPosition( this );
               oTable.fnUpdate( sValue, aPos[0], aPos[1] );
           },
           "submitdata": function ( value, settings ) {
               return {
                   "row_id": this.parentNode.getAttribute('id'),
                   "column": oTable.fnGetPosition( this )[2]
               };
           },
   
           "width": "90%",
           "height": "100%"
       } );
   
   
   });
   
   function fnClickAddRow() {
       $('#editable').dataTable().fnAddData( [
           "Custom row",
           "New row",
           "New row",
           "New row",
           "New row" ] );
   
   }
</script>
</body>
</html>