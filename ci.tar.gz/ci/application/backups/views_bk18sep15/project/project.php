<div class="row wrapper border-bottom white-bg page-heading">
   <div class="col-lg-10">
      <h2><?php $company_data=get_company_name(encript($company_id)); echo "Company Name: ".$company_data['company_name'] ?></h2>
      <ol class="breadcrumb">
         <li>
            <a href="<?php echo base_url(); ?>dashboard"> Dashboard</a>
         </li>
         <li class="active">
            <a href="#"><?php echo $this->lang->line('project'); ?></a>
         </li>
         <!-- <li class="active">
            <strong><?php //echo $this->lang->line('add_new_user'); ?></strong>
            </li>-->
      </ol>
   </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
   <?php
      $message = $this->session->flashdata('item');
      if($message!="") {
      
      ?>
   <div class="alert <?php echo $message['class']; ?>">
      <button type="button" class="close close-sm" data-dismiss="alert">
      <i class="fa fa-times"></i>
      </button>
      <?php echo $message['message']; ?>
   </div>
   <?php
      }
      ?>      
   <div class="row">
      <div class="col-lg-12">
         <div class="ibox float-e-margins">
            <div class="ibox-title">
               <h5> <?php echo $this->lang->line('project'); ?> </h5>
            </div>
            <div class="ibox-content">
               <div class="">
                  <a  class="btn btn-primary" href="<?php echo base_url(); ?>project/addproject"><?php echo $this->lang->line('add new project'); ?> </a>
               </div>
               <table class="table table-striped table-bordered table-hover " id="editable" >
                  <thead>
                     <tr>
                        <th><?php echo $this->lang->line('serial no'); ?> </th>
                        <th><?php echo $this->lang->line('project name'); ?></th>
                        <th><?php echo $this->lang->line('Created_by'); ?></th>
                        <th><?php echo $this->lang->line('project status'); ?></th>
                        <th></th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php
                        foreach($project_info as $ValProject){
                        	 foreach($ValProject as $arrVal){
                            $getArrVal[]=$arrVal;
                        	 }
                        }
                        
                        foreach($getArrVal as $valUniq){
                        	$uniqueVal[]=$valUniq['project_pid'];
                        }
                        
                        $arrUniq=array_unique($uniqueVal);
                        
                        $i=1;
                        
                        foreach($arrUniq as $proId)
                        {
                        	$proResult=$this->project_m->getprojectname($proId);
                        	 $userDetail= $this->project_m->get_pusername($proResult->project_userid);
                         
                        	?>    
                     <tr class="gradeX">
                        <td><?php  echo $i ?></td>
                        <td><?php echo  $proResult->project_name;?></td>
                        <td><?php echo ucfirst($userDetail->user_fname)." ".ucfirst($userDetail->user_lname);?></td>
                        <td class="center">
                           <?php if ($proResult->project_status==1)
                              {?>
                           <a href="<?php echo base_url(); ?>project/deactiveproject/<?php echo $proResult->project_pid;?>"><?php echo $this->lang->line('active'); ?></a>
                           <?php }
                              else
                              {  ?> <a href="<?php echo base_url(); ?>project/activeproject/<?php echo $proResult->project_pid;?>"><?php echo $this->lang->line('deactive'); ?></a> <?php }?>
                        </td>
                        <?php 
                           $session_data=$this->session->userdata('logged_in');
                              if($session_data['user_type']==2 || $session_data['user_type']==1){
                           ?>
                        <td class="center"><a  class="btn btn-white btn-sm" href="<?php echo base_url(); ?>project/editProject/<?php echo $proResult->project_pid;?>">
                           <i class="fa fa-pencil"></i><?php echo $this->lang->line('edit'); ?></a>
                           <a  class="btn btn-white btn-sm" onclick="return confirm('Are you sure you want to delete this item?')"
                              href="<?php echo base_url(); ?>project/deleteproject/<?php echo $proResult->project_pid;?>"><?php echo $this->lang->line('delete'); ?></a>
                           <a class="btn btn-white btn-sm" href="<?php echo base_url(); ?>project/editproject/<?php echo $proResult->project_pid;?>">
                           <i class="fa fa-copy"></i><?php echo $this->lang->line('copy'); ?></a>
                        </td>
                        <?php } ?>
                     </tr>
                     <?php $i++ ;} ?>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>