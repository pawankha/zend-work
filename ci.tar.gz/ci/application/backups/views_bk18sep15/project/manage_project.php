<?php $session_data =$this->session->userdata('logged_in');?>
<div class="row wrapper border-bottom white-bg page-heading">
   <div class="col-lg-10">
      <h2><?php $project_data=get_project_name(encript($project_id)); echo "Project Name: ".$project_data['project_name'] ?></h2>
      <ol class="breadcrumb">
         <li>
            <a href="<?php echo base_url(); ?>dashboard"> Dashboard</a>
         </li>
         <li class="active">
            <strong> Manage Project</strong>
         </li>
         <!-- <li class="active">
            <strong><?php //echo $this->lang->line('add_new_user'); ?></strong>
            </li>-->
      </ol>
   </div>
</div>
<div class="wrapper wrapper-content">
   <div class="row">
      <a href="<?php echo base_url(); ?>recipe/getrecipes/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">
         <div class="col-lg-3">
            <div class="ibox float-e-margins">
               <div class="ibox-title">
                  <h5>Recipes</h5>
               </div>
               <div class="ibox-content">
                  <h1 class="no-margins"><?php if($count_recipe!=""){ echo $count_recipe;}else{ echo "0"; } ?></h1>
                  <small>Total Recipes</small>
               </div>
            </div>
         </div>
      </a>
      <a href="<?php echo base_url(); ?>category/getcategory/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">
         <div class="col-lg-3">
            <div class="ibox float-e-margins">
               <div class="ibox-title">
                  <h5>Categories</h5>
               </div>
               <div class="ibox-content">
                  <h1 class="no-margins"><?php if($count_category!=""){ echo $count_category;}else{ echo "0"; } ?></h1>
                  <small>Total Categories</small>
               </div>
            </div>
         </div>
      </a>
      <a href="<?php echo base_url(); ?>supplier/getSupplier/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">
         <div class="col-lg-3">
            <div class="ibox float-e-margins">
               <div class="ibox-title">
                  <h5>Suppliers</h5>
               </div>
               <div class="ibox-content">
                  <h1 class="no-margins"><?php if($count_supplier!=""){ echo $count_supplier;}else{ echo "0"; } ?></h1>
                  <small>Total Suppliers</small>
               </div>
            </div>
         </div>
      </a>
      <a href="<?php echo base_url(); ?>pricingtires/getTier/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">
         <div class="col-lg-3">
            <div class="ibox float-e-margins">
               <div class="ibox-title">
                  <h5>Pricing Tiers</h5>
               </div>
               <div class="ibox-content">
                  <h1 class="no-margins"><?php if($count_tier!=""){ echo $count_tier;}else{ echo "0"; } ?></h1>
                  <small>Total Pricing Tiers</small>
               </div>
            </div>
         </div>
      </a>
      <a href="<?php echo base_url(); ?>product/getproductgroup/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">
         <div class="col-lg-3">
            <div class="ibox float-e-margins">
               <div class="ibox-title">
                  <h5>Product Groups</h5>
               </div>
               <div class="ibox-content">
                  <h1 class="no-margins"><?php if($count_productgroup!=""){ echo $count_productgroup;}else{ echo "0"; } ?></h1>
                  <small>Total Poduct Groups</small>
               </div>
            </div>
         </div>
      </a>
      <a href="<?php echo base_url(); ?>product/getproducts/<?php echo encript($project_id)?>/<?php echo encript($company_id)?>">
         <div class="col-lg-3">
            <div class="ibox float-e-margins">
               <div class="ibox-title">
                  <h5>Products </h5>
               </div>
               <div class="ibox-content">
                  <h1 class="no-margins"><?php if($count_products!=""){ echo $count_products;}else{ echo "0"; } ?></h1>
                  <small>Total Poducts</small>
               </div>
            </div>
         </div>
      </a>
   </div>
</div>