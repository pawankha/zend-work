<div class="wrapper wrapper-content animated fadeInRight">
   <?php
      $message = $this->session->flashdata('item');
      if($message!="") {
      
      ?>
   <div class="alert <?php echo $message['class']; ?>">
      <button type="button" class="close close-sm" data-dismiss="alert">
      <i class="fa fa-times"></i>
      </button>
      <?php echo $message['message']; ?>
   </div>
   <?php
      }
      ?>      
   <form  action="<?php echo base_url(); ?>company/deleteall" method="post"/>
      <div class="row">
         <div class="col-lg-12">
            <div class="ibox float-e-margins">
               <div class="ibox-title">
                  <h5><?php echo $this->lang->line('company'); ?></h5>
               </div>
               <div class="ibox-content">
                  <div class="">
                     <a  class="btn btn-primary" href="<?php echo base_url(); ?>company/addCompany"><?php echo $this->lang->line('add_new_company'); ?></a>
                     <button type="submit" value="submit"  id="delete" disabled="disabled" onclick="return confirm('Are you sure you want to delete this ?')" class="btn btn-primary">Delete All Selected</button>
                  </div>
                  <?php if(count($companies)>0){?>
                  <div class="table-responsive" >
                     <table class="table table-striped table-bordered table-hover dataTables-example" style="width:99%"   id="editable" >
                        <thead>
                           <tr>
                              <th><?php if(count($companies)>0){ ?><input type="checkbox" class="i-checks checkall"><?php } ?></th>
                              <th>Id</th>
                              <th><?php echo $this->lang->line('company_name'); ?></th>
                              <th><?php echo $this->lang->line('company_address');?></th>
                              <th><?php echo $this->lang->line('status'); ?></th>
                              <th class="nosort">Action</th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php
                              $i=1;
                              foreach($companies as $company)
                              {
                              //$creator_id = $userinfo['created_by'];
                              //$creator_info_user = $this->Users_m->created_by_user($creator_id);
                              
                              
                              
                               ?>    
                           <tr class="gradeX">
                              <td><input type="checkbox"    class="i-checks"   name="delete[]" value="<?php  echo $company['id'];?>"></td>
                              <td><?php echo $i ?></td>
                              <td><?php echo ucfirst($company['company_name']);?></td>
                              <td class="center"><?php echo $company['company_address'];?></td>
                              <td class="center">
                                 <?php if ($company['status']==1)
                                    {?>
                                 <a href="<?php echo base_url(); ?>company/deactivecompany/<?php echo encript($company['id']);?>"><span class="label label-primary">Active</span></a>
                                 <?php }
                                    else
                                    {  ?> <a href="<?php echo base_url(); ?>company/activecompany/<?php echo encript($company['id']);?>"><span class="label label-default">Deactive</span></a> <?php }?>
                              </td>
                              <?php
                                 //encrypt using triple DES
                                     ?>
                              <td class="center"><a  class="btn btn-white btn-sm" href="<?php echo base_url(); ?>company/manageadmin/<?php echo encript($company['id']);?>"> <i class="fa fa-pencil"></i>Manage admin</a>
                                 <a class="btn btn-white btn-sm" href="<?php echo base_url(); ?>company/editcompany/<?php echo encript($company['id']);?>"> <i class="fa fa-pencil"></i>Edit</a>
                                 <a class="btn btn-white btn-sm" onclick="return confirm('Are you sure you want to delete this item?')"
                                    href="<?php echo base_url(); ?>company/deletecompany/<?php echo encript($company['id']);?>"> Delete</a>
                                 <a  class="btn btn-white btn-sm" href="<?php echo base_url(); ?>company/editcompany/<?php echo encript($company['id'])."/copy";?>"> <i class="fa fa-copy"></i>Copy</a>
                              </td>
                           </tr>
                           <?php $i++; } ?>
                     </table>
                  </div>
                  <?php }else{ ?>
                  <p>No Result</p>
                  <?php } ?>
               </div>
            </div>
         </div>
      </div>
   </form>
</div>
<div style="clear:both"></div>
<script src="<?php echo base_url(); ?>assets/js/plugins/iCheck/icheck.min.js"></script>
<script>
   $(document).ready(function(){
       $('.i-checks').iCheck({
           checkboxClass: 'icheckbox_square-green',
           radioClass: 'iradio_square-green',
       });
   });
   $(document).ready(function(){
   var checkboxes = $("input[type='checkbox']"),
   checkboxes1 = $(".checkall"),
   submitButt = $("#delete");
   $('tbody .iCheck-helper').click(function()
   {
   
   submitButt.attr("disabled", !checkboxes.is(":checked"));
   
   });
   
   //select all//
   $('thead .iCheck-helper').click(function(){
   if (checkboxes1.is(":checked")) {
   $('tbody .i-checks').attr('checked',true);
   $( "tbody .icheckbox_square-green" ).addClass( "checked");
   submitButt.attr("disabled", !checkboxes.is(":checked"));
   }else{
   $('tbody .i-checks').removeAttr('checked'); 
   $( "tbody .icheckbox_square-green" ).removeClass( "checked");
   submitButt.attr("disabled", !checkboxes.is(":checked"));
   }
   //select all//
   
   });
   });
</script>