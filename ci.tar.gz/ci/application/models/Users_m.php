<?Php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Users_m extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
    // insert user
    function Adduser($data)
    {
        $insert = $this->db->insert('de_login', $data);
        return $insert;
    }
    
    // Get all users of company
    function getUsers($company_id)
    {
        $this->db->select('*');
        $this->db->where('id', $company_id);
        $this->db->from('de_login');
        $query = $this->db->get();
        return $query->result_array();
    }
    
    // Select user of company
    function Edituser($userid, $company_id)
    {
        $this->db->select('*');
        $this->db->where('id', $userid);
        $this->db->from('de_login');
        $query = $this->db->get();
        return $query->row_array();
    }
    
    // update user of company
    function Updateuser($data, $userid)
    {
        $this->db->where('id', $userid);
        $update = $this->db->update('de_login', $data);
        return $update;
    }
    
    // Delete user of company
    function Deleteuser($userid)
    {
        $this->db->where('id', $userid);
        $delete = $this->db->delete('de_login');
        return $delete;
    }
    
    // Activate user of company
    function activeuser($userid, $data)
    {
        $this->db->where('id', $userid);
        $update = $this->db->update('de_login', $data);
        return $update;
    }
    
    // Deactivate user of company
    function deactiveuser($userid, $data)
    {
        $this->db->where('id', $userid);
        $update = $this->db->update('de_login', $data);
        return $update;
    }
    
    // get user created by admin
    function created_by_user($creator_id)
    {
        $this->db->select('*');
        $this->db->where('id', $creator_id);
        $this->db->from('de_login');
        $query = $this->db->get();
        return $query->row_array();
    }
    
    // Delete all users of company
    function deleteall($data)
    {
        foreach ($data as $id) {
            $this->db->where('id', $id);
            $delete = $this->db->delete('de_login');
        } //$data as $id
        return $delete;
    }
}
?>
