<?php
   defined('BASEPATH') OR exit('No direct script access allowed');
   ?><!DOCTYPE html>

    <!-- topbar ends -->
<div class="ch-container">
 <br>
               <ul class="thumbnails gallery">
                     <?php for($i=0;$i<count($userdata);$i++){ ?>
                            <li id="image-1" class="thumbnail">
                                <a style="background:url(<?php echo base_url()."uploads/gallery/".$userdata[$i]['image'] ?>)"
                                   title="Sample Image 1" href="<?php echo base_url()."uploads/gallery/".$userdata[$i]['image'] ?>"><img
                                        class="grayscale" src="<?php echo base_url()."uploads/gallery/".$userdata[$i]['image'] ?>"
                                        alt="Sample Image 1"></a>
                            </li>
                            <?php } ?>
                            </ul>
    </div>

