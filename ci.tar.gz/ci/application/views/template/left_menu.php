<?php //$session_data =$this->session->userdata('logged_in'); ?>

   
   <div class="col-sm-2 col-lg-2">
            <div class="sidebar-nav">
                <div class="nav-canvas">
                    <div class="nav-sm nav nav-stacked">

                    </div>
                    <ul class="nav nav-pills nav-stacked main-menu">
                        <li class="nav-header">Main</li>
                        <li><a class="ajax-link" href="dashboard"><i class="glyphicon glyphicon-home"></i><span> Dashboard</span></a>
                        </li>
                        <li><a class="ajax-link" href="ChangePassword"><i class="glyphicon glyphicon-eye-open"></i><span> Update Password</span></a>
                        </li>
                        <li><a class="ajax-link" href="UpdateProfile"><i
                                    class="glyphicon glyphicon-edit"></i><span> Update Profile</span></a></li>
                        <li><a class="ajax-link" href="AddGallery"><i class="glyphicon glyphicon-list-alt"></i><span> Add Gallery</span></a>
                        </li>
                        <li><a class="ajax-link" href="ViewGallery"><i class="glyphicon glyphicon-picture"></i><span> View Gallery</span></a>
                        </li>
                        
                        <li class="nav-header hidden-md">Manage Users</li>
                        <li><a class="ajax-link" href="AddUser"><i
                                    class="glyphicon glyphicon-align-justify"></i><span> Add User</span></a></li>
                        <li class="accordion">
                            <a href="ViewUser"><i class="glyphicon glyphicon-plus"></i><span> View User</span></a>
                        </li>
                           
                    </ul>
                   
                </div>
            </div>
        </div>
    <noscript>
            <div class="alert alert-block col-md-12">
                <h4 class="alert-heading">Warning!</h4>

                <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a>
                    enabled to use this site.</p>
            </div>
        </noscript>