<?php
   defined('BASEPATH') OR exit('No direct script access allowed');
   ?><!DOCTYPE html>

    <!-- topbar ends -->
<div class="ch-container">
  <div class="box col-md-6">
   <?php
      $message = $this->session->flashdata('item');
       if($message!="")
      {?>
       <div class="alert alert-info" id="errormsg" name="errormsg">
      <?php  echo  $message['message'];?>
      </div>
       <?php }?>
  </div>
    <div class="box col-md-6">
        <div class="box-inner">
            <div class="box-header well" data-original-title="">
                <h2><i class="glyphicon glyphicon-edit"></i> Update Password</h2>
            </div>
            <div class="box-content">
               <?php
               $attributes = array('role' => 'form');?>
                <?php echo form_open_multipart('AddGallery/addgallery',$attributes); ?>
                 <?php echo validation_errors(); ?>
                <div id="imagePreview"></div>
                <div class="form-group"></div> 
                        <label for="exampleInputPassword1"> Update Image</label>
                        <input type="file" class="form-control" id="uploadFile" name="image">
                    </div>
                       <button type="submit" class="btn btn-default">Submit</button>
                      
                       <?php echo form_close(); ?>

            </div>
        </div>
    </div>

